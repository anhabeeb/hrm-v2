import { AlertTriangle, BriefcaseBusiness, CalendarClock, CheckCircle2, Circle, ClipboardCheck, FileCheck2, FileDown, RefreshCw, ShieldAlert, UserPlus, UsersRound, WalletCards } from "lucide-react";
import { FormEvent, type ChangeEvent, type ReactNode, useCallback, useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { EmployeeIdentityCell } from "../components/employee/EmployeeIdentityCell";
import { ExportMenu } from "../components/export/ExportMenu";
import { ActiveFilterChips, FilterResetButton, FilterSection, MoreFiltersSheet, SaveFilterViewButton, StandardDateRangeFilter, StandardFilterBar, StandardSearchInput, StandardSelectFilter, type ActiveFilterChip, type StandardDateRange } from "../components/filters";
import { EmployeeCascadeSelect } from "../components/organization/EmployeeCascadeSelect";
import { OrganizationCascadeSelector } from "../components/organization/OrganizationCascadeSelector";
import { ModuleSettingsBody } from "../components/settings/ModuleToggleHeader";
import { CardSkeleton, FormSkeleton, TableSkeleton } from "../components/loading";
import { ActionTextButton } from "../components/ui/action-button";
import { Badge } from "../components/ui/badge";
import { Button, RowActionButton } from "../components/ui/button";
import { DataTableFrame } from "../components/ui/data-table";
import { EmptyState } from "../components/ui/empty-state";
import { PerformanceDataTable } from "../components/table/PerformanceDataTable";
import { TablePaginationBar } from "../components/table/TablePaginationBar";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { SubNavigationBar, SubNavigationItem } from "../components/ui/navigation-tabs";
import { PageHeader, PageShell } from "../components/ui/page-shell";
import { Panel } from "../components/ui/panel";
import { StatusBadge } from "../components/ui/status-badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Timeline } from "../components/ui/timeline";
import { AdminHelpLink } from "../features/admin-help/AdminHelpLink";
import { useAuth } from "../hooks/useAuth";
import { useDocumentUploadBatch } from "../hooks/useDocumentUploadBatch";
import { usePaginatedQuery } from "../hooks/usePaginatedQuery";
import { useOrganizationReferences } from "../hooks/useOrganizationReferences";
import { useResilientWorkspaceQuery } from "../hooks/useResilientWorkspaceQuery";
import { useWorkspaceMutation } from "../hooks/useWorkspaceMutation";
import { ApiError, api } from "../lib/api";
import type { CompleteDocumentUploadsResult } from "../lib/documentUploadApi";
import { focusFirstInvalidField, normalizeValidationIssues, useFormValidation, validateDateField, validateRequiredField } from "../lib/form-validation";
import { sectionNeedsRetry, sectionStatusLabel, type ModuleSectionState } from "../lib/moduleSectionLoading";
import { queryClient } from "../lib/queryClient";
import { queryKeys } from "../lib/queryKeys";
import { applyWorkspacePayload, invalidateOnboardingWorkspaceSlices, workspaceScope, type WorkspaceSlice } from "../lib/workspaceInvalidation";
import type { Employee } from "../types/employees";
import type { LifecycleSettings, LifecycleTask, OffboardingCase, OnboardingCase } from "../types/lifecycle";
import type { OrganizationDepartment, OrganizationJobLevel, OrganizationLocation, OrganizationPosition } from "../types/organization";
import { CheckboxField, SelectField } from "../components/ui/page-shell";
import { FieldError } from "../components/forms/FieldError";
import { FormErrorSummary } from "../components/forms/FormErrorSummary";
import { ValidatedReasonField, ValidatedTextField } from "../components/forms/validated-fields";
import { useAlert } from "../components/alerts/useAlert";

type Mode =
  | "onboarding-dashboard"
  | "onboarding-cases"
  | "onboarding-settings"
  | "onboarding-alerts"
  | "offboarding-dashboard"
  | "offboarding-cases"
  | "offboarding-settings"
  | "lifecycle-reports";

type CaseKind = "onboarding" | "offboarding";
type Row = Record<string, unknown>;

const nav = [
  { label: "Onboarding Dashboard", mode: "onboarding-dashboard", to: "/onboarding" },
  { label: "Onboarding Cases", mode: "onboarding-cases", to: "/onboarding/cases" },
  { label: "Onboarding Alerts", mode: "onboarding-alerts", to: "/onboarding/alerts" },
  { label: "Offboarding Dashboard", mode: "offboarding-dashboard", to: "/offboarding" },
  { label: "Offboarding Cases", mode: "offboarding-cases", to: "/offboarding/cases" },
  { label: "Lifecycle Reports", mode: "lifecycle-reports", to: "/lifecycle/reports" }
] as const;

const onboardingSettingFields = [
  "onboarding_enabled",
  "require_onboarding_before_activation",
  "allow_draft_employee_records",
  "auto_create_onboarding_case_on_employee_create",
  "allow_partial_onboarding",
  "require_documents_before_activation",
  "require_contract_before_activation",
  "require_payroll_profile_before_activation",
  "require_biometric_mapping_before_activation",
  "require_user_account_before_activation",
  "require_approval_before_activation",
  "allow_activation_override_with_reason",
  "employee_self_service_onboarding_view_enabled"
];

const offboardingSettingFields = [
  "offboarding_enabled",
  "require_offboarding_case_before_exit",
  "auto_create_offboarding_case_on_exit_status",
  "require_final_settlement_before_archive",
  "require_asset_uniform_clearance",
  "require_document_checklist",
  "require_payroll_final_check",
  "require_attendance_final_check",
  "require_roster_future_assignment_check",
  "require_user_account_deactivation",
  "require_access_revocation",
  "require_approval_before_exit_finalization",
  "allow_offboarding_override_with_reason",
  "employee_self_service_offboarding_view_enabled"
];

const reportKeys = [
  "onboarding/summary",
  "onboarding/overdue-tasks",
  "onboarding/blocked",
  "onboarding/completed",
  "onboarding/by-department",
  "onboarding/by-worksite",
  "onboarding/overrides",
  "offboarding/summary",
  "offboarding/overdue-tasks",
  "offboarding/pending-clearance",
  "offboarding/pending-final-settlement",
  "offboarding/pending-payroll-check",
  "offboarding/pending-access-revocation",
  "offboarding/completed",
  "offboarding/overrides",
  "lifecycle/events",
  "lifecycle/sla-placeholder"
];

function text(value: unknown) {
  return value === null || value === undefined || value === "" ? "-" : String(value);
}

function displayText(value: unknown, fallback = "Not set") {
  return value === null || value === undefined || value === "" ? fallback : String(value);
}

function title(value: string) {
  return value.replace(/\//g, " / ").replace(/-/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function isEnabled(value: unknown) {
  return value === true || value === 1 || value === "1";
}

function objectMessage(value: unknown) {
  if (value === null || value === undefined || value === "") return "-";
  if (typeof value === "object") {
    const row = value as Row;
    return String(row.message ?? row.title ?? row.task_name ?? row.field ?? JSON.stringify(row));
  }
  return String(value);
}

export function LifecyclePage({ mode = "onboarding-dashboard" }: { mode?: Mode }) {
  const { token, user } = useAuth();
  const permissions = new Set(user?.permissions ?? []);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [onboardingCases, setOnboardingCases] = useState<OnboardingCase[]>([]);
  const [offboardingCases, setOffboardingCases] = useState<OffboardingCase[]>([]);
  const [dashboard, setDashboard] = useState<Row>({});
  const [alerts, setAlerts] = useState<Row[]>([]);
  const [settings, setSettings] = useState<LifecycleSettings | null>(null);
  const [selected, setSelected] = useState<{ kind: CaseKind; id: string } | null>(null);
  const [createKind, setCreateKind] = useState<CaseKind | null>(null);
  const [reportKey, setReportKey] = useState(reportKeys[0]);
  const [reportRows, setReportRows] = useState<Row[]>([]);
  const [reasonAction, setReasonAction] = useState<{ title: string; submit: (reason: string) => Promise<void> } | null>(null);
  const [casePage, setCasePage] = useState(1);
  const [casePageSize, setCasePageSize] = useState(25);
  const organizationRefs = useOrganizationReferences(token);
  const [searchParams, setSearchParams] = useSearchParams();

  const activeKind: CaseKind = mode.startsWith("offboarding") ? "offboarding" : "onboarding";
  const activeCases = activeKind === "onboarding" ? onboardingCases : offboardingCases;
  const canManageLifecycleSettings = activeKind === "onboarding"
    ? permissions.has("onboarding.settings.manage") || permissions.has("onboarding.settings.update") || permissions.has("settings.manage")
    : permissions.has("offboarding.settings.manage") || permissions.has("offboarding.settings.update") || permissions.has("settings.manage");
  const caseQuery = usePaginatedQuery<{ cases: (OnboardingCase | OffboardingCase)[]; pagination?: Record<string, unknown> }>({
    scope: user?.id,
    tableName: `${activeKind}-cases`,
    page: casePage,
    pageSize: casePageSize,
    filters: { kind: activeKind },
    enabled: Boolean(token && mode.includes("cases")),
    queryFn: ({ signal, pagination }) => activeKind === "onboarding"
      ? api.listOnboardingCases(token!, { limit: pagination.limit, offset: pagination.offset }, signal)
      : api.listOffboardingCases(token!, { limit: pagination.limit, offset: pagination.offset }, signal),
    getRowCount: (data) => data?.cases.length ?? 0
  });

  async function load() {
    if (!token) return;
    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      if (mode.includes("settings")) {
        setSettings(activeKind === "onboarding" ? (await api.getOnboardingSettings(token)).settings : (await api.getOffboardingSettings(token)).settings);
      } else if (mode === "onboarding-alerts") {
        setAlerts((await api.listOnboardingAlerts(token)).alerts);
      } else if (mode === "lifecycle-reports") {
        setReportRows((await api.getReport(token, reportKey)).report.rows as Row[]);
      } else if (mode.includes("dashboard")) {
        setDashboard(activeKind === "onboarding" ? (await api.getOnboardingDashboardSummary(token)).summary : (await api.getOffboardingDashboard(token)).dashboard);
      } else {
        const employeeResult = await api.listEmployees(token, { limit: 100 }).catch(() => ({ employees: [] }));
        setEmployees(employeeResult.employees);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Lifecycle workspace could not be loaded.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, [token, mode, reportKey]);

  useEffect(() => {
    setCasePage(1);
  }, [mode]);

  useEffect(() => {
    const rows = caseQuery.data?.cases;
    if (!rows) return;
    if (activeKind === "onboarding") setOnboardingCases(rows as OnboardingCase[]);
    else setOffboardingCases(rows as OffboardingCase[]);
  }, [activeKind, caseQuery.data]);

  useEffect(() => {
    const caseId = searchParams.get("case_id");
    if (caseId && mode === "onboarding-cases") setSelected({ kind: "onboarding", id: caseId });
  }, [mode, searchParams]);

  async function saveSettings(input: LifecycleSettings) {
    if (!token) return;
    setError(null);
    try {
      setSettings(activeKind === "onboarding" ? (await api.updateOnboardingSettings(token, input)).settings : (await api.updateOffboardingSettings(token, input)).settings);
      setMessage("Settings saved.");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to save lifecycle settings.");
    }
  }

  async function refreshAlerts() {
    if (!token) return;
    await api.refreshOnboardingAlerts(token);
    await load();
  }

  async function exportReport() {
    if (!token) return;
    const download = await api.exportReportCsv(token, reportKey);
    const url = URL.createObjectURL(download.blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = download.filename;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <PageShell>
      <PageHeader
        title="Employee Lifecycle"
        description="Onboarding, offboarding, lifecycle tasks, activation readiness, and exit readiness."
        actions={<><AdminHelpLink target="onboardingDocuments" label="Onboarding guide" /><ActionTextButton intent="refresh" size="sm" onClick={() => void load()}><RefreshCw className="h-4 w-4" /> Refresh</ActionTextButton></>}
      />

      <SubNavigationBar label="Employee lifecycle section tabs">
        {nav.map((item) => <SubNavigationItem key={item.mode} to={item.to} active={mode === item.mode}>{item.label}</SubNavigationItem>)}
      </SubNavigationBar>

      {message ? <div className="rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{message}</div> : null}

      {mode.includes("dashboard") ? (
        <DashboardSection
          kind={activeKind}
          data={dashboard}
          loading={loading || caseQuery.isInitialLoading}
          error={error}
          onSelect={(id) => {
            setSelected({ kind: activeKind, id });
            if (activeKind === "onboarding") setSearchParams({ case_id: id });
          }}
        />
      ) : null}
      {mode.includes("cases") ? (
        <CasesSection
          kind={activeKind}
          cases={activeCases}
          loading={loading}
          error={error ?? caseQuery.error?.message ?? null}
          onCreate={() => setCreateKind(activeKind)}
          onSelect={(id) => {
            setSelected({ kind: activeKind, id });
              if (activeKind === "onboarding") setSearchParams({ case_id: id });
          }}
          pagination={{
            page: casePage,
            pageSize: casePageSize,
            hasMore: Boolean(caseQuery.data?.pagination?.has_more),
            refreshing: caseQuery.isRefreshing,
            onPageChange: setCasePage,
            onPageSizeChange: setCasePageSize
          }}
        />
      ) : null}
      {mode.includes("settings") ? <SettingsSection settings={settings} kind={activeKind} canManage={canManageLifecycleSettings} loading={loading} error={error} onSave={saveSettings} /> : null}
      {mode === "onboarding-alerts" ? <AlertsSection alerts={alerts} loading={loading} error={error} onRefresh={() => void refreshAlerts()} /> : null}
      {mode === "lifecycle-reports" ? <ReportsSection reportKey={reportKey} setReportKey={setReportKey} rows={reportRows} loading={loading} error={error} onExport={() => void exportReport()} /> : null}

      {createKind ? <CreateCaseModal kind={createKind} employees={employees} organizationRefs={organizationRefs} onClose={() => setCreateKind(null)} onCreated={() => { setCreateKind(null); void load(); void caseQuery.refetch(); }} /> : null}
      {selected ? (
        <CaseDetailModal
          kind={selected.kind}
          caseId={selected.id}
          onClose={() => {
            setSelected(null);
            if (searchParams.get("case_id")) setSearchParams({});
          }}
          onChanged={() => { void load(); void caseQuery.refetch(); }}
          askReason={(titleText, submit) => setReasonAction({ title: titleText, submit })}
        />
      ) : null}
      {reasonAction ? <ReasonModal title={reasonAction.title} onClose={() => setReasonAction(null)} onSubmit={async (reason) => { await reasonAction.submit(reason); setReasonAction(null); }} /> : null}
    </PageShell>
  );
}

type OnboardingFilterState = {
  search: string;
  status: string;
  readiness: string;
  plannedStart: StandardDateRange;
  created: StandardDateRange;
  department: string;
  jobLevel: string;
  position: string;
  owner: string;
  blockerType: string;
  documentStatus: string;
  contractStatus: string;
  payrollStatus: string;
  userAccountStatus: string;
  approvalStatus: string;
  activationStatus: string;
};

const defaultOnboardingFilters: OnboardingFilterState = {
  search: "",
  status: "",
  readiness: "",
  plannedStart: {},
  created: {},
  department: "",
  jobLevel: "",
  position: "",
  owner: "",
  blockerType: "",
  documentStatus: "",
  contractStatus: "",
  payrollStatus: "",
  userAccountStatus: "",
  approvalStatus: "",
  activationStatus: ""
};

const setupStatusOptions = ["MISSING", "BLOCKED", "WARNING", "COMPLETE", "NOT_REQUIRED"].map((value) => ({ value, label: title(value) }));
const blockerTypeOptions = [
  { value: "employee_data", label: "Employee Data" },
  { value: "organization", label: "Department / Job / Position" },
  { value: "documents", label: "Documents" },
  { value: "contract", label: "Contract" },
  { value: "payroll", label: "Payroll" },
  { value: "user_account", label: "User Account" },
  { value: "approvals", label: "Approvals" },
  { value: "assets_uniforms", label: "Assets / Uniforms" }
];

function normalize(value: unknown) {
  return String(value ?? "").trim().toLowerCase();
}

function uniqueTextOptions(rows: Row[], key: string) {
  return Array.from(new Set(rows.map((row) => text(row[key])).filter((value) => value !== "-"))).sort().map((value) => ({ value, label: value }));
}

function rowSetupStatus(row: Row, key: string) {
  return String(asRow(row.setup_statuses)[key] ?? "");
}

function dateInRange(value: unknown, range: StandardDateRange) {
  const date = displayText(value, "");
  if (!date) return true;
  if (range.from && date < range.from) return false;
  if (range.to && date > range.to) return false;
  return true;
}

function caseMatchesBlocker(row: Row, blockerType: string) {
  if (!blockerType) return true;
  if (blockerType === "overdue") return Boolean(row.is_overdue);
  if (blockerType === "organization") return !row.primary_department_id || !row.primary_position_id || !row.job_level_id;
  const setupKey = blockerType === "documents" ? "documents"
    : blockerType === "contract" ? "contract"
    : blockerType === "payroll" ? "payroll"
    : blockerType === "user_account" ? "user_account"
    : blockerType === "approvals" ? "approvals"
    : blockerType === "assets_uniforms" ? "assets_uniforms"
    : "employee_data";
  const setupStatus = rowSetupStatus(row, setupKey);
  const blockerTypes = Array.isArray(row.blocker_types) ? row.blocker_types.map((item) => normalize(item)) : [];
  return !["COMPLETE", "NOT_REQUIRED"].includes(setupStatus) || blockerTypes.includes(blockerType);
}

function readinessValue(row: Row) {
  if (row.ready_for_activation || row.activation_status === "READY") return "READY";
  if (row.is_blocked || row.onboarding_status === "BLOCKED" || row.activation_status === "NOT_READY") return "BLOCKED";
  if (row.onboarding_status === "ACTIVATED" || row.activation_status === "ACTIVATED") return "ACTIVATED";
  if (row.has_started_setup) return "IN_PROGRESS";
  return "DRAFT";
}

function filterOnboardingRows(rows: Row[], filters: OnboardingFilterState) {
  const search = normalize(filters.search);
  return rows.filter((row) => {
    const haystack = [
      row.case_number,
      row.employee_name,
      row.employee_name_snapshot,
      row.employee_no,
      row.employee_number_snapshot,
      row.department_name,
      row.location_name,
      row.position_name,
      row.job_level_name
    ].map(normalize).join(" ");
    if (search && !haystack.includes(search)) return false;
    if (filters.status && row.onboarding_status !== filters.status) return false;
    if (filters.activationStatus && row.activation_status !== filters.activationStatus) return false;
    if (filters.readiness && readinessValue(row) !== filters.readiness) return false;
    if (filters.department && text(row.department_name) !== filters.department) return false;
    if (filters.jobLevel && text(row.job_level_name) !== filters.jobLevel) return false;
    if (filters.position && text(row.position_name) !== filters.position) return false;
    if (filters.owner && text(row.assigned_owner_name) !== filters.owner) return false;
    if (!dateInRange(row.planned_start_date, filters.plannedStart)) return false;
    if (!dateInRange(String(row.created_at ?? "").slice(0, 10), filters.created)) return false;
    if (!caseMatchesBlocker(row, filters.blockerType)) return false;
    if (filters.documentStatus && rowSetupStatus(row, "documents") !== filters.documentStatus) return false;
    if (filters.contractStatus && rowSetupStatus(row, "contract") !== filters.contractStatus) return false;
    if (filters.payrollStatus && rowSetupStatus(row, "payroll") !== filters.payrollStatus) return false;
    if (filters.userAccountStatus && rowSetupStatus(row, "user_account") !== filters.userAccountStatus) return false;
    if (filters.approvalStatus && rowSetupStatus(row, "approvals") !== filters.approvalStatus) return false;
    return true;
  });
}

function filterHasValues(filters: OnboardingFilterState) {
  return Object.entries(filters).some(([, value]) => {
    if (typeof value === "object" && value !== null) return Boolean((value as StandardDateRange).from || (value as StandardDateRange).to);
    return Boolean(value);
  });
}

function applyOnboardingDashboardQuery(query: Row | undefined, setFilters: (next: OnboardingFilterState) => void) {
  const next = { ...defaultOnboardingFilters };
  const filter = String(query?.filter ?? "");
  if (filter === "draft") next.readiness = "DRAFT";
  if (filter === "in_progress") next.readiness = "IN_PROGRESS";
  if (filter === "ready") next.readiness = "READY";
  if (filter === "blocked") next.readiness = "BLOCKED";
  if (filter === "overdue") next.blockerType = "overdue";
  if (query?.blocker_type) next.blockerType = String(query.blocker_type);
  if (query?.planned_start_from || query?.planned_start_to) next.plannedStart = { from: String(query.planned_start_from ?? ""), to: String(query.planned_start_to ?? "") };
  setFilters(next);
}

function onboardingFilterChips(filters: OnboardingFilterState, setFilter: <K extends keyof OnboardingFilterState>(key: K, value: OnboardingFilterState[K]) => void, resetRange: (key: "plannedStart" | "created") => void): ActiveFilterChip[] {
  const chips: ActiveFilterChip[] = [];
  const add = (key: keyof OnboardingFilterState, label: string, value: ReactNode) => chips.push({ key: String(key), label, value, onRemove: () => setFilter(key, defaultOnboardingFilters[key] as never) });
  if (filters.search) add("search", "Search", filters.search);
  if (filters.status) add("status", "Status", title(filters.status));
  if (filters.readiness) add("readiness", "Readiness", title(filters.readiness));
  if (filters.department) add("department", "Department", filters.department);
  if (filters.jobLevel) add("jobLevel", "Job level", filters.jobLevel);
  if (filters.position) add("position", "Position", filters.position);
  if (filters.owner) add("owner", "HR owner", filters.owner);
  if (filters.blockerType) add("blockerType", "Blocker", blockerTypeOptions.find((item) => item.value === filters.blockerType)?.label ?? title(filters.blockerType));
  if (filters.documentStatus) add("documentStatus", "Documents", title(filters.documentStatus));
  if (filters.contractStatus) add("contractStatus", "Contract", title(filters.contractStatus));
  if (filters.payrollStatus) add("payrollStatus", "Payroll", title(filters.payrollStatus));
  if (filters.userAccountStatus) add("userAccountStatus", "User account", title(filters.userAccountStatus));
  if (filters.approvalStatus) add("approvalStatus", "Approvals", title(filters.approvalStatus));
  if (filters.activationStatus) add("activationStatus", "Activation", title(filters.activationStatus));
  if (filters.plannedStart.from || filters.plannedStart.to) chips.push({ key: "plannedStart", label: "Planned start", value: `${filters.plannedStart.from || "Any"} - ${filters.plannedStart.to || "Any"}`, onRemove: () => resetRange("plannedStart") });
  if (filters.created.from || filters.created.to) chips.push({ key: "created", label: "Created", value: `${filters.created.from || "Any"} - ${filters.created.to || "Any"}`, onRemove: () => resetRange("created") });
  return chips;
}

function kpiTone(tone: unknown): "neutral" | "success" | "warning" | "danger" | "info" {
  return ["success", "warning", "danger", "info"].includes(String(tone)) ? String(tone) as "success" | "warning" | "danger" | "info" : "neutral";
}

function KpiIcon({ iconKey }: { iconKey: unknown }) {
  const className = "h-4 w-4";
  const key = String(iconKey ?? "");
  if (key.includes("alert")) return <AlertTriangle className={className} />;
  if (key.includes("calendar")) return <CalendarClock className={className} />;
  if (key.includes("document")) return <FileCheck2 className={className} />;
  if (key.includes("contract")) return <BriefcaseBusiness className={className} />;
  if (key.includes("payroll")) return <WalletCards className={className} />;
  if (key.includes("user_account")) return <UserPlus className={className} />;
  if (key.includes("approval") || key.includes("check")) return <ClipboardCheck className={className} />;
  return <UsersRound className={className} />;
}

function DashboardSection({ kind, data, loading, error, onSelect }: { kind: CaseKind; data: Row; loading: boolean; error: string | null; onSelect: (id: string) => void }) {
  if (kind === "onboarding" && Array.isArray(data.kpis)) {
    return <OnboardingDashboardSection data={data} loading={loading} error={error} onSelect={onSelect} />;
  }
  const stats = Object.entries(data).filter(([, value]) => typeof value === "number");
  const rows = (data.rows ?? data.recent_onboarding ?? data.recent_offboarding ?? []) as Row[];
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map(([key, value]) => (
          <Panel key={key} className="p-4">
            <p className="text-xs font-medium uppercase text-muted-foreground">{title(key)}</p>
            <p className="mt-2 text-2xl font-semibold">{String(value)}</p>
          </Panel>
        ))}
      </div>
      <DataTableFrame loading={loading} error={error} empty={!loading && rows.length === 0}>
        <Table>
          <TableHeader><TableRow><TableHead>Case</TableHead><TableHead>Employee</TableHead><TableHead>Status</TableHead><TableHead>Due</TableHead></TableRow></TableHeader>
          <TableBody>
            {rows.map((row) => (
              <TableRow key={String(row.id)}>
                <TableCell>{text(row.case_number)}</TableCell>
                <TableCell><EmployeeIdentityCell employeeId={text(row.employee_id)} employeeName={text(row.employee_name ?? row.employee_name_snapshot)} employeeNumber={text(row.employee_no ?? row.employee_number_snapshot)} departmentName={text(row.department_name)} locationName={text(row.location_name ?? row.worksite_name)} size="sm" /></TableCell>
                <TableCell><StatusBadge value={row.onboarding_status ?? row.offboarding_status} /></TableCell>
                <TableCell>{text(row.due_date)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </DataTableFrame>
    </div>
  );
}

function OnboardingDashboardSection({ data, loading, error, onSelect }: { data: Row; loading: boolean; error: string | null; onSelect: (id: string) => void }) {
  const rows = asRows(data.cases ?? data.rows);
  const enabledModules = asRow(data.enabled_modules);
  const [filters, setFilters] = useState<OnboardingFilterState>(defaultOnboardingFilters);
  const filtered = useMemo(() => filterOnboardingRows(rows, filters), [rows, filters]);
  const setFilter = <K extends keyof OnboardingFilterState>(key: K, value: OnboardingFilterState[K]) => setFilters((current) => ({ ...current, [key]: value }));
  const resetFilters = () => setFilters(defaultOnboardingFilters);
  const resetRange = (key: "plannedStart" | "created") => setFilter(key, {});
  const activeChips = onboardingFilterChips(filters, setFilter, resetRange);
  const statusOptions = uniqueTextOptions(rows, "onboarding_status");
  const activationStatusOptions = uniqueTextOptions(rows, "activation_status");
  const departmentOptions = uniqueTextOptions(rows, "department_name");
  const jobLevelOptions = uniqueTextOptions(rows, "job_level_name");
  const positionOptions = uniqueTextOptions(rows, "position_name");
  const ownerOptions = uniqueTextOptions(rows, "assigned_owner_name");
  const visibleKpis = asRows(data.kpis).filter((item) => item.enabled !== false);
  const blockerSummary = asRows(data.blocker_summary).filter((item) => item.enabled !== false);
  const priorityActions = asRows(data.priority_actions).filter((item) => item.enabled !== false);
  const exportColumns = ["case_number", "employee_no", "employee_name", "department_name", "job_level_name", "position_name", "location_name", "onboarding_status", "activation_status", "due_date", "planned_start_date"];

  return (
    <div className="space-y-4" data-onboarding-dashboard-kpis>
      {loading ? <CardSkeleton cards={8} label="Loading onboarding KPI cards" /> : null}
      {!loading ? (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-6">
          {visibleKpis.map((kpi) => (
            <Button
              key={String(kpi.id)}
              type="button"
              variant="actionNeutral"
              size="sm"
              className="h-auto w-full flex-col items-stretch justify-start rounded-lg border bg-white p-3 text-left shadow-panel transition hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-primary/40"
              onClick={() => applyOnboardingDashboardQuery(asRow(kpi.query), setFilters)}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-xs font-semibold uppercase tracking-wide text-muted-foreground">{text(kpi.title)}</p>
                  <p className="mt-2 text-2xl font-semibold text-slate-950">{text(kpi.value)}</p>
                </div>
                <span className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md ${kpiTone(kpi.tone) === "success" ? "bg-emerald-50 text-emerald-700" : kpiTone(kpi.tone) === "warning" ? "bg-amber-50 text-amber-700" : kpiTone(kpi.tone) === "danger" ? "bg-red-50 text-red-700" : "bg-cyan-50 text-cyan-700"}`}>
                  <KpiIcon iconKey={kpi.icon_key} />
                </span>
              </div>
              <p className="mt-2 line-clamp-2 text-xs leading-5 text-muted-foreground">{text(kpi.description)}</p>
            </Button>
          ))}
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_320px]">
        <Panel className="p-4" data-onboarding-blocker-readiness-summary>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <h2 className="text-sm font-semibold">Activation Readiness</h2>
              <p className="text-xs text-muted-foreground">Blocked-case summary grouped by setup area.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {Object.entries(asRow(data.readiness_summary)).map(([key, value]) => (
                <Badge key={key} tone={key.includes("ready") ? "success" : key.includes("blocked") ? "danger" : "neutral"}>
                  {title(key)}: {text(value)}
                </Badge>
              ))}
            </div>
          </div>
          <div className="mt-4 grid gap-2 md:grid-cols-2">
            {blockerSummary.map((item) => (
              <Button key={String(item.id)} type="button" variant="actionNeutral" size="sm" className="h-auto w-full justify-start rounded-md border bg-slate-50 px-3 py-2 text-left hover:border-primary/40 hover:bg-white" onClick={() => applyOnboardingDashboardQuery(asRow(item.query), setFilters)}>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm font-medium">{text(item.title)}</span>
                  <Badge tone={Number(item.count ?? 0) > 0 ? "warning" : "neutral"}>{text(item.count)}</Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{text(item.explanation)}</p>
              </Button>
            ))}
          </div>
        </Panel>
        <Panel className="p-4" data-onboarding-priority-actions>
          <h2 className="text-sm font-semibold">Priority Actions</h2>
          <p className="text-xs text-muted-foreground">Jump to the highest-impact onboarding work.</p>
          <div className="mt-3 grid gap-2">
            {priorityActions.length ? priorityActions.map((action) => (
              <ActionTextButton key={String(action.id)} intent={kpiTone(action.tone) === "success" ? "complete" : kpiTone(action.tone) === "danger" ? "warning" : "view"} size="sm" className="justify-start" onClick={() => applyOnboardingDashboardQuery(asRow(action.query), setFilters)}>
                {text(action.title)}
              </ActionTextButton>
            )) : <p className="text-sm text-muted-foreground">No urgent onboarding actions right now.</p>}
          </div>
        </Panel>
      </div>

      <Panel className="overflow-hidden">
        <div className="border-b p-3">
          <StandardFilterBar
            search={<StandardSearchInput value={filters.search} onDebouncedChange={(value) => setFilter("search", value)} placeholder="Search employee, case, department..." />}
            reset={<FilterResetButton onReset={resetFilters} disabled={!filterHasValues(filters)} />}
            saveView={<SaveFilterViewButton storageKey="hrm:onboarding-dashboard-filters" value={filters} onApply={setFilters} />}
            actions={<ExportMenu moduleName="Onboarding cases" rows={filtered} columns={exportColumns} filterSummary={activeChips.map((chip) => `${chip.label}: ${chip.value}`)} />}
          >
            <MoreFiltersSheet title="Onboarding filters" onReset={resetFilters}>
              <FilterSection title="Organization">
                <StandardSelectFilter value={filters.department} onValueChange={(value) => setFilter("department", value)} allLabel="All departments" width="department" options={departmentOptions} />
                <StandardSelectFilter value={filters.jobLevel} onValueChange={(value) => setFilter("jobLevel", value)} allLabel="All job levels" width="jobLevel" options={jobLevelOptions} />
                <StandardSelectFilter value={filters.position} onValueChange={(value) => setFilter("position", value)} allLabel="All positions" width="position" options={positionOptions} />
                <StandardSelectFilter value={filters.owner} onValueChange={(value) => setFilter("owner", value)} allLabel="All HR owners" width="employee" options={ownerOptions} />
              </FilterSection>
              <FilterSection title="Setup blockers">
                <StandardSelectFilter value={filters.blockerType} onValueChange={(value) => setFilter("blockerType", value)} allLabel="All blockers" width="documentType" options={blockerTypeOptions} />
                <StandardSelectFilter value={filters.documentStatus} onValueChange={(value) => setFilter("documentStatus", value)} allLabel="Document setup" width="status" options={setupStatusOptions} />
                {enabledModules.contracts !== false ? <StandardSelectFilter value={filters.contractStatus} onValueChange={(value) => setFilter("contractStatus", value)} allLabel="Contract setup" width="status" options={setupStatusOptions} /> : null}
                {enabledModules.payroll !== false ? <StandardSelectFilter value={filters.payrollStatus} onValueChange={(value) => setFilter("payrollStatus", value)} allLabel="Payroll setup" width="status" options={setupStatusOptions} /> : null}
                <StandardSelectFilter value={filters.userAccountStatus} onValueChange={(value) => setFilter("userAccountStatus", value)} allLabel="User account setup" width="status" options={setupStatusOptions} />
                {enabledModules.approvals !== false ? <StandardSelectFilter value={filters.approvalStatus} onValueChange={(value) => setFilter("approvalStatus", value)} allLabel="Approval status" width="status" options={setupStatusOptions} /> : null}
              </FilterSection>
              <FilterSection title="Dates">
                <StandardDateRangeFilter value={filters.created} onChange={(value) => setFilter("created", value)} label="Created Date Range" />
              </FilterSection>
            </MoreFiltersSheet>
            <StandardSelectFilter value={filters.status} onValueChange={(value) => setFilter("status", value)} allLabel="All statuses" width="status" options={statusOptions} />
            <StandardSelectFilter value={filters.readiness} onValueChange={(value) => setFilter("readiness", value)} allLabel="All readiness" width="status" options={["DRAFT", "IN_PROGRESS", "BLOCKED", "READY", "ACTIVATED"].map((value) => ({ value, label: title(value) }))} />
            <StandardDateRangeFilter value={filters.plannedStart} onChange={(value) => setFilter("plannedStart", value)} label="Planned Start Date Range" />
            <StandardSelectFilter value={filters.activationStatus} onValueChange={(value) => setFilter("activationStatus", value)} allLabel="Activation status" width="status" options={activationStatusOptions} />
          </StandardFilterBar>
          <ActiveFilterChips chips={activeChips} className="mt-2" />
        </div>
        <OnboardingCaseTable rows={filtered} loading={loading} error={error} onSelect={onSelect} />
      </Panel>
    </div>
  );
}

function CasesSection({
  kind,
  cases,
  loading,
  error,
  pagination,
  onCreate,
  onSelect
}: {
  kind: CaseKind;
  cases: (OnboardingCase | OffboardingCase)[];
  loading: boolean;
  error: string | null;
  pagination?: { page: number; pageSize: number; hasMore: boolean; refreshing?: boolean; onPageChange: (page: number) => void; onPageSizeChange: (pageSize: number) => void };
  onCreate: () => void;
  onSelect: (id: string) => void;
}) {
  const rows = cases as unknown as Row[];
  const [filters, setFilters] = useState<OnboardingFilterState>(defaultOnboardingFilters);
  const setFilter = <K extends keyof OnboardingFilterState>(key: K, value: OnboardingFilterState[K]) => setFilters((current) => ({ ...current, [key]: value }));
  const resetFilters = () => setFilters(defaultOnboardingFilters);
  const resetRange = (key: "plannedStart" | "created") => setFilter(key, {});
  const activeChips = onboardingFilterChips(filters, setFilter, resetRange);
  const filtered = kind === "onboarding" ? filterOnboardingRows(rows, filters) : rows;
  if (kind === "onboarding") {
    return (
      <div className="space-y-3">
        <div className="flex justify-end">
          <ActionTextButton intent="create" size="sm" onClick={onCreate}>Create onboarding case</ActionTextButton>
        </div>
        <Panel className="overflow-hidden">
          <div className="border-b p-3">
            <StandardFilterBar
              search={<StandardSearchInput value={filters.search} onDebouncedChange={(value) => setFilter("search", value)} placeholder="Search employee or onboarding case..." />}
              reset={<FilterResetButton onReset={resetFilters} disabled={!filterHasValues(filters)} />}
              saveView={<SaveFilterViewButton storageKey="hrm:onboarding-case-filters" value={filters} onApply={setFilters} />}
            >
              <MoreFiltersSheet title="Onboarding case filters" onReset={resetFilters}>
                <FilterSection title="Organization">
                  <StandardSelectFilter value={filters.department} onValueChange={(value) => setFilter("department", value)} allLabel="All departments" width="department" options={uniqueTextOptions(rows, "department_name")} />
                  <StandardSelectFilter value={filters.jobLevel} onValueChange={(value) => setFilter("jobLevel", value)} allLabel="All job levels" width="jobLevel" options={uniqueTextOptions(rows, "job_level_name")} />
                  <StandardSelectFilter value={filters.position} onValueChange={(value) => setFilter("position", value)} allLabel="All positions" width="position" options={uniqueTextOptions(rows, "position_name")} />
                  <StandardSelectFilter value={filters.owner} onValueChange={(value) => setFilter("owner", value)} allLabel="All HR owners" width="employee" options={uniqueTextOptions(rows, "assigned_owner_name")} />
                </FilterSection>
                <FilterSection title="Setup Readiness">
                  <StandardSelectFilter value={filters.blockerType} onValueChange={(value) => setFilter("blockerType", value)} allLabel="All blockers" width="documentType" options={blockerTypeOptions} />
                  <StandardSelectFilter value={filters.documentStatus} onValueChange={(value) => setFilter("documentStatus", value)} allLabel="Document setup" width="status" options={setupStatusOptions} />
                  <StandardSelectFilter value={filters.contractStatus} onValueChange={(value) => setFilter("contractStatus", value)} allLabel="Contract setup" width="status" options={setupStatusOptions} />
                  <StandardSelectFilter value={filters.payrollStatus} onValueChange={(value) => setFilter("payrollStatus", value)} allLabel="Payroll setup" width="status" options={setupStatusOptions} />
                  <StandardSelectFilter value={filters.userAccountStatus} onValueChange={(value) => setFilter("userAccountStatus", value)} allLabel="User account setup" width="status" options={setupStatusOptions} />
                  <StandardSelectFilter value={filters.approvalStatus} onValueChange={(value) => setFilter("approvalStatus", value)} allLabel="Approval status" width="status" options={setupStatusOptions} />
                </FilterSection>
                <FilterSection title="Dates">
                  <StandardDateRangeFilter value={filters.created} onChange={(value) => setFilter("created", value)} label="Created Date Range" />
                </FilterSection>
              </MoreFiltersSheet>
              <StandardSelectFilter value={filters.status} onValueChange={(value) => setFilter("status", value)} allLabel="All statuses" width="status" options={uniqueTextOptions(rows, "onboarding_status")} />
              <StandardSelectFilter value={filters.readiness} onValueChange={(value) => setFilter("readiness", value)} allLabel="All readiness" width="status" options={["DRAFT", "IN_PROGRESS", "BLOCKED", "READY", "ACTIVATED"].map((value) => ({ value, label: title(value) }))} />
              <StandardDateRangeFilter value={filters.plannedStart} onChange={(value) => setFilter("plannedStart", value)} label="Planned Start Date Range" />
            </StandardFilterBar>
            <ActiveFilterChips chips={activeChips} className="mt-2" />
          </div>
          <OnboardingCaseTable rows={filtered} loading={loading} refreshing={pagination?.refreshing} error={error} onSelect={onSelect} />
          {pagination ? <TablePaginationBar page={pagination.page} pageSize={pagination.pageSize} rowCount={filtered.length} hasMore={pagination.hasMore} onPageChange={pagination.onPageChange} onPageSizeChange={pagination.onPageSizeChange} /> : null}
        </Panel>
      </div>
    );
  }
  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <ActionTextButton intent="create" size="sm" onClick={onCreate}>Create {kind} case</ActionTextButton>
      </div>
      <PerformanceDataTable loading={loading} refreshing={pagination?.refreshing} error={error} empty={!loading && cases.length === 0} rowCount={cases.length} emptyTitle="No lifecycle cases found" emptyDescription="Create a case or adjust filters.">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Case</TableHead><TableHead>Employee</TableHead><TableHead>Department</TableHead><TableHead>Worksite</TableHead><TableHead>Status</TableHead><TableHead>Readiness</TableHead><TableHead>Due</TableHead><TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {cases.map((row) => (
              <TableRow key={row.id}>
                <TableCell className="font-medium">{row.case_number}</TableCell>
                <TableCell><EmployeeIdentityCell employeeId={row.employee_id} employeeName={row.employee_name ?? row.employee_name_snapshot ?? "-"} employeeNumber={row.employee_no ?? row.employee_number_snapshot} departmentName={row.department_name} locationName={row.location_name} size="sm" /></TableCell>
                <TableCell>{row.department_name ?? "-"}</TableCell>
                <TableCell>{row.location_name ?? "-"}</TableCell>
                <TableCell><StatusBadge value={"onboarding_status" in row ? row.onboarding_status : row.offboarding_status} /></TableCell>
                <TableCell><StatusBadge value={"activation_status" in row ? row.activation_status : row.finalization_status} /></TableCell>
                <TableCell>{row.due_date ?? "-"}</TableCell>
                <TableCell><RowActionButton intent="view" size="sm" title="View lifecycle case" onClick={() => onSelect(row.id)}>View</RowActionButton></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </PerformanceDataTable>
      {pagination ? <TablePaginationBar page={pagination.page} pageSize={pagination.pageSize} rowCount={cases.length} hasMore={pagination.hasMore} onPageChange={pagination.onPageChange} onPageSizeChange={pagination.onPageSizeChange} /> : null}
    </div>
  );
}

function OnboardingCaseTable({ rows, loading, refreshing, error, onSelect }: { rows: Row[]; loading: boolean; refreshing?: boolean; error: string | null; onSelect: (id: string) => void }) {
  return (
    <PerformanceDataTable loading={loading} refreshing={refreshing} error={error} empty={!loading && rows.length === 0} rowCount={rows.length} emptyTitle="No onboarding cases found" emptyDescription="Create an onboarding case or adjust filters.">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Case</TableHead><TableHead>Employee</TableHead><TableHead>Department</TableHead><TableHead>Job level</TableHead><TableHead>Position</TableHead><TableHead>Status</TableHead><TableHead>Readiness</TableHead><TableHead>Due</TableHead><TableHead>Setup</TableHead><TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row) => (
              <TableRow key={String(row.id)}>
                <TableCell className="font-medium">{text(row.case_number)}</TableCell>
                <TableCell><EmployeeIdentityCell employeeId={text(row.employee_id)} employeeName={text(row.employee_name ?? row.employee_name_snapshot)} employeeNumber={text(row.employee_no ?? row.employee_number_snapshot)} departmentName={text(row.department_name)} locationName={text(row.location_name)} size="sm" /></TableCell>
                <TableCell>{text(row.department_name)}</TableCell>
                <TableCell>{text(row.job_level_name)}</TableCell>
                <TableCell>{text(row.position_name)}</TableCell>
                <TableCell><StatusBadge value={row.onboarding_status} /></TableCell>
                <TableCell><StatusBadge value={row.activation_status} /></TableCell>
                <TableCell>{text(row.due_date)}</TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {["documents", "contract", "payroll", "user_account"].map((key) => {
                      const value = rowSetupStatus(row, key);
                      if (!value) return null;
                      return <Badge key={key} tone={value === "COMPLETE" ? "success" : value === "NOT_REQUIRED" ? "neutral" : value === "BLOCKED" ? "danger" : "warning"}>{title(key)}: {title(value)}</Badge>;
                    })}
                  </div>
                </TableCell>
                <TableCell className="text-right"><RowActionButton intent="view" size="sm" title="View onboarding case" onClick={() => onSelect(String(row.id))}>View</RowActionButton></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
    </PerformanceDataTable>
  );
}

function SettingsSection({ settings, kind, canManage, loading, error, onSave }: { settings: LifecycleSettings | null; kind: CaseKind; canManage: boolean; loading: boolean; error: string | null; onSave: (input: LifecycleSettings) => Promise<void> }) {
  const [draft, setDraft] = useState<LifecycleSettings | null>(settings);
  useEffect(() => setDraft(settings), [settings]);
  const fields = kind === "onboarding" ? onboardingSettingFields : offboardingSettingFields;
  const enabledField = kind === "onboarding" ? "onboarding_enabled" : "offboarding_enabled";
  if (loading) return <DataTableFrame loading><div /></DataTableFrame>;
  if (error) return <DataTableFrame error={error}><div /></DataTableFrame>;
  if (!draft) return <Panel><EmptyState title="Settings unavailable" /></Panel>;
  const enabled = isEnabled(draft[enabledField]);
  return (
    <Panel className="space-y-4 p-4">
      <ModuleSettingsBody disabled={!enabled}>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {fields.filter((field) => field !== enabledField).map((field) => (
            <CheckboxField
              key={field}
              label={title(field)}
              checked={isEnabled(draft[field])}
              disabled={!canManage || !enabled}
              onChange={(checked) => setDraft({ ...draft, [field]: checked ? 1 : 0 })}
            />
          ))}
        </div>
        <div className="mt-4 flex justify-end">
          <ActionTextButton intent="save" size="sm" disabled={!canManage || !enabled} onClick={() => void onSave(draft)}>Save settings</ActionTextButton>
        </div>
      </ModuleSettingsBody>
    </Panel>
  );
}

function AlertsSection({ alerts, loading, error, onRefresh }: { alerts: Row[]; loading: boolean; error: string | null; onRefresh: () => void }) {
  return (
    <div className="space-y-3">
      <div className="flex justify-end"><ActionTextButton intent="refresh" size="sm" onClick={onRefresh}><ShieldAlert className="h-4 w-4" /> Refresh alerts</ActionTextButton></div>
      <DataTableFrame loading={loading} error={error} empty={!loading && alerts.length === 0}>
        <Table>
          <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Type</TableHead><TableHead>Severity</TableHead><TableHead>Status</TableHead><TableHead>Created</TableHead></TableRow></TableHeader>
          <TableBody>{alerts.map((row) => <TableRow key={String(row.id)}><TableCell><EmployeeIdentityCell employeeId={text(row.employee_id)} employeeName={text(row.employee_name)} employeeNumber={text(row.employee_no ?? row.employee_number_snapshot)} size="sm" /></TableCell><TableCell>{text(row.alert_type)}</TableCell><TableCell><Badge tone="warning">{text(row.severity)}</Badge></TableCell><TableCell><StatusBadge value={row.status} /></TableCell><TableCell>{text(row.created_at)}</TableCell></TableRow>)}</TableBody>
        </Table>
      </DataTableFrame>
    </div>
  );
}

function ReportsSection({ reportKey, setReportKey, rows, loading, error, onExport }: { reportKey: string; setReportKey: (value: string) => void; rows: Row[]; loading: boolean; error: string | null; onExport: () => void }) {
  const columns = useMemo(() => Object.keys(rows[0] ?? {}).slice(0, 8), [rows]);
  return (
    <div className="space-y-3">
      <Panel className="flex flex-col gap-3 p-3 sm:flex-row sm:items-end">
        <div className="max-w-md flex-1">
          <Label>Lifecycle report</Label>
          <SelectField className="mt-1 h-9 w-full rounded-md border bg-white px-3 text-sm" value={reportKey} onChange={(event) => setReportKey(event.target.value)}>
            {reportKeys.map((key) => <option key={key} value={key}>{title(key)}</option>)}
          </SelectField>
        </div>
        <ActionTextButton intent="export" size="sm" onClick={onExport}><FileDown className="h-4 w-4" /> Export CSV</ActionTextButton>
      </Panel>
      <DataTableFrame loading={loading} error={error} empty={!loading && rows.length === 0}>
        <Table>
          <TableHeader><TableRow>{columns.map((column) => <TableHead key={column}>{title(column)}</TableHead>)}</TableRow></TableHeader>
          <TableBody>{rows.map((row, index) => <TableRow key={String(row.id ?? index)}>{columns.map((column) => <TableCell key={column}>{text(row[column])}</TableCell>)}</TableRow>)}</TableBody>
        </Table>
      </DataTableFrame>
    </div>
  );
}

function CreateCaseModal({ kind, employees, organizationRefs, onClose, onCreated }: { kind: CaseKind; employees: Employee[]; organizationRefs: ReturnType<typeof useOrganizationReferences>; onClose: () => void; onCreated: () => void }) {
  const { token } = useAuth();
  const [employeeId, setEmployeeId] = useState(employees[0]?.id ?? "");
  const [lastWorkingDay, setLastWorkingDay] = useState(new Date().toISOString().slice(0, 10));
  const [exitType, setExitType] = useState("RESIGNED");
  const [exitReason, setExitReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const validation = useFormValidation();
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!token) return;
    const issues = [
      ...validateRequiredField(employeeId, "employee_id", "Employee"),
      ...(kind === "offboarding" ? validateRequiredField(exitType, "exit_type", "Exit type") : []),
      ...(kind === "offboarding" ? validateDateField(lastWorkingDay, "last_working_day", "Last working day", { required: true }) : [])
    ];
    validation.setIssues(issues);
    if (issues.some((issue) => issue.severity === "error")) {
      setTimeout(() => focusFirstInvalidField(issues), 0);
      return;
    }
    setError(null);
    try {
      if (kind === "onboarding") await api.createEmployeeOnboardingCase(token, employeeId);
      else await api.createEmployeeOffboardingCase(token, employeeId, { exit_type: exitType, last_working_day: lastWorkingDay, exit_reason: exitReason || null });
      onCreated();
    } catch (err) {
      const issuesFromApi = normalizeValidationIssues(err);
      if (issuesFromApi.length) {
        validation.setIssues(issuesFromApi);
        setTimeout(() => focusFirstInvalidField(issuesFromApi), 0);
      }
      setError(issuesFromApi[0]?.message ?? (err instanceof ApiError ? err.message : "Unable to create lifecycle case."));
    }
  }
  return (
    <Modal title={`Create ${kind} case`} onClose={onClose}>
      <form className="space-y-3" onSubmit={(event) => void submit(event)}>
        <FormErrorSummary issues={validation.issues} />
        <EmployeeCascadeSelect employees={employees} departments={organizationRefs.departments} locations={organizationRefs.locations} jobLevels={organizationRefs.jobLevels} positions={organizationRefs.positions} value={employeeId} onChange={setEmployeeId} />
        <FieldError issues={validation.fieldIssues("employee_id")} />
        {kind === "offboarding" ? (
          <>
            <div><Label>Exit type</Label><SelectField name="exit_type" data-validation-field="exit_type" className="mt-1 h-9 w-full rounded-md border bg-white px-3 text-sm" value={exitType} onChange={(event) => setExitType(event.target.value)}>{["RESIGNED", "TERMINATED", "END_OF_CONTRACT", "ABSCONDED", "RETIRED", "DECEASED", "OTHER"].map((value) => <option key={value} value={value}>{title(value)}</option>)}</SelectField><FieldError issues={validation.fieldIssues("exit_type")} /></div>
            <ValidatedTextField field="last_working_day" label="Last working day" type="date" value={lastWorkingDay} issues={validation.issues} onChange={setLastWorkingDay} />
            <ValidatedTextField field="exit_reason" label="Exit reason" value={exitReason} issues={validation.issues} onChange={setExitReason} />
          </>
        ) : null}
        {error ? <p className="text-sm text-red-600">{error}</p> : null}
        <div className="flex justify-end gap-2"><Button variant="outline" onClick={onClose}>Cancel</Button><ActionTextButton intent="create" type="submit">Create</ActionTextButton></div>
      </form>
    </Modal>
  );
}

function CaseDetailModal({ kind, caseId, onClose, onChanged, askReason }: { kind: CaseKind; caseId: string; onClose: () => void; onChanged: () => void; askReason: (title: string, submit: (reason: string) => Promise<void>) => void }) {
  const { token } = useAuth();
  const [detail, setDetail] = useState<{ case: OnboardingCase | OffboardingCase; checklist: { tasks: LifecycleTask[] }; readiness?: Row } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const onboardingWorkspaceQuery = useResilientWorkspaceQuery<Row>({
    workspaceName: "onboarding-workspace",
    queryKey: (scope) => queryKeys.onboarding.workspace(scope, caseId),
    enabled: kind === "onboarding",
    placeholderData: (previousData) => String(asRow(previousData?.case).id ?? "") === caseId ? previousData : undefined,
    timeoutMs: 12000,
    queryFn: async ({ token, signal, timeoutMs }) => (await api.getOnboardingWorkspace(token, caseId, signal, timeoutMs)).workspace as Row
  });
  const workspace = kind === "onboarding" ? (onboardingWorkspaceQuery.data ?? null) : null;
  const onboardingDetail = workspace ? {
    case: workspace.case as OnboardingCase,
    checklist: workspace.checklist as { tasks: LifecycleTask[] },
    readiness: workspace.readiness as Row
  } : null;
  const activeDetail = kind === "onboarding" ? onboardingDetail : detail;
  const load = useCallback(async () => {
    if (!token) return;
    try {
      setError(null);
      if (kind === "onboarding") {
        await onboardingWorkspaceQuery.refetch();
      } else {
        const data = await api.getOffboardingCase(token, caseId);
        const readiness = (await api.getOffboardingReadiness(token, caseId)).readiness;
        setDetail({ case: data.case, checklist: data.checklist, readiness });
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to load lifecycle case.");
    }
  }, [caseId, kind, onboardingWorkspaceQuery, token]);
  useEffect(() => {
    if (kind === "offboarding") void load();
  }, [token, kind, caseId]);
  async function run(action: () => Promise<unknown>) {
    await action();
    await load();
    onChanged();
  }
  const combinedError = error ?? (onboardingWorkspaceQuery.blockingError ? onboardingWorkspaceQuery.blockingError.message : null);
  const tasks = activeDetail?.checklist?.tasks ?? [];
  const blockers = Array.isArray(activeDetail?.readiness?.blocking_items) ? (activeDetail?.readiness?.blocking_items as unknown[]) : [];
  const warnings = Array.isArray(activeDetail?.readiness?.warning_items) ? (activeDetail?.readiness?.warning_items as unknown[]) : [];
  const offboardingUserAccess = kind === "offboarding" ? asRow(detail?.readiness?.user_access) : {};
  const caseEmployeeId = activeDetail ? String((activeDetail.case as unknown as Row).employee_id ?? "") : "";
  return (
    <Modal title={`${title(kind)} case`} onClose={onClose} wide={kind === "onboarding"} hideHeader={kind === "onboarding"} bodyClassName={kind === "onboarding" ? "min-h-0 flex-1 overflow-hidden p-0" : undefined}>
      {combinedError ? (
        <Panel className="m-4 p-4">
          <EmptyState
            title={onboardingWorkspaceQuery.timedOut ? "Onboarding workspace timed out" : "Lifecycle case unavailable"}
            description={combinedError}
            action={<ActionTextButton intent="refresh" size="sm" onClick={() => void load()}>Retry loading case</ActionTextButton>}
          />
        </Panel>
      ) : null}
      {!activeDetail ? (combinedError ? null : <FormSkeleton fields={6} label="Loading lifecycle case detail" />) : (
        kind === "onboarding" && workspace ? (
          <OnboardingWorkspace
            workspace={workspace}
            caseId={caseId}
            onClose={onClose}
            reload={async () => {
              await load();
              onChanged();
            }}
            run={run}
            askReason={askReason}
            queryState={{
              refreshing: onboardingWorkspaceQuery.refreshing,
              backgroundError: onboardingWorkspaceQuery.backgroundError,
              retry: async () => {
                await load();
              }
            }}
          />
        ) : (
        <div className="space-y-4">
          <div className="grid gap-3 md:grid-cols-3">
            <Info label="Case" value={activeDetail.case.case_number} />
            <Info label="Status" value={"onboarding_status" in activeDetail.case ? activeDetail.case.onboarding_status : activeDetail.case.offboarding_status} />
            <Info label="Readiness" value={"activation_status" in activeDetail.case ? activeDetail.case.activation_status : activeDetail.case.finalization_status} />
          </div>
          <Timeline
            items={[
              { title: "Lifecycle case opened", description: activeDetail.case.case_number, meta: text((activeDetail.case as unknown as Row).created_at) },
              { title: "Current readiness", description: text("activation_status" in activeDetail.case ? activeDetail.case.activation_status : activeDetail.case.finalization_status) },
              { title: "Current workflow status", description: text("onboarding_status" in activeDetail.case ? activeDetail.case.onboarding_status : activeDetail.case.offboarding_status) }
            ]}
          />
          {kind === "onboarding" ? <ContractReadinessPanel contract={activeDetail.readiness?.contract as Row | undefined} /> : null}
          {kind === "offboarding" ? (
            <OffboardingUserAccessPanel
              status={offboardingUserAccess}
              employeeId={caseEmployeeId}
              canDeactivate={Boolean(token && caseEmployeeId && offboardingUserAccess.deactivation_required && offboardingUserAccess.status === "ACTIVE" && !offboardingUserAccess.protected_owner)}
              askReason={askReason}
              onDeactivate={(reason) => run(() => api.deactivateEmployeeUserForExit(token!, caseEmployeeId, { reason }))}
            />
          ) : null}
          <div className="grid gap-3 md:grid-cols-2">
            <Panel className="p-3"><h3 className="text-sm font-semibold">Blocking items</h3><List values={blockers} /></Panel>
            <Panel className="p-3"><h3 className="text-sm font-semibold">Warnings</h3><List values={warnings} /></Panel>
          </div>
          <div className="flex flex-wrap gap-2">
            <ActionTextButton intent="refresh" size="sm" onClick={() => void run(() => kind === "onboarding" ? api.refreshOnboardingTasks(token!, caseId) : api.refreshOffboardingTasks(token!, caseId))}>Refresh tasks</ActionTextButton>
            {kind === "onboarding" ? (
              <>
                <ActionTextButton intent="submit" size="sm" onClick={() => void run(() => api.submitOnboardingActivation(token!, caseId))}>Submit activation</ActionTextButton>
                <ActionTextButton intent="approve" size="sm" onClick={() => void run(() => api.approveOnboardingActivation(token!, caseId))}>Approve activation</ActionTextButton>
                <ActionTextButton intent="confirm" size="sm" onClick={() => void run(() => api.activateOnboardingCase(token!, caseId))}><CheckCircle2 className="h-4 w-4" /> Activate</ActionTextButton>
                <Button size="sm" variant="danger" onClick={() => askReason("Activate with override", (reason) => run(() => api.activateOnboardingCaseWithOverride(token!, caseId, reason)))}>Override activation</Button>
              </>
            ) : (
              <>
                <ActionTextButton intent="submit" size="sm" onClick={() => void run(() => api.submitOffboardingFinalization(token!, caseId))}>Submit finalization</ActionTextButton>
                <ActionTextButton intent="approve" size="sm" onClick={() => void run(() => api.approveOffboardingFinalization(token!, caseId))}>Approve finalization</ActionTextButton>
                <ActionTextButton intent="finalize" size="sm" onClick={() => void run(() => api.finalizeOffboardingCase(token!, caseId))}><CheckCircle2 className="h-4 w-4" /> Finalize exit</ActionTextButton>
                <Button size="sm" variant="danger" onClick={() => askReason("Finalize with override", (reason) => run(() => api.finalizeOffboardingCaseWithOverride(token!, caseId, reason)))}>Override finalization</Button>
              </>
            )}
          </div>
          <DataTableFrame empty={tasks.length === 0}>
            <Table>
              <TableHeader><TableRow><TableHead>Task</TableHead><TableHead>Group</TableHead><TableHead>Status</TableHead><TableHead>Required</TableHead><TableHead>Due</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
              <TableBody>
                {tasks.map((task) => (
                  <TableRow key={task.id}>
                    <TableCell>{task.task_name ?? task.title ?? task.task_key}</TableCell>
                    <TableCell>{task.task_group}</TableCell>
                    <TableCell><StatusBadge value={task.task_status ?? task.status} /></TableCell>
                    <TableCell>{task.is_required || task.required ? "Yes" : "No"}</TableCell>
                    <TableCell>{task.due_date ?? "-"}</TableCell>
                    <TableCell className="space-x-2">
                      <ActionTextButton intent="complete" size="sm" onClick={() => void run(() => kind === "onboarding" ? api.completeOnboardingTask(token!, task.id) : api.completeOffboardingTask(token!, task.id))}>Complete</ActionTextButton>
                      <ActionTextButton intent="waive" size="sm" onClick={() => askReason("Waive task", (reason) => run(() => kind === "onboarding" ? api.waiveOnboardingTask(token!, task.id, reason) : api.waiveOffboardingTask(token!, task.id, reason)))}>Waive</ActionTextButton>
                      <RowActionButton intent="warning" size="sm" title="Reopen" onClick={() => void run(() => kind === "onboarding" ? api.reopenOnboardingTask(token!, task.id) : api.reopenOffboardingTask(token!, task.id))}>Reopen</RowActionButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </DataTableFrame>
        </div>
        )
      )}
    </Modal>
  );
}

function OffboardingUserAccessPanel({
  status,
  employeeId,
  canDeactivate,
  askReason,
  onDeactivate
}: {
  status: Row;
  employeeId: string;
  canDeactivate: boolean;
  askReason: (title: string, submit: (reason: string) => Promise<void>) => void;
  onDeactivate: (reason: string) => Promise<void>;
}) {
  const deactivationStatus = text(status.deactivation_status ?? status.status ?? "NOT_REQUIRED");
  const isReady = Boolean(status.ready);
  return (
    <Panel className="p-3">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h3 className="text-sm font-semibold">System access deactivation</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Linked login access is reviewed during offboarding and deactivated before exit finalization when policy requires it.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge value={deactivationStatus} />
          <Badge tone={isReady ? "success" : "warning"}>{isReady ? "Ready" : "Action needed"}</Badge>
        </div>
      </div>
      <div className="mt-3 grid gap-3 md:grid-cols-4">
        <Info label="Linked user" value={status.name ? `${text(status.name)} (${text(status.email)})` : "No linked user"} />
        <Info label="Login status" value={status.status ?? "-"} />
        <Info label="Invite/reset" value={status.invite_status ?? "-"} />
        <Info label="Policy" value={status.required ? status.auto_deactivation_enabled ? "Auto deactivation" : "Manual deactivation" : "Not required"} />
      </div>
      {status.message ? <p className="mt-3 text-xs text-muted-foreground">{text(status.message)}</p> : null}
      {status.protected_owner ? <p className="mt-3 text-xs font-medium text-red-600">Protected Owner/Super Admin access cannot be disabled from offboarding.</p> : null}
      {employeeId && canDeactivate ? (
        <div className="mt-3 flex justify-end">
          <Button size="sm" variant="danger" onClick={() => askReason("Deactivate linked user access", onDeactivate)}>
            Deactivate linked access
          </Button>
        </div>
      ) : null}
    </Panel>
  );
}

const onboardingWorkspaceTabs = ["Overview", "Employee Info", "Contacts", "Job Assignment", "Documents", "Contract", "Payroll", "Payment & Pension", "Attendance & Roster", "Assets & Uniforms", "User Access"] as const;
type OnboardingWorkspaceTab = (typeof onboardingWorkspaceTabs)[number];

const onboardingWorkspaceSectionTasks: Record<OnboardingWorkspaceTab, string[]> = {
  Overview: [],
  "Employee Info": ["personal_info"],
  Contacts: ["contact_info"],
  "Job Assignment": ["job_assignment"],
  Documents: ["documents"],
  Contract: ["contract"],
  Payroll: ["payroll_profile"],
  "Payment & Pension": ["payment_method", "pension_profile"],
  "Attendance & Roster": ["attendance_biometric"],
  "Assets & Uniforms": ["assets_uniforms"],
  "User Access": ["user_access"]
};

const completedOnboardingTaskStatuses = new Set(["COMPLETED", "WAIVED", "NOT_REQUIRED"]);

const onboardingWorkspaceSectionStateKeys: Record<OnboardingWorkspaceTab, string[]> = {
  Overview: ["checklist", "readiness"],
  "Employee Info": ["checklist", "readiness"],
  Contacts: ["checklist", "readiness"],
  "Job Assignment": ["checklist", "readiness"],
  Documents: ["documents", "document_types", "checklist", "readiness"],
  Contract: ["contracts", "contract_types", "contract_settings", "readiness"],
  Payroll: ["payroll_profile", "readiness"],
  "Payment & Pension": ["payment_methods", "payment_institutions", "pension_profile", "pension_schemes", "readiness"],
  "Attendance & Roster": ["biometric_mappings", "readiness"],
  "Assets & Uniforms": ["asset_assignments", "available_assets", "readiness"],
  "User Access": ["readiness"]
};

function asRow(value: unknown): Row {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Row : {};
}

function asRows(value: unknown): Row[] {
  return Array.isArray(value) ? value as Row[] : [];
}

function boolValue(value: unknown) {
  return value === true || value === 1 || value === "1" || value === "true";
}

function workspaceSectionStatesForTab(states: Row, tab: OnboardingWorkspaceTab): ModuleSectionState[] {
  const rows: ModuleSectionState[] = [];
  for (const key of onboardingWorkspaceSectionStateKeys[tab] ?? []) {
    const state = asRow(states[key]) as ModuleSectionState;
    if (state.status) rows.push({ ...state, section_key: key });
  }
  return rows;
}

function employeeTypeLabel(value: unknown) {
  const raw = text(value);
  return raw === "-" ? "Other" : title(raw);
}

function paymentMethodLabel(value: string) {
  if (value === "BANK_TRANSFER") return "Bank Transfer";
  if (value === "CHEQUE" || value === "CHEQUE_PLACEHOLDER") return "Cheque";
  if (value === "MOBILE_WALLET_PLACEHOLDER") return "Mobile Wallet";
  return title(value);
}

function bankInstitutionLabel(institution: Row) {
  const code = text(institution.code);
  const name = text(institution.name);
  return code && name ? `${code} - ${name}` : name || code;
}

function activeBankInstitutions(rows: Row[]) {
  return rows.filter((institution) => text(institution.type) === "BANK" && text(institution.status) === "ACTIVE" && boolValue(institution.is_active));
}

function isDisabledModule(workspace: Row, key: string) {
  const statuses = asRow(workspace.module_statuses);
  return statuses[key] === false;
}

function getOptionalSectionState(workspace: Row, key: string) {
  return asRow(asRow(workspace.sections).optional_section_states)[key] as Row | undefined;
}

function optionalSectionStatus(workspace: Row, key: string) {
  return String(getOptionalSectionState(workspace, key)?.status ?? "");
}

function optionalSectionUnavailable(workspace: Row, key: string) {
  return ["DISABLED", "NO_PERMISSION", "WARNING"].includes(optionalSectionStatus(workspace, key));
}

function optionalSectionTitle(state: Row | undefined) {
  const status = String(state?.status ?? "");
  if (status === "DISABLED") return "Disabled";
  if (status === "NO_PERMISSION") return "No permission";
  if (status === "NOT_REQUIRED") return "Not required";
  if (status === "WARNING") return "Warning";
  if (status === "STALE") return "Stale";
  if (status === "FAILED") return "Failed";
  if (status === "TIMEOUT") return "Timed out";
  if (status === "DEFERRED") return "Refreshing";
  if (status === "COMPLETE") return "Complete";
  return "Missing";
}

function optionalSectionTone(state: Row | undefined): "neutral" | "success" | "warning" | "danger" | "info" {
  const status = String(state?.status ?? "");
  if (status === "COMPLETE") return "success";
  if (status === "WARNING" || status === "STALE" || status === "TIMEOUT" || status === "DEFERRED") return "warning";
  if (status === "FAILED") return "danger";
  if (status === "NO_PERMISSION") return "danger";
  if (status === "DISABLED" || status === "NOT_REQUIRED") return "neutral";
  return "info";
}

function OptionalSectionStatePanel({ workspace, sectionKey, fallbackTitle }: { workspace: Row; sectionKey: string; fallbackTitle: string }) {
  const state = getOptionalSectionState(workspace, sectionKey);
  return (
    <Panel className="p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-sm font-semibold">{String(state?.label ?? fallbackTitle)}</h3>
        <Badge tone={optionalSectionTone(state)}>{optionalSectionTitle(state)}</Badge>
      </div>
      <EmptyState
        className="mt-3 min-h-32 rounded-md border bg-slate-50"
        title={optionalSectionTitle(state)}
        description={String(state?.message ?? `${fallbackTitle} is not available for this onboarding workspace.`)}
      />
    </Panel>
  );
}

function OptionalSectionNotice({ workspace, sectionKey, fallbackTitle }: { workspace: Row; sectionKey: string; fallbackTitle: string }) {
  const state = getOptionalSectionState(workspace, sectionKey);
  if (!state || String(state.status ?? "") === "COMPLETE" || String(state.status ?? "") === "MISSING") return null;
  return (
    <div className="mt-3 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700">
      <span className="font-semibold">{String(state.label ?? fallbackTitle)}: </span>
      <span>{String(state.message ?? `${fallbackTitle} is not available.`)}</span>
    </div>
  );
}

function taskStatusForKeys(tasks: Row[], keys: string[]) {
  const relevant = tasks.filter((task) => keys.includes(String(task.task_key ?? "")));
  if (!relevant.length) return "Not Required";
  if (relevant.every((task) => completedOnboardingTaskStatuses.has(String(task.task_status ?? task.status)))) return "Complete";
  if (relevant.some((task) => String(task.task_status ?? task.status) === "BLOCKED")) return "Blocked";
  return "Missing";
}

function readinessStatusLabel(value: unknown) {
  const raw = String(value ?? "");
  if (raw === "READY" || raw === "COMPLETE" || raw === "COMPLETED") return "Complete";
  if (raw === "NOT_REQUIRED") return "Not Required";
  if (raw === "DISABLED") return "Disabled";
  if (raw === "NO_PERMISSION") return "No Permission";
  if (raw === "BLOCKED") return "Blocked";
  if (raw === "STALE") return "Stale";
  if (raw === "FAILED") return "Failed";
  if (raw === "WARNING" || raw === "IN_PROGRESS") return "Missing";
  return raw ? title(raw) : "Missing";
}

function readinessPillTone(status: string): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "Complete") return "success";
  if (status === "Blocked" || status === "No Permission") return "danger";
  if (status === "Missing") return "warning";
  if (status === "Not Required" || status === "Disabled") return "neutral";
  return "info";
}

function onboardingReadinessState(rowCase: Row, readiness: Row, tasks: Row[]) {
  if (rowCase.onboarding_status === "ACTIVATED" || rowCase.activation_status === "ACTIVATED") return "Activated";
  if (readiness.can_activate === true) return "Ready for Activation";
  const blockers = asRows(readiness.blocking_items ?? readiness.blockers);
  if (blockers.length) return "Blocked";
  if (tasks.some((task) => !["NOT_STARTED", "PENDING"].includes(String(task.task_status ?? task.status ?? "")))) return "In Progress";
  return "Not Started";
}

function employeeDisplayName(employee: Row) {
  return displayText(employee.full_name ?? employee.display_name ?? employee.name, "Employee");
}

function employeeInitials(employee: Row) {
  const name = employeeDisplayName(employee);
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
  return initials || "E";
}

function employeeProfilePhoto(employee: Row) {
  const value = employee.profile_photo_url ?? employee.profile_photo_preview_url ?? employee.profile_photo;
  return typeof value === "string" && value.trim() ? value : "";
}

function onboardingBlockerTarget(value: unknown): OnboardingWorkspaceTab {
  const message = objectMessage(value).toLowerCase();
  if (/document|passport|visa|permit|license|medical|insurance|photo/.test(message)) return "Documents";
  if (/bank|cash|payment|pension/.test(message)) return "Payment & Pension";
  if (/payroll|salary/.test(message)) return "Payroll";
  if (/department|position|location|job|manager|assignment/.test(message)) return "Job Assignment";
  if (/contract|probation|confirmation/.test(message)) return "Contract";
  if (/asset|uniform/.test(message)) return "Assets & Uniforms";
  if (/user|login|access|self-service|self service/.test(message)) return "User Access";
  if (/phone|email|contact|address/.test(message)) return "Contacts";
  if (/approval|approve/.test(message)) return "Overview";
  return "Overview";
}

function visibleOnboardingBlockers(values: Row[]) {
  return values.filter((value) => {
    const status = String(value.status ?? value.task_status ?? "").toUpperCase();
    const message = objectMessage(value).toLowerCase();
    return !["DISABLED", "NOT_REQUIRED"].includes(status) && !/disabled|not required/.test(message);
  });
}

function onboardingReadinessRows(workspace: Row, readiness: Row, tasks: Row[]) {
  const modules = asRow(workspace.module_statuses);
  return [
    { label: "Employee profile", status: taskStatusForKeys(tasks, ["personal_info", "contact_info"]), tab: "Employee Info" as OnboardingWorkspaceTab },
    { label: "Job assignment", status: taskStatusForKeys(tasks, ["job_assignment"]), tab: "Job Assignment" as OnboardingWorkspaceTab },
    {
      label: "Required documents",
      status: modules.document_compliance === false ? "Not Required" : readinessStatusLabel(asRow(readiness.documents).status ?? taskStatusForKeys(tasks, ["documents"])),
      tab: "Documents" as OnboardingWorkspaceTab
    },
    {
      label: "Payroll/payment setup",
      status: modules.payroll === false ? "Not Required" : asRow(readiness.payroll).ready ? "Complete" : taskStatusForKeys(tasks, ["payroll_profile", "payment_method", "pension_profile"]),
      tab: "Payroll" as OnboardingWorkspaceTab
    },
    {
      label: "Contract setup",
      status: modules.contracts === false ? "Not Required" : readinessStatusLabel(asRow(readiness.contract).status ?? taskStatusForKeys(tasks, ["contract"])),
      tab: "Contract" as OnboardingWorkspaceTab
    },
    {
      label: "User access",
      status: modules.self_service === false ? "Not Required" : asRow(readiness.user_access).ready ? "Complete" : taskStatusForKeys(tasks, ["user_access"]),
      tab: "User Access" as OnboardingWorkspaceTab
    },
    ...(modules.assets_uniforms === false ? [{ label: "Assets & Uniforms", status: "Not Required", tab: "Assets & Uniforms" as OnboardingWorkspaceTab }] : [{ label: "Assets & Uniforms", status: taskStatusForKeys(tasks, ["assets_uniforms"]), tab: "Assets & Uniforms" as OnboardingWorkspaceTab }])
  ];
}

function workspaceContactValue(workspace: Row, matchers: string[], employeeKeys: string[]) {
  const contacts = asRows(asRow(workspace.sections).contacts);
  const contact = contacts.find((item) => matchers.includes(String(item.contact_type ?? item.type ?? "").toUpperCase()));
  const employee = asRow(workspace.employee);
  return contact?.value ?? employeeKeys.map((key) => employee[key]).find((value) => value !== null && value !== undefined && value !== "");
}

function OnboardingEmployeeSummaryRow({ label, value }: { label: string; value: unknown }) {
  const display = displayText(value);
  return (
    <div className="grid min-w-0 grid-cols-[88px_minmax(0,1fr)] gap-2 border-b border-slate-100 py-1.5 last:border-0">
      <span className="text-xs font-medium text-slate-500">{label}</span>
      <span className="min-w-0 truncate text-sm font-medium text-slate-800" title={display}>{display}</span>
    </div>
  );
}

function formatOnboardingModuleLabel(value: string) {
  const key = value.trim().toLowerCase();
  const normalizedKey = key
    .replace(/&/g, "and")
    .replace(/[\s/-]+/g, "_")
    .replace(/_and_/g, "_")
    .replace(/__+/g, "_");
  const labels: Record<string, string> = {
    assets_uniforms: "Assets & Uniforms",
    bank_loans: "Bank loans",
    custom_deductions: "Custom deductions",
    document_compliance: "Document compliance",
    documents: "Documents",
    final_settlement: "Final settlement",
    payment_institutions: "Payment institutions",
    payment_methods: "Payment methods",
    self_service: "Self-service",
    zkteco_attendance: "ZKTeco attendance"
  };
  return labels[normalizedKey] ?? labels[key] ?? normalizedKey.split("_").filter(Boolean).map((part) => part === "zk" || part === "zkteco" ? "ZKTeco" : part.charAt(0).toUpperCase() + part.slice(1)).join(" ");
}

function onboardingStatusCategory(value: unknown) {
  const label = readinessStatusLabel(value);
  if (label === "Complete") return "Complete";
  if (label === "Not Required") return "Not Required";
  if (label === "Disabled") return "Disabled";
  if (label === "Blocked") return "Blocked";
  if (label === "No Permission") return "No Permission";
  return "Missing";
}

function summarizeReadinessRows(rows: Array<{ status: unknown }>) {
  return rows.reduce((summary, row) => {
    const category = onboardingStatusCategory(row.status);
    summary[category] = (summary[category] ?? 0) + 1;
    return summary;
  }, {} as Record<string, number>);
}

function attentionReadinessRows(rows: Array<{ label: string; status: unknown; tab: OnboardingWorkspaceTab }>) {
  return rows.filter((row) => !["Complete", "Not Required", "Disabled"].includes(onboardingStatusCategory(row.status)));
}

function onboardingModuleStateRows(workspace: Row) {
  const moduleRows = Object.entries(asRow(workspace.module_statuses)).map(([key, value]) => ({
    key,
    label: formatOnboardingModuleLabel(key),
    status: value === false ? "Disabled" : "Enabled"
  }));
  const optionalRows = Object.entries(asRow(asRow(workspace.sections).optional_section_states)).map(([key, stateValue]) => {
    const state = asRow(stateValue);
    return {
      key: `optional_${key}`,
      label: formatOnboardingModuleLabel(String(state.label ?? key)),
      status: optionalSectionTitle(state)
    };
  });
  const seen = new Set<string>();
  return [...moduleRows, ...optionalRows]
    .filter((row) => {
      const key = row.label.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => a.label.localeCompare(b.label));
}

function onboardingModuleStateSummary(rows: Array<{ status: string }>) {
  const enabled = rows.filter((row) => row.status === "Enabled" || row.status === "Complete").length;
  const notRequired = rows.filter((row) => row.status === "Not required" || row.status === "Not Required").length;
  const disabled = rows.filter((row) => row.status === "Disabled").length;
  return { enabled, notRequired, disabled };
}

type OnboardingWorkspaceMutationResult = { workspace?: Row } & Record<string, unknown>;

function onboardingActivationReadinessStatus(readiness: Row) {
  const raw = String(readiness.status ?? readiness.readiness_status ?? readiness.refresh_status ?? "").toLowerCase();
  if (raw === "failed") return "failed";
  if (raw === "stale" || boolValue(readiness.is_stale)) return "stale";
  if (raw === "refreshing" || boolValue(readiness.refreshing)) return "refreshing";
  if (raw === "ready" || readiness.can_activate === true) return "ready";
  if (raw === "not_required") return "not_required";
  return "blocked";
}

function readinessAllowsActivation(readiness: Row) {
  return readiness.can_activate === true && onboardingActivationReadinessStatus(readiness) === "ready" && !boolValue(readiness.is_stale) && !boolValue(readiness.refreshing);
}

function readinessRefreshIsActive(readiness: Row, workspaceMeta: Row) {
  const status = onboardingActivationReadinessStatus(readiness);
  return status === "refreshing" || (boolValue(workspaceMeta.refreshing) && status !== "stale" && status !== "failed");
}

function readinessRefreshMessage(readiness: Row) {
  const status = onboardingActivationReadinessStatus(readiness);
  if (status === "ready") return "Ready for activation.";
  if (status === "stale") return String(readiness.refresh_reason ?? "Using last saved readiness. Refresh readiness to confirm activation.");
  if (status === "failed") return String(readiness.failure_message ?? readiness.failed_reason ?? readiness.refresh_reason ?? "Readiness refresh failed. Retry readiness.");
  if (status === "refreshing") return "Refreshing readiness...";
  return "Blocked by onboarding requirements.";
}

function safeReadinessText(value: unknown, fallback: string) {
  const text = typeof value === "string" ? value.replace(/\s+/g, " ").trim() : "";
  if (!text || ["undefined", "null", "[object object]"].includes(text.toLowerCase())) return fallback;
  if (/stack trace|sqlite_|select\s|insert\s|update\s|delete\s|token|password|secret|bank account|document number/i.test(text)) return fallback;
  return text;
}

function readinessFailureDetails(readiness: Row, refresh?: Row | null) {
  const failedSectionLabel = safeReadinessText(
    readiness.failed_section_label ?? refresh?.failed_section_label,
    ""
  );
  const rawMessage = safeReadinessText(
    readiness.error_message ??
    readiness.failure_message ??
    readiness.failed_reason ??
    readiness.refresh_reason ??
    refresh?.error_message ??
    refresh?.last_error_message ??
    refresh?.message,
    failedSectionLabel
      ? `Readiness refresh failed while checking ${failedSectionLabel}.`
      : "Readiness refresh failed before the failed section could be identified."
  );
  const firstSentence = rawMessage.split(/(?<=\.)\s+/)[0]?.trim() || rawMessage;
  const title = failedSectionLabel
    ? `Readiness refresh failed while checking ${failedSectionLabel}.`
    : firstSentence.includes("before the failed section")
      ? firstSentence
      : "Readiness refresh failed before the failed section could be identified.";
  const reason = safeReadinessText(
    readiness.failure_reason ?? readiness.reason ?? refresh?.failure_reason,
    failedSectionLabel
      ? rawMessage.replace(title, "").trim() || `${failedSectionLabel} could not be checked.`
      : "The background readiness job stopped before completion."
  );
  const nextAction = safeReadinessText(
    readiness.next_action ?? refresh?.next_action,
    failedSectionLabel
      ? `Review the ${failedSectionLabel} setup and click Retry readiness.`
      : "Click Retry readiness. If it fails again, share the Job ID and Request ID with support."
  );
  const jobId = safeReadinessText(readiness.job_id ?? readiness.refresh_job_id ?? refresh?.job_id, "");
  const requestId = safeReadinessText(readiness.request_id ?? refresh?.request_id, "");
  const errorCode = safeReadinessText(readiness.error_code ?? readiness.failure_code ?? refresh?.error_code ?? refresh?.last_error_code, "");
  return { title, reason, nextAction, jobId, requestId, errorCode };
}

function readinessFailureMessage(readiness: Row, refresh?: Row | null) {
  const details = readinessFailureDetails(readiness, refresh);
  return `${details.title} Reason: ${details.reason} What to do next: ${details.nextAction}`.replace(/\s+/g, " ").trim();
}

function saveResponseQueuedReadiness(result: OnboardingWorkspaceMutationResult) {
  const refresh = asRow(result.readiness_refresh);
  const status = String(refresh.status ?? "").toLowerCase();
  return ["queued", "already_queued", "running", "refreshing"].includes(status) || boolValue(result.readiness_updating);
}

type ReadinessRefreshTracker = {
  jobId: string | null;
  status: string;
  startedAt: string | null;
  pollAfterMs: number;
  requestId?: string | null;
  errorCode?: string | null;
  lastErrorMessage?: string | null;
  failedSection?: string | null;
  failedSectionLabel?: string | null;
  failureReason?: string | null;
  nextAction?: string | null;
};

function readinessRefreshTrackerFromResult(result: OnboardingWorkspaceMutationResult): ReadinessRefreshTracker | null {
  const refresh = asRow(result.readiness_refresh);
  const activeRefresh = asRow(result.active_refresh);
  const status = String(refresh.status ?? activeRefresh.status ?? "").toLowerCase();
  if (!["queued", "already_queued", "running", "refreshing"].includes(status)) return null;
  return {
    jobId: typeof refresh.job_id === "string" ? refresh.job_id : typeof activeRefresh.job_id === "string" ? activeRefresh.job_id : null,
    status,
    startedAt: typeof refresh.started_at === "string" ? refresh.started_at : typeof activeRefresh.started_at === "string" ? activeRefresh.started_at : null,
    pollAfterMs: Math.max(1000, Math.min(5000, Number(refresh.poll_after_ms ?? 1500) || 1500)),
    requestId: typeof activeRefresh.request_id === "string" ? activeRefresh.request_id : typeof refresh.request_id === "string" ? refresh.request_id : null,
    errorCode: typeof activeRefresh.error_code === "string" ? activeRefresh.error_code : typeof refresh.error_code === "string" ? refresh.error_code : typeof activeRefresh.last_error_code === "string" ? activeRefresh.last_error_code : typeof refresh.last_error_code === "string" ? refresh.last_error_code : null,
    lastErrorMessage: typeof activeRefresh.last_error_message === "string" ? activeRefresh.last_error_message : typeof refresh.last_error_message === "string" ? refresh.last_error_message : null,
    failedSection: typeof activeRefresh.failed_section_key === "string" ? activeRefresh.failed_section_key : typeof activeRefresh.failed_section === "string" ? activeRefresh.failed_section : typeof refresh.failed_section_key === "string" ? refresh.failed_section_key : typeof refresh.failed_section === "string" ? refresh.failed_section : null,
    failedSectionLabel: typeof activeRefresh.failed_section_label === "string" ? activeRefresh.failed_section_label : typeof refresh.failed_section_label === "string" ? refresh.failed_section_label : null,
    failureReason: typeof activeRefresh.failure_reason === "string" ? activeRefresh.failure_reason : typeof refresh.failure_reason === "string" ? refresh.failure_reason : null,
    nextAction: typeof activeRefresh.next_action === "string" ? activeRefresh.next_action : typeof refresh.next_action === "string" ? refresh.next_action : null
  };
}

function isOnboardingSaveTimeoutError(error: unknown): error is ApiError {
  return error instanceof ApiError && error.status === 0 && (error.category === "timeout" || error.code === "REQUEST_ABORTED");
}

function OnboardingWorkspace({ workspace, caseId, onClose, reload, run, askReason, queryState }: { workspace: Row; caseId: string; onClose: () => void; reload: () => Promise<void>; run: (action: () => Promise<unknown>) => Promise<void>; askReason: (title: string, submit: (reason: string) => Promise<void>) => void; queryState?: { refreshing: boolean; backgroundError: Error | null; retry: () => Promise<void> } }) {
  const { token, user } = useAuth();
  const alerts = useAlert();
  const [activeTab, setActiveTab] = useState<OnboardingWorkspaceTab>("Overview");
  const [moreActionsOpen, setMoreActionsOpen] = useState(false);
  const [readinessUpdating, setReadinessUpdating] = useState(false);
  const [readinessPendingConfirmation, setReadinessPendingConfirmation] = useState(false);
  const [readinessQueuedAt, setReadinessQueuedAt] = useState<number | null>(null);
  const [readinessRetrying, setReadinessRetrying] = useState(false);
  const [readinessRefreshJob, setReadinessRefreshJob] = useState<ReadinessRefreshTracker | null>(null);
  const [readinessOverride, setReadinessOverride] = useState<Row | null>(null);
  const scope = useMemo(() => workspaceScope(token, user), [token, user]);
  const workspaceMutation = useWorkspaceMutation<OnboardingWorkspaceMutationResult, { action: () => Promise<unknown>; slices: WorkspaceSlice[] }>({
    mutationFn: async (variables) => variables.action() as Promise<OnboardingWorkspaceMutationResult>,
    applyResult: (result, variables) => {
      applyWorkspacePayload(scope, caseId, result);
      invalidateOnboardingWorkspaceSlices({ scope, caseId, slices: variables.slices });
    }
  });
  function applyReadinessPayload(result: OnboardingWorkspaceMutationResult) {
    const resultWorkspace = asRow(result.workspace);
    const nextReadiness = asRow(result.readiness ?? resultWorkspace.readiness);
    if (!Object.keys(nextReadiness).length) return nextReadiness;
    setReadinessOverride(nextReadiness);
    queryClient.setQueryData(queryKeys.onboarding.workspace(scope, caseId), (current: unknown) => {
      const currentRow = asRow(current);
      if (!Object.keys(currentRow).length) return current;
      const currentMeta = asRow(currentRow.workspace_meta);
      return {
        ...currentRow,
        readiness: nextReadiness,
        workspace_meta: {
          ...currentMeta,
          refreshing: readinessRefreshIsActive(nextReadiness, currentMeta)
        }
      };
    });
    void queryClient.invalidateQueries({ queryKey: queryKeys.onboarding.readiness(scope, caseId) });
    return nextReadiness;
  }
  async function save(action: () => Promise<unknown>, success: string, slices: WorkspaceSlice[]) {
    if (!token) return;
    try {
      const result = await workspaceMutation.mutateAsync({ action, slices });
      const resultWorkspace = asRow(result.workspace);
      const nextReadiness = applyReadinessPayload(result);
      const queuedReadiness = saveResponseQueuedReadiness(result);
      const tracker = readinessRefreshTrackerFromResult(result);
      if (tracker) setReadinessRefreshJob(tracker);
      if (queuedReadiness) {
        setReadinessPendingConfirmation(true);
        setReadinessQueuedAt(Date.now());
      }
      setReadinessUpdating(queuedReadiness || readinessRefreshIsActive(nextReadiness, asRow(resultWorkspace.workspace_meta)));
      alerts.showSuccess(queuedReadiness ? "Saved. Updating readiness..." : success);
      const warning = typeof result.warning === "string" ? result.warning : null;
      if (warning) alerts.showWarning(warning);
    } catch (err) {
      if (isOnboardingSaveTimeoutError(err) && err.requestId) {
        alerts.showWarning("Save timed out. Checking whether your changes were saved...");
        try {
          const status = await api.getOnboardingWorkspaceSaveStatus(token, caseId, { request_id: err.requestId });
          if (status.committed && status.result) {
            const result = status.result as OnboardingWorkspaceMutationResult;
            applyWorkspacePayload(scope, caseId, result);
            invalidateOnboardingWorkspaceSlices({ scope, caseId, slices });
            const resultWorkspace = asRow(result.workspace);
            const nextReadiness = applyReadinessPayload(result);
            const queuedReadiness = saveResponseQueuedReadiness(result);
            const tracker = readinessRefreshTrackerFromResult(result);
            if (tracker) setReadinessRefreshJob(tracker);
            if (queuedReadiness) {
              setReadinessPendingConfirmation(true);
              setReadinessQueuedAt(Date.now());
            }
            setReadinessUpdating(queuedReadiness || readinessRefreshIsActive(nextReadiness, asRow(resultWorkspace.workspace_meta)));
            alerts.showSuccess(queuedReadiness ? "Saved. Updating readiness..." : success);
            const warning = typeof result.warning === "string" ? result.warning : null;
            if (warning) alerts.showWarning(warning);
            return;
          }
          alerts.showWarning("Save status could not be confirmed. Retry or refresh section.");
          return;
        } catch {
          alerts.showWarning("Save status could not be confirmed. Retry or refresh section.");
          return;
        }
      }
      alerts.showApiError(err, "Unable to save onboarding workspace section.");
    }
  }
  async function refreshReadiness(showSuccess = false) {
    if (!token) return;
    if (readinessRetrying || readinessRefreshJob) {
      return;
    }
    setReadinessRetrying(true);
    setReadinessUpdating(true);
    try {
      const result = await workspaceMutation.mutateAsync({
        action: () => api.refreshOnboardingWorkspaceReadiness(token, caseId),
        slices: ["readiness", "document-checklist"]
      });
      const resultWorkspace = asRow(result.workspace);
      const nextReadiness = applyReadinessPayload(result);
      const queuedReadiness = saveResponseQueuedReadiness(result) || boolValue(result.queued);
      const tracker = readinessRefreshTrackerFromResult(result);
      if (tracker) setReadinessRefreshJob(tracker);
      const stillRefreshing = queuedReadiness || readinessRefreshIsActive(nextReadiness, asRow(resultWorkspace.workspace_meta));
      if (queuedReadiness) {
        setReadinessPendingConfirmation(true);
        setReadinessQueuedAt(Date.now());
      }
      setReadinessUpdating(stillRefreshing);
      if (!stillRefreshing) {
        setReadinessPendingConfirmation(false);
        setReadinessQueuedAt(null);
        setReadinessRefreshJob(null);
      }
      if (showSuccess && !stillRefreshing) alerts.showSuccess("Readiness refreshed.");
      else if (queuedReadiness) alerts.showInfo("Readiness refresh started", "Activation stays disabled until readiness is confirmed.");
    } catch (err) {
      setReadinessUpdating(false);
      setReadinessRefreshJob(null);
      alerts.showApiError(err, "Readiness refresh failed. Retry.");
    } finally {
      setReadinessRetrying(false);
    }
  }
  async function saveDocumentBatch(form: FormData) {
    if (!token) return;
    try {
      const result = await api.uploadOnboardingWorkspaceDocumentBatch(token, caseId, form);
      const uploaded = Number(result.uploaded_count ?? 0);
      applyWorkspacePayload(scope, caseId, result as OnboardingWorkspaceMutationResult);
      applyReadinessPayload(result as OnboardingWorkspaceMutationResult);
      invalidateOnboardingWorkspaceSlices({ scope, caseId, slices: ["documents", "document-checklist", "readiness"] });
      const tracker = readinessRefreshTrackerFromResult(result as OnboardingWorkspaceMutationResult);
      if (tracker) setReadinessRefreshJob(tracker);
      setReadinessUpdating(Boolean((result as Record<string, unknown>).readiness_updating ?? true));
      alerts.showSuccess(uploaded === 1 ? "1 document uploaded." : `${uploaded} documents uploaded.`);
      return result;
    } catch (err) {
      alerts.showApiError(err, "Document batch upload failed.");
      throw err;
    }
  }
  async function runWorkspaceAction(action: () => Promise<unknown>, success: string) {
    if (!token) return;
    try {
      await run(action);
      alerts.showSuccess(success);
    } catch (err) {
      alerts.showApiError(err, "Unable to update onboarding case.");
    }
  }
  const rowCase = asRow(workspace.case);
  const employee = asRow(workspace.employee);
  const checklist = asRow(workspace.checklist);
  const readiness = readinessOverride ?? asRow(workspace.readiness);
  const workspaceMeta = asRow(workspace.workspace_meta);
  const optionalSectionStates = asRow(asRow(workspace.sections).optional_section_states);
  const tasks = asRows(checklist.tasks);
  const activationReadinessStatus = onboardingActivationReadinessStatus(readiness);
  const readinessActiveRefresh = readinessRefreshIsActive(readiness, workspaceMeta);
  const readinessNeedsManualRefresh = activationReadinessStatus === "stale" || activationReadinessStatus === "failed" || readinessPendingConfirmation;
  const canActivate = readinessAllowsActivation(readiness);
  const taskByKey = new Map(tasks.map((task) => [String(task.task_key), task]));
  const sectionStatus = (tab: OnboardingWorkspaceTab) => {
    if (tab === "Overview") return canActivate;
    const keys = onboardingWorkspaceSectionTasks[tab];
    if (!keys.length) return false;
    const existingTasks = keys.map((key) => taskByKey.get(key)).filter(Boolean) as Row[];
    return existingTasks.length > 0 && existingTasks.every((task) => completedOnboardingTaskStatuses.has(String(task.task_status ?? task.status)));
  };
  const employeeName = employeeDisplayName(employee);
  const employeeCode = displayText(employee.employee_no ?? employee.employee_code, "No employee code");
  const employeeType = employeeTypeLabel(employee.employee_type);
  const employeeTitle = displayText(employee.position_name ?? employee.job_title ?? employee.designation ?? employee.role_title, "Title not set");
  const employeePhoto = employeeProfilePhoto(employee);
  const phone = workspaceContactValue(workspace, ["PERSONAL_PHONE", "PHONE", "MOBILE", "WORK_PHONE"], ["phone", "mobile", "personal_phone"]);
  const email = workspaceContactValue(workspace, ["PERSONAL_EMAIL", "EMAIL", "WORK_EMAIL"], ["email", "personal_email", "work_email"]);
  const activeSectionComplete = sectionStatus(activeTab);
  const activeSectionStates = workspaceSectionStatesForTab(optionalSectionStates, activeTab);
  const activeSectionIssue = activeSectionStates.find((state) => sectionNeedsRetry(state) || ["NO_PERMISSION", "DISABLED"].includes(String(state?.status ?? "").toUpperCase())) ?? null;
  const activationStatus = String(rowCase.activation_status ?? "");
  const onboardingStatus = String(rowCase.onboarding_status ?? "");
  const activationBadgeLabel = activationStatus ? title(activationStatus) : "Pending";
  const activationBadgeTone: "neutral" | "success" | "warning" | "danger" | "info" = ["ACTIVATED", "APPROVED", "OVERRIDDEN"].includes(activationStatus) ? "success" : activationStatus === "SUBMITTED" ? "info" : activationStatus === "REJECTED" ? "danger" : "warning";
  const approvalRequired = tasks.some((task) => String(task.task_key ?? task.key ?? "").toLowerCase() === "activation_approval" && (task.is_required || task.required)) || ["SUBMITTED", "APPROVED"].includes(activationStatus) || onboardingStatus === "PENDING_APPROVAL";
  const primaryAction = (() => {
    if (["ACTIVATED", "OVERRIDDEN"].includes(activationStatus)) {
      return { label: "Activated", intent: "complete" as const, disabled: true, title: "This employee has already been activated.", run: async () => undefined };
    }
    if (activationStatus === "SUBMITTED") {
      return { label: "Approve activation", intent: "approve" as const, disabled: false, title: "Approve the submitted onboarding activation.", run: () => runWorkspaceAction(() => api.approveOnboardingActivation(token!, caseId), "Activation approved.") };
    }
    if (approvalRequired && activationStatus !== "APPROVED") {
      return { label: "Submit activation", intent: "submit" as const, disabled: !canActivate || readinessUpdating || readinessActiveRefresh || readinessNeedsManualRefresh, title: readinessUpdating || readinessActiveRefresh ? "Readiness is updating after the latest save. Refresh readiness before activation." : readinessNeedsManualRefresh ? "Refresh readiness to confirm activation eligibility." : canActivate ? "Submit onboarding activation for approval." : "Complete required onboarding items before submitting activation.", run: () => runWorkspaceAction(() => api.completeOnboardingWorkspace(token!, caseId), "Activation submitted.") };
    }
    return { label: "Activate Employee", intent: "confirm" as const, disabled: !canActivate || readinessUpdating || readinessActiveRefresh || readinessNeedsManualRefresh, title: readinessUpdating || readinessActiveRefresh ? "Readiness is updating after the latest save. Refresh readiness before activation." : readinessNeedsManualRefresh ? "Refresh readiness to confirm activation eligibility." : canActivate ? "Activate employee." : "Complete required onboarding items before activation.", run: () => runWorkspaceAction(() => api.activateOnboardingCase(token!, caseId), "Employee activated.") };
  })();
  const readinessFailureInfo = activationReadinessStatus === "failed"
    ? readinessFailureDetails(readiness, readinessRefreshJob ? {
        job_id: readinessRefreshJob.jobId,
        request_id: readinessRefreshJob.requestId,
        error_code: readinessRefreshJob.errorCode,
        last_error_message: readinessRefreshJob.lastErrorMessage,
        failed_section: readinessRefreshJob.failedSection,
        failed_section_key: readinessRefreshJob.failedSection,
        failed_section_label: readinessRefreshJob.failedSectionLabel,
        failure_reason: readinessRefreshJob.failureReason,
        next_action: readinessRefreshJob.nextAction
      } : null)
    : null;
  useEffect(() => {
    if (readinessRefreshIsActive(readiness, workspaceMeta)) {
      setReadinessUpdating(true);
    } else if (["ready", "blocked", "stale", "failed", "not_required"].includes(onboardingActivationReadinessStatus(readiness))) {
      setReadinessUpdating(false);
    }
  }, [readiness.can_activate, readiness.is_stale, readiness.readiness_status, readiness.refresh_status, readiness.refreshing, readiness.status, workspaceMeta.refreshing]);
  useEffect(() => {
    if (!readinessUpdating) return;
    const timeout = window.setTimeout(() => setReadinessUpdating(false), 20000);
    return () => window.clearTimeout(timeout);
  }, [readinessUpdating]);
  useEffect(() => {
    if (!readinessPendingConfirmation || !readinessQueuedAt) return;
    const calculatedAt = Date.parse(String(readiness.last_calculated_at ?? readiness.calculated_at ?? ""));
    if (Number.isFinite(calculatedAt) && calculatedAt >= readinessQueuedAt - 1000 && !readinessRefreshIsActive(readiness, workspaceMeta)) {
      setReadinessPendingConfirmation(false);
      setReadinessQueuedAt(null);
    }
  }, [readiness.last_calculated_at, readiness.calculated_at, readiness.refreshing, readiness.status, readiness.readiness_status, readiness.refresh_status, readinessPendingConfirmation, readinessQueuedAt, workspaceMeta.refreshing]);
  useEffect(() => {
    if (!token || !readinessRefreshJob) return;
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      try {
        const result = await api.getOnboardingReadinessStatus(token, caseId, { job_id: readinessRefreshJob.jobId });
        if (cancelled) return;
        const nextReadiness = applyReadinessPayload(result as OnboardingWorkspaceMutationResult);
        const refresh = asRow(result.readiness_refresh);
        const activeRefresh = asRow(result.active_refresh);
        const refreshStatus = String(activeRefresh.status ?? refresh.status ?? result.active_refresh_status ?? readinessRefreshJob.status ?? "").toLowerCase();
        const nextStatus = onboardingActivationReadinessStatus(nextReadiness);
        const displayJobId = typeof activeRefresh.job_id === "string" ? activeRefresh.job_id : typeof refresh.job_id === "string" ? refresh.job_id : readinessRefreshJob.jobId;
        const activeJobIdForPolling = typeof result.active_refresh_job_id === "string" ? result.active_refresh_job_id : null;
        const refreshActive = !["failed", "stale_failed"].includes(refreshStatus) && (["queued", "already_queued", "running", "refreshing"].includes(refreshStatus) || nextStatus === "refreshing" || Boolean(activeJobIdForPolling));
        if (refreshActive) {
          setReadinessUpdating(true);
          setReadinessPendingConfirmation(true);
          setReadinessRefreshJob({
            jobId: displayJobId,
            status: refreshStatus || readinessRefreshJob.status,
            startedAt: typeof refresh.started_at === "string" ? refresh.started_at : typeof activeRefresh.started_at === "string" ? activeRefresh.started_at : readinessRefreshJob.startedAt,
            pollAfterMs: Math.max(1000, Math.min(5000, Number(refresh.poll_after_ms ?? readinessRefreshJob.pollAfterMs) || 1500)),
            requestId: typeof activeRefresh.request_id === "string" ? activeRefresh.request_id : typeof refresh.request_id === "string" ? refresh.request_id : readinessRefreshJob.requestId,
            errorCode: typeof activeRefresh.error_code === "string" ? activeRefresh.error_code : typeof refresh.error_code === "string" ? refresh.error_code : typeof activeRefresh.last_error_code === "string" ? activeRefresh.last_error_code : typeof refresh.last_error_code === "string" ? refresh.last_error_code : null,
            lastErrorMessage: typeof activeRefresh.last_error_message === "string" ? activeRefresh.last_error_message : typeof refresh.last_error_message === "string" ? refresh.last_error_message : null,
            failedSection: typeof activeRefresh.failed_section_key === "string" ? activeRefresh.failed_section_key : typeof activeRefresh.failed_section === "string" ? activeRefresh.failed_section : typeof refresh.failed_section_key === "string" ? refresh.failed_section_key : typeof refresh.failed_section === "string" ? refresh.failed_section : null,
            failedSectionLabel: typeof activeRefresh.failed_section_label === "string" ? activeRefresh.failed_section_label : typeof refresh.failed_section_label === "string" ? refresh.failed_section_label : null,
            failureReason: typeof activeRefresh.failure_reason === "string" ? activeRefresh.failure_reason : typeof refresh.failure_reason === "string" ? refresh.failure_reason : null,
            nextAction: typeof activeRefresh.next_action === "string" ? activeRefresh.next_action : typeof refresh.next_action === "string" ? refresh.next_action : null
          });
          return;
        }
        setReadinessUpdating(false);
        setReadinessPendingConfirmation(false);
        setReadinessQueuedAt(null);
        setReadinessRefreshJob(null);
        invalidateOnboardingWorkspaceSlices({ scope, caseId, slices: ["readiness", "document-checklist"] });
        if (nextStatus === "ready") alerts.showSuccess("Readiness confirmed.");
        else if (nextStatus === "failed") {
          const failureDetails = readinessFailureDetails(nextReadiness, activeRefresh);
          const support = [failureDetails.jobId ? `Job ID: ${failureDetails.jobId}` : "", failureDetails.requestId ? `Request ID: ${failureDetails.requestId}` : ""].filter(Boolean).join(" | ");
          const failureMessage = `${failureDetails.title} Reason: ${failureDetails.reason} What to do next: ${failureDetails.nextAction}${support ? ` Support details: ${support}` : ""}`;
          alerts.showWarning("Readiness refresh failed", failureMessage);
        }
        else if (nextStatus === "blocked") alerts.showInfo("Readiness confirmed", "Some onboarding requirements are still blocking activation.");
      } catch (err) {
        if (cancelled) return;
        setReadinessUpdating(false);
        setReadinessPendingConfirmation(false);
        setReadinessRefreshJob(null);
        alerts.showApiError(err, "Readiness refresh failed. Retry.");
      }
    }, readinessRefreshJob.pollAfterMs);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [token, caseId, readinessRefreshJob, scope, alerts]);
  return (
    <div className="OnboardingEmployeePopupLayout flex h-full min-h-0 flex-col overflow-hidden bg-slate-50" data-onboarding-employee-popup-layout>
      <header className="onboarding-popup-header shrink-0 border-b bg-white px-4 py-3 sm:px-5">
        <div className="flex min-w-0 flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0 max-w-full overflow-hidden">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="min-w-0 max-w-full truncate text-lg font-semibold text-slate-950 sm:text-xl">{employeeName}</h2>
              <Badge tone="info">{employeeType}</Badge>
              <StatusBadge value={rowCase.onboarding_status} />
              <Badge tone={activationBadgeTone}>{activationBadgeLabel}</Badge>
              {queryState?.refreshing || isEnabled(workspaceMeta.refreshing) ? <span className="text-xs font-medium text-sky-700">Refreshing</span> : null}
            </div>
            <div className="mt-1 grid min-w-0 max-w-full gap-x-3 gap-y-1 text-xs text-muted-foreground sm:grid-cols-2 xl:grid-cols-4">
              <span className="min-w-0 truncate" title={employeeCode}>{employeeCode}</span>
              <span className="min-w-0 truncate" title={displayText(employee.joining_date, "Not set")}>Joining {displayText(employee.joining_date, "Not set")}</span>
              <span className="min-w-0 truncate" title={displayText(employee.department_name, "Department not set")}>{displayText(employee.department_name, "Department not set")}</span>
              <span className="min-w-0 truncate" title={employeeTitle}>{employeeTitle}</span>
              {rowCase.owner_name || rowCase.assignee_name ? <span className="min-w-0 truncate" title={displayText(rowCase.owner_name ?? rowCase.assignee_name)}>Owner {displayText(rowCase.owner_name ?? rowCase.assignee_name)}</span> : null}
            </div>
          </div>
          <Button variant="ghost" size="sm" className="shrink-0" onClick={onClose}>Close</Button>
        </div>
      </header>
      <div className="min-h-0 flex-1 overflow-x-hidden overflow-y-auto p-3 sm:p-4">
      <div className="grid min-w-0 max-w-full gap-4 overflow-hidden lg:grid-cols-[240px_minmax(0,1fr)_340px] xl:grid-cols-[260px_minmax(0,1fr)_360px]">
        <aside className="onboarding-setup-navigation-panel order-2 min-w-0 max-w-full overflow-hidden lg:order-1 lg:sticky lg:top-0 lg:max-h-[calc(90vh-9rem)] lg:overflow-y-auto" aria-label="Onboarding setup navigation">
          <nav aria-label="Onboarding setup sections" className="min-w-0 overflow-hidden rounded-lg border bg-white p-2 shadow-panel" data-onboarding-section-sidebar>
            <div className="px-2 pb-2 pt-1">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Setup sections</p>
              <p className="mt-1 text-xs text-muted-foreground">Complete required setup items.</p>
            </div>
            <div className="space-y-1">
              {onboardingWorkspaceTabs.map((tab) => {
                const isActive = activeTab === tab;
                const complete = sectionStatus(tab);
                return (
                  <Button variant="ghost" size="sm" title={tab} key={tab} aria-current={isActive ? "page" : undefined} className={`w-full justify-start rounded-md px-2 text-left ${isActive ? "bg-primary/10 text-primary hover:bg-primary/15" : "text-slate-700"} ${complete ? "font-semibold" : ""}`} onClick={() => setActiveTab(tab)}>
                    {complete ? <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" /> : <Circle className="h-4 w-4 shrink-0 text-slate-300" />}
                    <span className="min-w-0 flex-1 truncate">{tab}</span>
                  </Button>
                );
              })}
            </div>
          </nav>
        </aside>
        <main className="onboarding-main-workspace order-3 min-w-0 max-w-full space-y-4 overflow-hidden lg:order-2" aria-label="Onboarding workspace">
          <Panel className="min-w-0 overflow-hidden p-3">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div className="min-w-0">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Current section</p>
                <h3 className="mt-1 truncate text-base font-semibold text-slate-950">{activeTab}</h3>
                <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">
                  {activeSectionComplete ? "This section has the required setup saved." : "Review and save this section to update setup status."}
                </p>
              </div>
              <Badge tone={activeSectionComplete ? "success" : "warning"}>{activeSectionComplete ? "Complete" : "Needs review"}</Badge>
            </div>
          </Panel>
          {queryState?.backgroundError ? (
            <Panel className="border-amber-200 bg-amber-50 p-3">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-amber-900">Workspace refresh did not finish</p>
                  <p className="mt-1 text-sm text-amber-800">Cached data remains visible. Retry only this onboarding workspace refresh when ready.</p>
                </div>
                <ActionTextButton intent="refresh" size="sm" onClick={() => void queryState.retry()}>Retry</ActionTextButton>
              </div>
            </Panel>
          ) : null}
          {readinessUpdating || readinessPendingConfirmation ? (
            <Panel className="border-sky-200 bg-sky-50 p-3" data-onboarding-readiness-background-refresh>
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-sky-950">{readinessRefreshJob ? "Refreshing readiness..." : readinessUpdating ? "Using last saved readiness. Refreshing in background..." : "Readiness refresh pending"}</p>
                  <p className="mt-1 break-words text-sm text-sky-800">{readinessRefreshJob ? "The workspace remains available while activation readiness is confirmed." : "Your section save is complete. Activation stays disabled until readiness is confirmed."}</p>
                </div>
                <ActionTextButton intent="refresh" size="sm" disabled={readinessRetrying || Boolean(readinessRefreshJob)} onClick={() => void refreshReadiness(false)}>{readinessRefreshJob ? "Refresh running" : "Refresh readiness"}</ActionTextButton>
              </div>
            </Panel>
          ) : null}
          {readinessFailureInfo ? (
            <Panel className="border-red-200 bg-red-50 p-3" data-onboarding-readiness-failure-reason>
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-red-950">{readinessFailureInfo.title}</p>
                  <div className="mt-2 space-y-2 text-sm text-red-800">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-red-700">Reason</p>
                      <p className="break-words">{readinessFailureInfo.reason}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-red-700">What to do next</p>
                      <p className="break-words">{readinessFailureInfo.nextAction}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-red-700">Support details</p>
                      <div className="space-y-1 text-xs text-red-700">
                        <p className="break-all">Job ID: {readinessFailureInfo.jobId || "Not available"}</p>
                        <p className="break-all">Request ID: {readinessFailureInfo.requestId || "Not available"}</p>
                        {readinessFailureInfo.errorCode ? <p className="break-all">Code: {readinessFailureInfo.errorCode}</p> : null}
                      </div>
                    </div>
                  </div>
                </div>
                <ActionTextButton intent="refresh" size="sm" disabled={readinessRetrying || Boolean(readinessRefreshJob)} onClick={() => void refreshReadiness(false)}>
                  {readinessRefreshJob ? "Refresh running" : "Retry readiness"}
                </ActionTextButton>
              </div>
            </Panel>
          ) : null}
          {activeSectionIssue ? (
            <Panel className="border-slate-200 bg-white p-3">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900">{activeSectionIssue.label ?? activeTab}: {sectionStatusLabel(activeSectionIssue)}</p>
                  <p className="mt-1 break-words text-sm text-muted-foreground">{activeSectionIssue.message ?? "This optional section is loading separately. Other onboarding setup remains available."}</p>
                  {String(activeSectionIssue.section_key ?? "") === "readiness" ? <p className="mt-1 break-words text-xs text-slate-600">{readinessRefreshMessage(readiness)}</p> : null}
                </div>
                {sectionNeedsRetry(activeSectionIssue) ? (
                  <ActionTextButton intent="refresh" size="sm" disabled={readinessRetrying || Boolean(readinessRefreshJob)} onClick={() => {
                    if (String(activeSectionIssue.section_key ?? "") === "readiness") void refreshReadiness(false);
                    else void reload();
                  }}>{String(activeSectionIssue.section_key ?? "") === "readiness" ? readinessRefreshJob ? "Refresh running" : "Retry readiness" : "Retry section"}</ActionTextButton>
                ) : null}
              </div>
            </Panel>
          ) : null}
      {activeTab === "Overview" ? <OnboardingWorkspaceOverview readiness={readiness} tasks={tasks} workspace={workspace} /> : null}
      {activeTab === "Employee Info" ? <EmployeeInfoWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.updateOnboardingWorkspaceEmployeeInfo(token!, caseId, input), "Employee information saved.", ["employee-info", "readiness"])} /> : null}
      {activeTab === "Contacts" ? <ContactWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.updateOnboardingWorkspaceContactInfo(token!, caseId, input), "Contact information saved.", ["contacts", "readiness"])} /> : null}
      {activeTab === "Job Assignment" ? <JobAssignmentWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.updateOnboardingWorkspaceJobAssignment(token!, caseId, input), "Job assignment saved.", ["job-assignment", "documents", "document-checklist", "readiness"])} /> : null}
      {activeTab === "Documents" ? <DocumentsWorkspaceForm workspace={workspace} caseId={caseId} token={token} onSave={saveDocumentBatch} onAcceleratedResult={(result) => {
        invalidateOnboardingWorkspaceSlices({ scope, caseId, slices: ["documents", "document-checklist", "readiness"] });
        setReadinessUpdating(Boolean(result.readiness_updating || result.recalculation_status === "queued"));
        alerts.showSuccess(result.completed_count === 1 ? "1 document uploaded. Updating readiness..." : `${result.completed_count} documents uploaded. Updating readiness...`);
      }} /> : null}
      {activeTab === "Contract" ? <ContractWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.createOnboardingWorkspaceContract(token!, caseId, input), "Contract draft created.", ["contract", "readiness"])} /> : null}
      {activeTab === "Payroll" ? <PayrollWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.updateOnboardingWorkspacePayrollProfile(token!, caseId, input), "Payroll profile saved.", ["payroll", "payment-methods", "pension", "readiness"])} /> : null}
      {activeTab === "Payment & Pension" ? <PaymentPensionWorkspaceForm workspace={workspace} onPaymentSave={(input) => save(() => api.createOnboardingWorkspacePaymentMethod(token!, caseId, input), "Payment method saved.", ["payment-methods", "payroll", "pension", "readiness"])} onPensionSave={(input) => save(() => api.updateOnboardingWorkspacePensionProfile(token!, caseId, input), "Pension profile saved.", ["pension", "payroll", "payment-methods", "readiness"])} /> : null}
      {activeTab === "Attendance & Roster" ? <AttendanceRosterWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.createOnboardingWorkspaceBiometricMapping(token!, caseId, input), "Attendance/biometric setup saved.", ["attendance", "readiness"])} /> : null}
      {activeTab === "Assets & Uniforms" ? <AssetsWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.saveOnboardingWorkspaceAssetsUniforms(token!, caseId, input), "Asset/uniform setup saved.", ["assets", "readiness"])} /> : null}
      {activeTab === "User Access" ? <UserAccessWorkspaceForm workspace={workspace} onSave={(input) => save(() => api.saveOnboardingWorkspaceUserAccount(token!, caseId, input), "User access setup saved.", ["user-access", "readiness"])} /> : null}
        </main>
        <aside className="onboarding-employee-info-panel order-1 min-w-0 max-w-full overflow-hidden lg:order-3 lg:sticky lg:top-0 lg:max-h-[calc(90vh-9rem)] lg:overflow-y-auto" aria-label="Employee information" data-onboarding-employee-info-panel>
          <Panel className="min-w-0 overflow-hidden p-3">
            <div className="flex items-start gap-3">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-full border bg-slate-100 text-sm font-semibold text-slate-700">
                {employeePhoto ? <img src={employeePhoto} alt={`${employeeName} profile`} className="h-full w-full object-cover" /> : employeeInitials(employee)}
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-950" title={employeeName}>{employeeName}</p>
                <p className="truncate text-xs text-muted-foreground" title={employeeTitle}>{employeeTitle}</p>
              </div>
            </div>
            <div className="mt-4">
              <OnboardingEmployeeSummaryRow label="Code" value={employeeCode} />
              <OnboardingEmployeeSummaryRow label="Type" value={employeeType} />
              <OnboardingEmployeeSummaryRow label="Department" value={employee.department_name} />
              <OnboardingEmployeeSummaryRow label="Position" value={employee.position_name ?? employee.job_title ?? employee.designation} />
              <OnboardingEmployeeSummaryRow label="Job level" value={employee.job_level_name} />
              <OnboardingEmployeeSummaryRow label="Employment" value={employee.employment_type} />
              <OnboardingEmployeeSummaryRow label="Joining" value={employee.joining_date} />
              <OnboardingEmployeeSummaryRow label="Phone" value={phone} />
              <OnboardingEmployeeSummaryRow label="Email" value={email} />
              <OnboardingEmployeeSummaryRow label="Location" value={employee.location_name ?? employee.primary_location_name} />
            </div>
          </Panel>
        </aside>
      </div>
      </div>
      <footer className="onboarding-popup-footer shrink-0 border-t bg-white px-4 py-3 sm:px-5">
        <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="min-w-0 truncate text-xs text-muted-foreground">Section forms save changes inside the workspace. Use More actions to refresh setup status after saving.</p>
          <div className="flex min-w-0 justify-end gap-2" data-onboarding-footer-visible-actions>
            <Button variant="outline" className="shrink-0" onClick={onClose}>Close</Button>
            <ActionTextButton
              intent={primaryAction.intent}
              size="sm"
              disabled={primaryAction.disabled}
              title={primaryAction.title}
              className="shrink-0"
              onClick={() => void primaryAction.run()}
            >
              <CheckCircle2 className="h-4 w-4" /> {primaryAction.label}
            </ActionTextButton>
            <div className="relative shrink-0">
              <Button variant="outline" size="sm" aria-expanded={moreActionsOpen} onClick={() => setMoreActionsOpen((value) => !value)}>More actions</Button>
              {moreActionsOpen ? (
                <div className="absolute bottom-full right-0 z-20 mb-2 w-56 rounded-md border bg-white p-1.5 shadow-lg">
                  <ActionTextButton intent="refresh" size="sm" className="w-full justify-start" disabled={readinessRetrying || Boolean(readinessRefreshJob)} onClick={() => { setMoreActionsOpen(false); void refreshReadiness(false); }}>{readinessRefreshJob ? "Refresh running" : "Refresh readiness"}</ActionTextButton>
                  <ActionTextButton intent="submit" size="sm" className="w-full justify-start" onClick={() => { setMoreActionsOpen(false); void runWorkspaceAction(() => api.completeOnboardingWorkspace(token!, caseId), "Activation submitted."); }}>Submit activation</ActionTextButton>
                  <ActionTextButton intent="approve" size="sm" className="mt-1 w-full justify-start" onClick={() => { setMoreActionsOpen(false); void runWorkspaceAction(() => api.approveOnboardingActivation(token!, caseId), "Activation approved."); }}>Approve activation</ActionTextButton>
                  <Button size="sm" variant="danger" className="mt-1 w-full justify-start" onClick={() => { setMoreActionsOpen(false); askReason("Activate with override", (reason) => runWorkspaceAction(() => api.activateOnboardingCaseWithOverride(token!, caseId, reason), "Employee activated with override.")); }}>Override activation</Button>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function OnboardingWorkspaceOverview({ readiness, tasks, workspace }: { readiness: Row; tasks: Row[]; workspace: Row }) {
  const rows = onboardingReadinessRows(workspace, readiness, tasks);
  const summary = summarizeReadinessRows(rows);
  const reviewCount = (summary.Missing ?? 0) + (summary.Blocked ?? 0) + (summary["No Permission"] ?? 0);
  const counters = [
    { label: "Completed", value: summary.Complete ?? 0, tone: "success" as const },
    { label: "To review", value: reviewCount, tone: "warning" as const },
    { label: "Not required", value: summary["Not Required"] ?? 0, tone: "neutral" as const },
    { label: "Disabled", value: summary.Disabled ?? 0, tone: "neutral" as const }
  ];
  return (
    <div className="space-y-3">
      <Panel className="min-w-0 overflow-hidden p-4">
        <div className="flex min-w-0 items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="truncate text-sm font-semibold">Workspace overview</h3>
            <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">Use the setup navigation to complete each onboarding section. Section-specific messages appear inside the section that needs action.</p>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 lg:grid-cols-4">
          {counters.map((counter) => (
            <div key={counter.label} className="min-w-0 rounded-md border bg-slate-50 px-3 py-2">
              <p className="truncate text-[11px] font-medium uppercase tracking-wide text-slate-500">{counter.label}</p>
              <p className="mt-1 text-lg font-semibold text-slate-950">{counter.value}</p>
            </div>
          ))}
        </div>
      </Panel>
      <Panel className="min-w-0 overflow-hidden p-4">
        <h3 className="truncate text-sm font-semibold">How to finish onboarding</h3>
        <div className="mt-3 grid gap-2 text-sm text-slate-700 md:grid-cols-2">
          <div className="break-words rounded-md border bg-slate-50 px-3 py-2">Select a setup section from the left navigation.</div>
          <div className="break-words rounded-md border bg-slate-50 px-3 py-2">Save the section form to update the completion tick.</div>
          <div className="break-words rounded-md border bg-slate-50 px-3 py-2">Resolve section-specific messages where they appear.</div>
          <div className="break-words rounded-md border bg-slate-50 px-3 py-2">Use the footer action when activation becomes available.</div>
        </div>
      </Panel>
    </div>
  );
}

function EmployeeInfoWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  const employee = asRow(workspace.employee);
  const [form, setForm] = useState({
    full_name: text(employee.full_name),
    display_name: text(employee.display_name) === "-" ? "" : text(employee.display_name),
    gender: text(employee.gender) === "-" ? "" : text(employee.gender),
    date_of_birth: text(employee.date_of_birth) === "-" ? "" : text(employee.date_of_birth),
    nationality: text(employee.nationality) === "-" ? "" : text(employee.nationality),
    employee_type: text(employee.employee_type) === "-" ? "LOCAL" : text(employee.employee_type),
    employment_type: text(employee.employment_type) === "-" ? "FULL_TIME" : text(employee.employment_type),
    joining_date: text(employee.joining_date) === "-" ? "" : text(employee.joining_date),
    confirmation_date: text(employee.confirmation_date) === "-" ? "" : text(employee.confirmation_date),
    payroll_included: Boolean(employee.payroll_included),
    roster_eligible: Boolean(employee.roster_eligible),
    notes_summary: text(employee.notes_summary) === "-" ? "" : text(employee.notes_summary)
  });
  return (
    <Panel className="p-4">
      <h3 className="text-sm font-semibold">Basic employee information</h3>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <Field label="Full name"><Input value={form.full_name} onChange={(event) => setForm({ ...form, full_name: event.target.value })} /></Field>
        <Field label="Display name"><Input value={form.display_name} onChange={(event) => setForm({ ...form, display_name: event.target.value })} /></Field>
        <Field label="Employee number"><Input value={text(employee.employee_no)} disabled /></Field>
        <Field label="Gender"><Input value={form.gender} onChange={(event) => setForm({ ...form, gender: event.target.value })} /></Field>
        <Field label="Date of birth"><Input type="date" value={form.date_of_birth} onChange={(event) => setForm({ ...form, date_of_birth: event.target.value })} /></Field>
        <Field label="Nationality"><Input value={form.nationality} onChange={(event) => setForm({ ...form, nationality: event.target.value })} /></Field>
        <SelectField label="Employee type" value={form.employee_type} onValueChange={(employee_type) => setForm({ ...form, employee_type })}>{["LOCAL", "FOREIGN", "OTHER"].map((value) => <option key={value} value={value}>{value}</option>)}</SelectField>
        <SelectField label="Employment type" value={form.employment_type} onValueChange={(employment_type) => setForm({ ...form, employment_type })}>{["FULL_TIME", "PART_TIME", "INTERN", "TEMPORARY", "CONTRACT"].map((value) => <option key={value} value={value}>{value}</option>)}</SelectField>
        <Field label="Joined date"><Input type="date" value={form.joining_date} onChange={(event) => setForm({ ...form, joining_date: event.target.value })} /></Field>
        <Field label="Confirmation date"><Input type="date" value={form.confirmation_date} onChange={(event) => setForm({ ...form, confirmation_date: event.target.value })} /></Field>
        <CheckboxField label="Payroll included" checked={form.payroll_included} onChange={(payroll_included) => setForm({ ...form, payroll_included })} />
        <CheckboxField label="Roster eligible" checked={form.roster_eligible} onChange={(roster_eligible) => setForm({ ...form, roster_eligible })} />
        <div className="md:col-span-3"><Field label="Notes"><Input value={form.notes_summary} onChange={(event) => setForm({ ...form, notes_summary: event.target.value })} /></Field></div>
      </div>
      <div className="mt-4 flex justify-end"><ActionTextButton intent="save" size="sm" onClick={() => onSave(form)}>Save employee info</ActionTextButton></div>
    </Panel>
  );
}

function ContactWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  const contacts = asRows(asRow(workspace.sections).contacts);
  const addresses = asRows(asRow(workspace.sections).addresses);
  const findContact = (type: string) => contacts.find((contact) => contact.contact_type === type);
  const currentAddress = addresses.find((address) => address.address_type === "CURRENT");
  const [form, setForm] = useState({
    phone: text(findContact("PERSONAL_PHONE")?.value) === "-" ? "" : text(findContact("PERSONAL_PHONE")?.value),
    personal_email: text(findContact("PERSONAL_EMAIL")?.value) === "-" ? "" : text(findContact("PERSONAL_EMAIL")?.value),
    emergency_contact_value: text(findContact("EMERGENCY")?.value) === "-" ? "" : text(findContact("EMERGENCY")?.value),
    emergency_relationship: text(findContact("EMERGENCY")?.relationship) === "-" ? "" : text(findContact("EMERGENCY")?.relationship),
    address_line: text(currentAddress?.address_line) === "-" ? "" : text(currentAddress?.address_line),
    island_city: text(currentAddress?.island_city) === "-" ? "" : text(currentAddress?.island_city),
    country: text(currentAddress?.country) === "-" ? "" : text(currentAddress?.country)
  });
  return (
    <Panel className="p-4">
      <h3 className="text-sm font-semibold">Contact information</h3>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <Field label="Phone"><Input value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} /></Field>
        <Field label="Personal email"><Input type="email" value={form.personal_email} onChange={(event) => setForm({ ...form, personal_email: event.target.value })} /></Field>
        <Field label="Emergency contact"><Input value={form.emergency_contact_value} onChange={(event) => setForm({ ...form, emergency_contact_value: event.target.value })} /></Field>
        <Field label="Emergency relationship"><Input value={form.emergency_relationship} onChange={(event) => setForm({ ...form, emergency_relationship: event.target.value })} /></Field>
        <Field label="Address"><Input value={form.address_line} onChange={(event) => setForm({ ...form, address_line: event.target.value })} /></Field>
        <Field label="Island / city"><Input value={form.island_city} onChange={(event) => setForm({ ...form, island_city: event.target.value })} /></Field>
        <Field label="Country"><Input value={form.country} onChange={(event) => setForm({ ...form, country: event.target.value })} /></Field>
      </div>
      <div className="mt-4 flex justify-end"><ActionTextButton intent="save" size="sm" onClick={() => onSave(form)}>Save contacts</ActionTextButton></div>
    </Panel>
  );
}

function JobAssignmentWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  const employee = asRow(workspace.employee);
  const refs = asRow(workspace.refs);
  const [form, setForm] = useState({
    primary_location_id: text(employee.primary_location_id) === "-" ? "" : text(employee.primary_location_id),
    primary_department_id: text(employee.primary_department_id) === "-" ? "" : text(employee.primary_department_id),
    job_level_id: text(employee.job_level_id) === "-" ? "" : text(employee.job_level_id),
    primary_position_id: text(employee.primary_position_id) === "-" ? "" : text(employee.primary_position_id),
    reporting_manager_employee_id: text(employee.reporting_manager_employee_id) === "-" ? "" : text(employee.reporting_manager_employee_id),
    employment_type: text(employee.employment_type) === "-" ? "FULL_TIME" : text(employee.employment_type),
    employee_type: text(employee.employee_type) === "-" ? "LOCAL" : text(employee.employee_type)
  });
  return (
    <Panel className="p-4">
      <h3 className="text-sm font-semibold">Job assignment</h3>
      <p className="mt-1 text-xs text-muted-foreground">Uses the existing Department &rarr; Job Level &rarr; Position cascading validation.</p>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <div className="md:col-span-3">
          <OrganizationCascadeSelector
            includeLocation
            departments={asRows(refs.departments) as unknown as OrganizationDepartment[]}
            locations={asRows(refs.locations) as unknown as OrganizationLocation[]}
            jobLevels={asRows(refs.job_levels) as unknown as OrganizationJobLevel[]}
            positions={asRows(refs.positions) as unknown as OrganizationPosition[]}
            value={{ locationId: form.primary_location_id, departmentId: form.primary_department_id, jobLevelId: form.job_level_id, positionId: form.primary_position_id }}
            labels={{ locationId: "Worksite/location", departmentId: "Department", jobLevelId: "Job level", positionId: "Position/designation" }}
            onChange={(next) => setForm({ ...form, primary_location_id: next.locationId ?? "", primary_department_id: next.departmentId ?? "", job_level_id: next.jobLevelId ?? "", primary_position_id: next.positionId ?? "" })}
          />
        </div>
        <SelectField label="Reporting manager" value={form.reporting_manager_employee_id} onValueChange={(reporting_manager_employee_id) => setForm({ ...form, reporting_manager_employee_id })}><option value="">None</option>{asRows(refs.reporting_managers).map((manager) => <option key={String(manager.id)} value={String(manager.id)}>{text(manager.full_name)} ({text(manager.employee_no)})</option>)}</SelectField>
        <SelectField label="Employee type" value={form.employee_type} onValueChange={(employee_type) => setForm({ ...form, employee_type })}>{["LOCAL", "FOREIGN", "OTHER"].map((value) => <option key={value} value={value}>{value}</option>)}</SelectField>
        <SelectField label="Employment type" value={form.employment_type} onValueChange={(employment_type) => setForm({ ...form, employment_type })}>{["FULL_TIME", "PART_TIME", "INTERN", "TEMPORARY", "CONTRACT"].map((value) => <option key={value} value={value}>{value}</option>)}</SelectField>
      </div>
      <div className="mt-4 flex justify-end"><ActionTextButton intent="save" size="sm" onClick={() => onSave(form)}>Save job assignment</ActionTextButton></div>
    </Panel>
  );
}

type DocumentBatchRow = {
  id: string;
  document_type_id: string;
  file: File | null;
  document_number: string;
  issue_date: string;
  expiry_date: string;
  notes: string;
};

type DocumentBatchRowField = "document_type_id" | "file" | "document_number" | "issue_date" | "expiry_date" | "notes" | "row";
type DocumentBatchErrorMap = Record<string, Partial<Record<DocumentBatchRowField, string>>>;

function documentBatchRowId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `document-row-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function createDocumentBatchRow(): DocumentBatchRow {
  return {
    id: documentBatchRowId(),
    document_type_id: "",
    file: null,
    document_number: "",
    issue_date: "",
    expiry_date: "",
    notes: ""
  };
}

function splitDocumentTypeSetting(value: unknown) {
  if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean);
  const raw = String(value ?? "").trim();
  if (!raw || raw === "-") return [];
  if (raw.startsWith("[")) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.map((item) => String(item).trim()).filter(Boolean);
    } catch {
      return raw.split(/[\n,]/).map((item) => item.trim()).filter(Boolean);
    }
  }
  return raw.split(/[\n,]/).map((item) => item.trim()).filter(Boolean);
}

function documentTypeAllowedMimeTypes(type?: Row) {
  const configured = splitDocumentTypeSetting(type?.allowed_mime_types);
  return configured.length ? configured : ["application/pdf", "image/jpeg", "image/png"];
}

function documentTypeAllowedExtensions(type?: Row) {
  return splitDocumentTypeSetting(type?.allowed_file_extensions).map((extension) => extension.startsWith(".") ? extension.toLowerCase() : `.${extension.toLowerCase()}`);
}

function documentTypeMaxFileSizeBytes(type?: Row) {
  const bytes = Number(type?.max_file_size_bytes);
  if (Number.isFinite(bytes) && bytes > 0) return bytes;
  const mb = Number(type?.max_file_size_mb ?? type?.max_size_mb);
  return (Number.isFinite(mb) && mb > 0 ? mb : 10) * 1024 * 1024;
}

function formatFileSize(bytes: number) {
  if (bytes >= 1024 * 1024) return `${Math.round(bytes / (1024 * 1024))} MB`;
  if (bytes >= 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${bytes} bytes`;
}

function documentTypeAccept(type?: Row) {
  return [...documentTypeAllowedMimeTypes(type), ...documentTypeAllowedExtensions(type)].join(",");
}

function mimeAllowed(file: File, type?: Row) {
  const allowed = documentTypeAllowedMimeTypes(type);
  const extensions = documentTypeAllowedExtensions(type);
  const fileName = file.name.toLowerCase();
  const extensionMatch = extensions.length > 0 && extensions.some((extension) => fileName.endsWith(extension));
  if (!file.type) return extensionMatch || allowed.length === 0;
  const mimeMatch = allowed.some((rule) => {
    if (rule === "*" || rule === "*/*") return true;
    if (rule.endsWith("/*")) return file.type.startsWith(rule.slice(0, -1));
    return file.type === rule;
  });
  return mimeMatch || extensionMatch;
}

function documentTypeFileRuleText(type?: Row) {
  const mimeTypes = documentTypeAllowedMimeTypes(type).join(", ");
  const extensions = documentTypeAllowedExtensions(type).join(", ");
  const allowed = extensions ? `${mimeTypes}; extensions ${extensions}` : mimeTypes;
  return `Allowed file types: ${allowed || "Default PDF/JPEG/PNG"} / Max file size: ${formatFileSize(documentTypeMaxFileSizeBytes(type))}.`;
}

function rowFieldError(errors: DocumentBatchErrorMap, rowId: string, field: DocumentBatchRowField) {
  return errors[rowId]?.[field] ?? "";
}

function DocumentsWorkspaceForm({ workspace, caseId, token, onSave, onAcceleratedResult }: { workspace: Row; caseId: string; token?: string | null; onSave: (form: FormData) => Promise<unknown>; onAcceleratedResult: (result: CompleteDocumentUploadsResult) => void }) {
  const refs = asRow(workspace.refs);
  const sections = asRow(workspace.sections);
  const documentTypes = asRows(refs.document_types);
  const documents = asRow(sections.documents);
  const documentWarning = typeof sections.document_type_warning === "string" ? sections.document_type_warning : "";
  const [rows, setRows] = useState<DocumentBatchRow[]>(() => [createDocumentBatchRow()]);
  const [rowErrors, setRowErrors] = useState<DocumentBatchErrorMap>({});
  const [uploading, setUploading] = useState(false);
  const uploadBatch = useDocumentUploadBatch({ token, caseId, onCompleted: onAcceleratedResult });
  const uploadBusy = uploading || uploadBatch.isUploading;
  const employee = asRow(workspace.employee);
  const checklistRows = asRows(documents.rows);
  const typeSpecificRows = checklistRows.filter((row) => text(row.matched_employee_type_rule) !== "-");
  const checklistMessage = typeof documents.message === "string" ? documents.message : "";
  const noRulesMessage = checklistRows.length === 0
    ? "No required document rules are configured for this employee."
    : typeSpecificRows.length === 0
      ? "No employee-type-specific document rule matched. Any-scope document rules still apply."
      : "";

  if (optionalSectionUnavailable(workspace, "documents")) return <OptionalSectionStatePanel workspace={workspace} sectionKey="documents" fallbackTitle="Documents" />;

  function selectedType(row: DocumentBatchRow) {
    return documentTypes.find((type) => String(type.id) === row.document_type_id);
  }
  function requiredNumber(type?: Row) {
    return boolValue(type?.requires_document_number) || boolValue(type?.document_number_required);
  }
  function requiredIssue(type?: Row) {
    return boolValue(type?.requires_issue_date) || boolValue(type?.issue_date_required);
  }
  function requiredExpiry(type?: Row) {
    return boolValue(type?.requires_expiry_date) || boolValue(type?.expiry_required);
  }
  function updateRow(rowId: string, changes: Partial<DocumentBatchRow>) {
    if (uploadBatch.isRowActive(rowId)) return;
    setRows((current) => current.map((row) => row.id === rowId ? { ...row, ...changes } : row));
    setRowErrors((current) => ({ ...current, [rowId]: {} }));
  }
  function addRow() {
    setRows((current) => [...current, createDocumentBatchRow()]);
  }
  function removeRow(rowId: string) {
    if (uploadBatch.isRowActive(rowId) || uploadBatch.rowState(rowId).status === "Uploaded") return;
    setRows((current) => current.length === 1 ? current : current.filter((row) => row.id !== rowId));
    setRowErrors((current) => {
      const next = { ...current };
      delete next[rowId];
      return next;
    });
  }
  function handleFileChange(rowId: string, event: ChangeEvent<HTMLInputElement>) {
    const files = event.target.files;
    if (files && files.length > 1) {
      updateRow(rowId, { file: null });
      setRowErrors((current) => ({ ...current, [rowId]: { ...current[rowId], file: "Upload one file at a time." } }));
      event.currentTarget.value = "";
      return;
    }
    updateRow(rowId, { file: files?.[0] ?? null });
  }
  function matchedScopeLabel(row: Row) {
    const scope = asRow(row.matched_scope);
    const parts = [
      `Employment: ${displayText(scope.employment_type, "Any")}`,
      `Department: ${displayText(scope.department, "Any")}`,
      `Position: ${displayText(scope.position, "Any")}`,
      `Location: ${displayText(scope.location, "Any")}`
    ];
    return parts.join(" / ");
  }
  function validateRows(selectedRows = rows) {
    const nextErrors: DocumentBatchErrorMap = {};
    const singleActiveRows = new Map<string, string[]>();
    selectedRows.forEach((row) => {
      const type = selectedType(row);
      const errors: Partial<Record<DocumentBatchRowField, string>> = {};
      if (!row.document_type_id) errors.document_type_id = "Document type is required.";
      if (!row.file) errors.file = "File is required.";
      if (type && row.file) {
        if (!mimeAllowed(row.file, type)) errors.file = `File type is not allowed. ${documentTypeFileRuleText(type)}`;
        if (row.file.size > documentTypeMaxFileSizeBytes(type)) errors.file = `File is too large. Maximum size is ${formatFileSize(documentTypeMaxFileSizeBytes(type))}.`;
      }
      if (type && requiredNumber(type) && !row.document_number.trim()) errors.document_number = "Document number/reference is required for this document type.";
      if (type && requiredIssue(type) && !row.issue_date) errors.issue_date = "Issue date is required for this document type.";
      if (type && requiredExpiry(type) && !row.expiry_date) errors.expiry_date = "Expiry date is required for this document type.";
      if (row.issue_date && row.expiry_date && row.expiry_date < row.issue_date) errors.expiry_date = "Expiry date cannot be before issue date.";
      if (type && !boolValue(type.allow_multiple_files)) {
        const key = String(type.id);
        singleActiveRows.set(key, [...(singleActiveRows.get(key) ?? []), row.id]);
      }
      if (Object.keys(errors).length) nextErrors[row.id] = errors;
    });
    for (const rowIds of singleActiveRows.values()) {
      if (rowIds.length <= 1) continue;
      for (const rowId of rowIds) {
        nextErrors[rowId] = {
          ...nextErrors[rowId],
          document_type_id: "This document type allows only one active file. Remove duplicate rows or select a type that allows multiple files."
        };
      }
    }
    return nextErrors;
  }
  function serverErrorsForRows(error: unknown, submittedRows = rows) {
    const nextErrors: DocumentBatchErrorMap = {};
    if (!(error instanceof ApiError)) return nextErrors;
    for (const issue of error.validationErrors) {
      const rowIndex = Number(issue.row_index ?? issue.rowIndex ?? 0);
      const field = String(issue.field ?? "row") as DocumentBatchRowField;
      const row = submittedRows[rowIndex];
      if (!row) continue;
      nextErrors[row.id] = {
        ...nextErrors[row.id],
        [field]: String(issue.message ?? error.message)
      };
    }
    for (const [path, messages] of Object.entries(error.fieldErrors)) {
      const match = path.match(/^rows\.(\d+)\.([a-z_]+)$/);
      if (!match) continue;
      const row = submittedRows[Number(match[1])];
      if (!row) continue;
      const field = match[2] as DocumentBatchRowField;
      nextErrors[row.id] = {
        ...nextErrors[row.id],
        [field]: Array.isArray(messages) ? messages[0] : String(messages)
      };
    }
    if (!Object.keys(nextErrors).length && rows[0]) {
      nextErrors[rows[0].id] = { row: error.message };
    }
    return nextErrors;
  }
  function buildBatchForm(batchRows: DocumentBatchRow[]) {
    const form = new FormData();
    form.set("metadata", JSON.stringify(batchRows.map((row) => ({
      row_id: row.id,
      document_type_id: row.document_type_id,
      document_number: row.document_number,
      issue_date: row.issue_date,
      expiry_date: row.expiry_date,
      notes: row.notes
    }))));
    batchRows.forEach((row, index) => {
      if (row.file) form.set(`file_${index}`, row.file);
    });
    return form;
  }
  async function submit(rowIds?: string[]) {
    if (uploadBusy) return;
    const submittedRows = rowIds?.length ? rows.filter((row) => rowIds.includes(row.id)) : rows;
    const nextErrors = validateRows(submittedRows);
    setRowErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    const form = buildBatchForm(submittedRows);
    setUploading(true);
    try {
      await uploadBatch.uploadRows({ rows: submittedRows, fallbackForm: form, fallbackBatchUpload: onSave });
      if (!rowIds?.length) setRows([createDocumentBatchRow()]);
      setRowErrors({});
    } catch (error) {
      setRowErrors(serverErrorsForRows(error, submittedRows));
    } finally {
      setUploading(false);
    }
  }
  return (
    <div className="grid min-w-0 max-w-full gap-4">
      <Panel className="min-w-0 max-w-full overflow-hidden p-4">
        <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <h3 className="text-sm font-semibold">Upload official documents</h3>
            <p className="mt-1 max-w-2xl text-xs text-muted-foreground">Add multiple document rows and upload them together. Each row accepts one file.</p>
          </div>
          <ActionTextButton intent="create" size="sm" className="shrink-0" onClick={addRow} disabled={uploadBusy}>Add document</ActionTextButton>
        </div>
        <OptionalSectionNotice workspace={workspace} sectionKey="document_types" fallbackTitle="Document upload types" />
        {documentWarning ? <p className="mt-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">{documentWarning}</p> : null}
        <div className="mt-3 space-y-3">
          {rows.map((row, index) => {
            const type = selectedType(row);
            const allowsMultiple = boolValue(type?.allow_multiple_files);
            const uploadState = uploadBatch.rowState(row.id);
            const rowActive = uploadBatch.isRowActive(row.id);
            const canRemoveRow = rows.length > 1 && !rowActive && ["Pending", "Failed", "Retry"].includes(uploadState.status);
            return (
              <div key={row.id} className="min-w-0 max-w-full overflow-hidden rounded-lg border border-slate-200 bg-white p-4">
                <div className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">Document {index + 1}</p>
                    {rowFieldError(rowErrors, row.id, "row") ? <p className="text-xs text-red-700">{rowFieldError(rowErrors, row.id, "row")}</p> : null}
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <Badge tone={uploadState.status === "Uploaded" ? "success" : uploadState.status === "Failed" ? "danger" : rowActive ? "info" : "neutral"}>{uploadState.status}</Badge>
                    {uploadState.status === "Failed" ? <ActionTextButton intent="refresh" size="sm" onClick={() => void submit([row.id])}>Retry</ActionTextButton> : null}
                    <ActionTextButton intent="remove" size="sm" disabled={!canRemoveRow} onClick={() => removeRow(row.id)}>Remove</ActionTextButton>
                  </div>
                </div>
                {rowActive || uploadState.status === "Uploaded" || uploadState.status === "Failed" ? (
                  <div className="mt-3 rounded-md border bg-slate-50 p-2">
                    <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
                      <span>{uploadState.message ?? (rowActive ? "Uploading and processing this document row." : uploadState.status)}</span>
                      <span className="shrink-0">{uploadState.progress}%</span>
                    </div>
                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-200">
                      <div className={`h-full rounded-full ${uploadState.status === "Failed" ? "bg-red-500" : uploadState.status === "Uploaded" ? "bg-emerald-500" : "bg-primary"}`} style={{ width: `${Math.max(0, Math.min(100, uploadState.progress))}%` }} />
                    </div>
                  </div>
                ) : null}
                <div className="mt-4 grid min-w-0 max-w-full gap-3 xl:grid-cols-2">
                  <div className="min-w-0">
                    <SelectField label="Document type" required disabled={rowActive} value={row.document_type_id} onValueChange={(document_type_id) => updateRow(row.id, { document_type_id })}>
                      <option value="">Select document type</option>
                      {documentTypes.map((documentType) => <option key={String(documentType.id)} value={String(documentType.id)}>{text(documentType.name)}{documentType.is_sensitive ? " (Sensitive)" : ""}</option>)}
                    </SelectField>
                    {rowFieldError(rowErrors, row.id, "document_type_id") ? <p className="text-xs text-red-700">{rowFieldError(rowErrors, row.id, "document_type_id")}</p> : null}
                  </div>
                  <div className="min-w-0">
                    <Field label="File *">
                      <Input disabled={rowActive} className="max-w-full file:max-w-full" type="file" accept={documentTypeAccept(type)} onChange={(event) => handleFileChange(row.id, event)} />
                      {row.file ? <p className="min-w-0 truncate text-xs text-muted-foreground" title={row.file.name}>{row.file.name} / {formatFileSize(row.file.size)}</p> : null}
                      {rowFieldError(rowErrors, row.id, "file") ? <p className="text-xs text-red-700">{rowFieldError(rowErrors, row.id, "file")}</p> : null}
                    </Field>
                  </div>
                </div>
                <div className="mt-3 grid min-w-0 max-w-full gap-3 xl:grid-cols-3">
                  <div className="min-w-0">
                    <Field label={`Document number/reference${requiredNumber(type) ? " *" : ""}`}>
                      <Input disabled={rowActive} required={requiredNumber(type)} value={row.document_number} onChange={(event) => updateRow(row.id, { document_number: event.target.value })} />
                      {rowFieldError(rowErrors, row.id, "document_number") ? <p className="text-xs text-red-700">{rowFieldError(rowErrors, row.id, "document_number")}</p> : null}
                    </Field>
                  </div>
                  <div className="min-w-0">
                    <Field label={`Issue date${requiredIssue(type) ? " *" : ""}`}>
                      <Input disabled={rowActive} type="date" required={requiredIssue(type)} value={row.issue_date} onChange={(event) => updateRow(row.id, { issue_date: event.target.value })} />
                      {rowFieldError(rowErrors, row.id, "issue_date") ? <p className="text-xs text-red-700">{rowFieldError(rowErrors, row.id, "issue_date")}</p> : null}
                    </Field>
                  </div>
                  <div className="min-w-0">
                    <Field label={`Expiry date${requiredExpiry(type) ? " *" : ""}`}>
                      <Input disabled={rowActive} type="date" required={requiredExpiry(type)} value={row.expiry_date} onChange={(event) => updateRow(row.id, { expiry_date: event.target.value })} />
                      {rowFieldError(rowErrors, row.id, "expiry_date") ? <p className="text-xs text-red-700">{rowFieldError(rowErrors, row.id, "expiry_date")}</p> : null}
                    </Field>
                  </div>
                </div>
                <div className="mt-3 min-w-0">
                  <Field label="Notes"><Input disabled={rowActive} value={row.notes} onChange={(event) => updateRow(row.id, { notes: event.target.value })} /></Field>
                </div>
                {type ? (
                  <div className="mt-3 min-w-0 space-y-1 rounded-md border bg-slate-50 px-3 py-2 text-xs text-muted-foreground">
                    <p className="break-words">{documentTypeFileRuleText(type)}</p>
                    <p className="break-words">{allowsMultiple ? "This document type allows multiple active files; add one row for each file." : "This document type allows only one active file. Uploading another later requires replacing the existing document."}</p>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
        {uploadBatch.readinessUpdating ? <p className="mt-3 rounded-md border border-sky-200 bg-sky-50 px-3 py-2 text-xs text-sky-800">Saved. Updating readiness in the background. Activation stays locked until readiness refreshes.</p> : null}
        <div className="mt-4 flex justify-end">
          <ActionTextButton intent="upload" size="sm" disabled={uploadBusy} onClick={() => void submit()}>
            {uploadBusy ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
            Upload documents
          </ActionTextButton>
        </div>
      </Panel>
      <Panel className="min-w-0 max-w-full overflow-hidden p-4">
        <div className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <h3 className="text-sm font-semibold">Required document checklist</h3>
            <p className="mt-1 text-xs text-muted-foreground">Required documents are based on the employee type, employment type, department, position, and location configured in Document Required Rules.</p>
          </div>
          <Badge tone="info" className="shrink-0">Employee type: {employeeTypeLabel(employee.employee_type)}</Badge>
        </div>
        {checklistMessage ? <p className="mt-3 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-muted-foreground">{checklistMessage}</p> : null}
        {noRulesMessage ? <p className="mt-3 rounded-md border border-sky-200 bg-sky-50 px-3 py-2 text-xs text-sky-800">{noRulesMessage}</p> : null}
        {checklistRows.length === 0 ? (
          <EmptyState
            className="mt-3 min-h-24 rounded-md border bg-slate-50 p-4"
            title="No required document rules are configured for this employee."
            description="Add document rules in Document Settings when this employee should have mandatory onboarding documents."
          />
        ) : (
          <DataTableFrame className="mt-3">
            <Table>
              <TableHeader><TableRow><TableHead>Document</TableHead><TableHead>Status</TableHead><TableHead>Uploaded</TableHead><TableHead>Expiry</TableHead><TableHead>Rule</TableHead><TableHead>Matched scope</TableHead></TableRow></TableHeader>
              <TableBody>{checklistRows.map((row) => <TableRow key={String(row.document_type_id ?? row.id)}><TableCell>{text(row.document_type_name)}</TableCell><TableCell><StatusBadge value={row.requirement_status ?? row.compliance_status} /></TableCell><TableCell>{row.missing ? "Missing" : "Uploaded"}</TableCell><TableCell>{text(asRow(row.document).expiry_date ?? row.expiry_date)}</TableCell><TableCell>{displayText(row.matched_employee_type_label, "Any")}</TableCell><TableCell className="max-w-80 whitespace-normal break-words text-xs text-muted-foreground">{matchedScopeLabel(row)}</TableCell></TableRow>)}</TableBody>
            </Table>
          </DataTableFrame>
        )}
      </Panel>
    </div>
  );
}

function ContractWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  if (optionalSectionUnavailable(workspace, "contracts")) return <OptionalSectionStatePanel workspace={workspace} sectionKey="contracts" fallbackTitle="Contract setup" />;
  if (isDisabledModule(workspace, "contracts")) return <Panel className="p-4"><EmptyState title="Contract not required" description="The Contracts module is disabled, so onboarding will not block on contract setup." /></Panel>;
  const refs = asRow(workspace.refs);
  const types = asRows(refs.contract_types);
  const [form, setForm] = useState({ contract_type_id: "", contract_number: "", contract_title: "", contract_start_date: "", contract_end_date: "", probation_start_date: "", probation_end_date: "", confirmation_due_date: "", notes: "" });
  const selectedType = types.find((type) => String(type.id) === form.contract_type_id);
  const requiresEnd = Boolean(selectedType?.requires_end_date);
  const requiresProbation = Boolean(selectedType?.requires_probation);
  return (
    <Panel className="p-4">
      <h3 className="text-sm font-semibold">Contract setup</h3>
      <OptionalSectionNotice workspace={workspace} sectionKey="contract_types" fallbackTitle="Contract types" />
      <OptionalSectionNotice workspace={workspace} sectionKey="contract_settings" fallbackTitle="Contract settings" />
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <SelectField required label="Contract type" value={form.contract_type_id} onValueChange={(contract_type_id) => setForm({ ...form, contract_type_id })}><option value="">Select type</option>{types.map((type) => <option key={String(type.id)} value={String(type.id)}>{text(type.name)}</option>)}</SelectField>
        <Field label="Contract number"><Input value={form.contract_number} onChange={(event) => setForm({ ...form, contract_number: event.target.value })} placeholder="Auto if blank" /></Field>
        <Field label="Title"><Input value={form.contract_title} onChange={(event) => setForm({ ...form, contract_title: event.target.value })} /></Field>
        <Field label="Start date *"><Input type="date" required value={form.contract_start_date} onChange={(event) => setForm({ ...form, contract_start_date: event.target.value })} /></Field>
        <Field label={`End date${requiresEnd ? " *" : ""}`}><Input type="date" required={requiresEnd} value={form.contract_end_date} onChange={(event) => setForm({ ...form, contract_end_date: event.target.value })} />{!requiresEnd ? <p className="text-xs text-muted-foreground">End date is optional for this contract type.</p> : null}</Field>
        <Field label={`Probation start${requiresProbation ? " *" : ""}`}><Input type="date" required={requiresProbation} value={form.probation_start_date} onChange={(event) => setForm({ ...form, probation_start_date: event.target.value })} /></Field>
        <Field label={`Probation end${requiresProbation ? " *" : ""}`}><Input type="date" required={requiresProbation} value={form.probation_end_date} onChange={(event) => setForm({ ...form, probation_end_date: event.target.value })} /></Field>
        <Field label="Confirmation due"><Input type="date" value={form.confirmation_due_date} onChange={(event) => setForm({ ...form, confirmation_due_date: event.target.value })} /></Field>
        <Field label="Notes"><Input value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} /></Field>
      </div>
      <div className="mt-4 flex justify-end"><ActionTextButton intent="create" size="sm" disabled={!form.contract_type_id || !form.contract_start_date} onClick={() => onSave(form)}>Create contract draft</ActionTextButton></div>
    </Panel>
  );
}

function PayrollWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  if (optionalSectionUnavailable(workspace, "payroll_profile")) return <OptionalSectionStatePanel workspace={workspace} sectionKey="payroll_profile" fallbackTitle="Payroll profile" />;
  if (isDisabledModule(workspace, "payroll")) return <Panel className="p-4"><EmptyState title="Payroll not required" description="Payroll module is disabled, so onboarding will not block on payroll setup." /></Panel>;
  const profile = asRow(asRow(workspace.sections).payroll_profile);
  const [form, setForm] = useState({
    basic_salary: text(profile.basic_salary) === "-" ? "0" : text(profile.basic_salary),
    currency: text(profile.currency) === "-" ? "MVR" : text(profile.currency),
    payment_method: text(profile.payment_method) === "-" ? "CASH" : text(profile.payment_method),
    payroll_included: profile.payroll_included !== 0,
    overtime_eligible: Boolean(profile.overtime_eligible),
    benefits_eligible: Boolean(profile.benefits_eligible),
    advance_eligible: Boolean(profile.advance_eligible),
    missed_day_deduction_enabled: profile.missed_day_deduction_enabled !== 0,
    leave_deduction_enabled: profile.leave_deduction_enabled !== 0,
    daily_rate_mode: text(profile.daily_rate_mode) === "-" ? "FIXED_30_DAYS" : text(profile.daily_rate_mode)
  });
  return (
    <Panel className="p-4">
      <h3 className="text-sm font-semibold">Payroll profile</h3>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <Field label="Basic salary"><Input type="number" min="0" value={form.basic_salary} onChange={(event) => setForm({ ...form, basic_salary: event.target.value })} /></Field>
        <Field label="Currency"><Input value={form.currency} onChange={(event) => setForm({ ...form, currency: event.target.value })} /></Field>
        <SelectField label="Payroll payment mode" value={form.payment_method} onValueChange={(payment_method) => setForm({ ...form, payment_method })}>{["CASH", "BANK_TRANSFER", "CHEQUE", "OTHER"].map((value) => <option key={value} value={value}>{title(value)}</option>)}</SelectField>
        <SelectField label="Daily rate mode" value={form.daily_rate_mode} onValueChange={(daily_rate_mode) => setForm({ ...form, daily_rate_mode })}>{["FIXED_30_DAYS", "CALENDAR_DAYS", "WORKING_DAYS"].map((value) => <option key={value} value={value}>{title(value)}</option>)}</SelectField>
        <CheckboxField label="Payroll included" checked={form.payroll_included} onChange={(payroll_included) => setForm({ ...form, payroll_included })} />
        <CheckboxField label="Overtime eligible" checked={form.overtime_eligible} onChange={(overtime_eligible) => setForm({ ...form, overtime_eligible })} />
        <CheckboxField label="Benefits eligible" checked={form.benefits_eligible} onChange={(benefits_eligible) => setForm({ ...form, benefits_eligible })} />
        <CheckboxField label="Advance eligible" checked={form.advance_eligible} onChange={(advance_eligible) => setForm({ ...form, advance_eligible })} />
        <CheckboxField label="Missed-day deduction" checked={form.missed_day_deduction_enabled} onChange={(missed_day_deduction_enabled) => setForm({ ...form, missed_day_deduction_enabled })} />
        <CheckboxField label="Leave deduction" checked={form.leave_deduction_enabled} onChange={(leave_deduction_enabled) => setForm({ ...form, leave_deduction_enabled })} />
      </div>
      <div className="mt-4 flex justify-end"><ActionTextButton intent="save" size="sm" onClick={() => onSave({ ...form, basic_salary: Number(form.basic_salary) })}>Save payroll profile</ActionTextButton></div>
    </Panel>
  );
}

function PaymentPensionWorkspaceForm({ workspace, onPaymentSave, onPensionSave }: { workspace: Row; onPaymentSave: (input: Row) => void; onPensionSave: (input: Row) => void }) {
  const refs = asRow(workspace.refs);
  const sections = asRow(workspace.sections);
  const payrollReadiness = asRow(asRow(workspace.readiness).payroll);
  const payrollChildren = asRow(payrollReadiness.children);
  const paymentReasons = asRows(payrollReadiness.blockers).map(objectMessage).filter(Boolean);
  const existingPayment = asRows(sections.payment_methods).find((method) => boolValue(method.is_primary)) ?? asRows(sections.payment_methods)[0] ?? {};
  const activeBanks = activeBankInstitutions(asRows(refs.payment_institutions));
  const paymentInstitutionsDisabled = isDisabledModule(workspace, "payment_institutions") || getOptionalSectionState(workspace, "payment_institutions")?.status === "DISABLED";
  const [payment, setPayment] = useState({
    payment_method_type: text(existingPayment.payment_method_type) === "-" ? "CASH" : text(existingPayment.payment_method_type) || "CASH",
    payment_institution_id: text(existingPayment.payment_institution_id) === "-" ? "" : text(existingPayment.payment_institution_id),
    bank_account_name: text(existingPayment.bank_account_name) === "-" ? "" : text(existingPayment.bank_account_name),
    bank_account_number: "",
    currency: text(existingPayment.currency) === "-" ? "MVR" : text(existingPayment.currency) || "MVR",
    is_primary: true,
    notes: ""
  });
  const [paymentErrors, setPaymentErrors] = useState<Record<string, string>>({});
  const pensionProfile = asRow(sections.pension_profile);
  const [pension, setPension] = useState({ pension_scheme_id: text(pensionProfile.pension_scheme_id) === "-" ? "" : text(pensionProfile.pension_scheme_id), enrollment_status: text(pensionProfile.enrollment_status) === "-" ? "ENROLLED" : text(pensionProfile.enrollment_status), pension_member_id: "", registration_number: "", effective_date: new Date().toISOString().slice(0, 10), notes: "" });
  const isBankTransfer = payment.payment_method_type === "BANK_TRANSFER";
  function changePaymentMethod(payment_method_type: string) {
    const normalized = payment_method_type === "CHEQUE" ? "CHEQUE_PLACEHOLDER" : payment_method_type;
    setPaymentErrors({});
    setPayment({
      ...payment,
      payment_method_type: normalized,
      payment_institution_id: normalized === "BANK_TRANSFER" ? payment.payment_institution_id : "",
      bank_account_name: normalized === "BANK_TRANSFER" ? payment.bank_account_name : "",
      bank_account_number: normalized === "BANK_TRANSFER" ? payment.bank_account_number : ""
    });
  }
  function savePaymentMethod() {
    const nextErrors: Record<string, string> = {};
    if (!payment.payment_method_type) nextErrors.payment_method_type = "Payment method is required.";
    if (isBankTransfer && paymentInstitutionsDisabled) nextErrors.payment_institution_id = "Payment Institutions module is disabled. Bank Transfer cannot be completed until it is enabled or payment method is changed to Cash.";
    else if (isBankTransfer && !payment.payment_institution_id) nextErrors.payment_institution_id = "Bank is required for Bank Transfer.";
    if (isBankTransfer && !payment.bank_account_name.trim()) nextErrors.bank_account_name = "Account name is required for Bank Transfer.";
    if (isBankTransfer && !payment.bank_account_number.trim()) nextErrors.bank_account_number = "Account number is required for Bank Transfer.";
    setPaymentErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    onPaymentSave(isBankTransfer ? payment : { ...payment, payment_institution_id: "", bank_account_name: "", bank_account_number: "" });
  }
  return (
    <div className="grid gap-3 lg:grid-cols-2">
      <Panel className="p-4">
        <h3 className="text-sm font-semibold">Payment method</h3>
        {paymentReasons.length ? <div className="mt-3 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">{paymentReasons[0]}</div> : null}
        {String(asRow(payrollChildren.payment_institution).status ?? "") === "NOT_REQUIRED" ? <div className="mt-3 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-muted-foreground">{String(asRow(payrollChildren.payment_institution).message ?? "Payment institution is not required for Cash payment.")}</div> : null}
        {optionalSectionUnavailable(workspace, "payment_methods") ? <EmptyState title={optionalSectionTitle(getOptionalSectionState(workspace, "payment_methods"))} description={String(getOptionalSectionState(workspace, "payment_methods")?.message ?? "Payment methods are not available.")} /> : isDisabledModule(workspace, "payment_methods") ? <EmptyState title="Payment method not required" description="Payment methods are disabled." /> : (
          <>
            <OptionalSectionNotice workspace={workspace} sectionKey="payment_institutions" fallbackTitle="Payroll payment institutions" />
            <div className="mt-3 grid gap-3">
              <SelectField label="Method" value={payment.payment_method_type} onValueChange={changePaymentMethod}>{["CASH", "BANK_TRANSFER", "CHEQUE_PLACEHOLDER", "MOBILE_WALLET_PLACEHOLDER", "OTHER"].map((value) => <option key={value} value={value}>{paymentMethodLabel(value)}</option>)}</SelectField>
              {paymentErrors.payment_method_type ? <p className="text-xs text-red-600">{paymentErrors.payment_method_type}</p> : null}
              {payment.payment_method_type === "CASH" ? <p className="rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-muted-foreground">Payment institution is not required for Cash payment. Cash payment does not require bank details.</p> : null}
              {isBankTransfer ? <p className="rounded-md border border-sky-200 bg-sky-50 px-3 py-2 text-xs text-sky-800">{paymentInstitutionsDisabled ? "Payment Institutions module is disabled. Bank Transfer cannot be completed until it is enabled or payment method is changed to Cash." : "Bank transfer requires bank, account name, and account number. Bank is required for Bank Transfer. Account name is required for Bank Transfer. Account number is required for Bank Transfer."}</p> : null}
              {isBankTransfer ? <Field label="Bank *"><SelectField value={payment.payment_institution_id} onValueChange={(payment_institution_id) => { setPayment({ ...payment, payment_institution_id }); setPaymentErrors({ ...paymentErrors, payment_institution_id: "" }); }}><option value="">Select active bank</option>{activeBanks.map((institution) => <option key={String(institution.id)} value={String(institution.id)}>{bankInstitutionLabel(institution)}</option>)}</SelectField>{paymentErrors.payment_institution_id ? <p className="text-xs text-red-600">{paymentErrors.payment_institution_id}</p> : null}</Field> : null}
              {isBankTransfer ? <Field label="Account name *"><Input value={payment.bank_account_name} onChange={(event) => { setPayment({ ...payment, bank_account_name: event.target.value }); setPaymentErrors({ ...paymentErrors, bank_account_name: "" }); }} />{paymentErrors.bank_account_name ? <p className="text-xs text-red-600">{paymentErrors.bank_account_name}</p> : null}</Field> : null}
              {isBankTransfer ? <Field label="Account number *"><Input value={payment.bank_account_number} onChange={(event) => { setPayment({ ...payment, bank_account_number: event.target.value }); setPaymentErrors({ ...paymentErrors, bank_account_number: "" }); }} />{paymentErrors.bank_account_number ? <p className="text-xs text-red-600">{paymentErrors.bank_account_number}</p> : null}</Field> : null}
              <Field label="Currency"><Input value={payment.currency} onChange={(event) => setPayment({ ...payment, currency: event.target.value })} /></Field>
            </div>
            <div className="mt-4 flex justify-end"><ActionTextButton intent="save" size="sm" onClick={savePaymentMethod}>Save payment method</ActionTextButton></div>
          </>
        )}
      </Panel>
      <Panel className="p-4">
        <h3 className="text-sm font-semibold">Pension profile</h3>
        {String(asRow(payrollChildren.pension).status ?? "") === "NOT_REQUIRED" ? <div className="mt-3 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-muted-foreground">{String(asRow(payrollChildren.pension).message ?? "Pension setup is not required because Pension is disabled.")}</div> : null}
        {optionalSectionUnavailable(workspace, "pension_profile") ? <EmptyState title={optionalSectionTitle(getOptionalSectionState(workspace, "pension_profile"))} description={String(getOptionalSectionState(workspace, "pension_profile")?.message ?? "Pension profile is not available.")} /> : isDisabledModule(workspace, "pension") ? <EmptyState title="Pension not required" description="Pension module is disabled." /> : (
          <>
            <OptionalSectionNotice workspace={workspace} sectionKey="pension_schemes" fallbackTitle="Pension schemes" />
            <div className="mt-3 grid gap-3">
              <SelectField label="Pension scheme" value={pension.pension_scheme_id} onValueChange={(pension_scheme_id) => setPension({ ...pension, pension_scheme_id })}><option value="">None / exempted</option>{asRows(refs.pension_schemes).map((scheme) => <option key={String(scheme.id)} value={String(scheme.id)}>{text(scheme.scheme_name)}</option>)}</SelectField>
              <SelectField label="Enrollment status" value={pension.enrollment_status} onValueChange={(enrollment_status) => setPension({ ...pension, enrollment_status })}>{["ENROLLED", "EXEMPTED", "VOLUNTARY", "NOT_ENROLLED", "SUSPENDED"].map((value) => <option key={value} value={value}>{title(value)}</option>)}</SelectField>
              <Field label="Member ID"><Input value={pension.pension_member_id} onChange={(event) => setPension({ ...pension, pension_member_id: event.target.value })} /></Field>
              <Field label="Registration number"><Input value={pension.registration_number} onChange={(event) => setPension({ ...pension, registration_number: event.target.value })} /></Field>
              <Field label="Effective date"><Input type="date" value={pension.effective_date} onChange={(event) => setPension({ ...pension, effective_date: event.target.value })} /></Field>
            </div>
            <div className="mt-4 flex justify-end"><ActionTextButton intent="save" size="sm" onClick={() => onPensionSave(pension)}>Save pension profile</ActionTextButton></div>
          </>
        )}
      </Panel>
    </div>
  );
}

function AttendanceRosterWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  const employee = asRow(workspace.employee);
  const [form, setForm] = useState({ biometric_user_id: "", biometric_user_name: "", external_employee_code: text(employee.employee_no), not_required: false, reason: "" });
  return (
    <div className="grid gap-3 lg:grid-cols-2">
      <Panel className="p-4">
        <h3 className="text-sm font-semibold">Attendance / biometric</h3>
        {optionalSectionUnavailable(workspace, "biometric_mappings") ? <EmptyState title={optionalSectionTitle(getOptionalSectionState(workspace, "biometric_mappings"))} description={String(getOptionalSectionState(workspace, "biometric_mappings")?.message ?? "Biometric attendance setup is not available.")} /> : isDisabledModule(workspace, "attendance") ? <EmptyState title="Attendance not required" description="Attendance module is disabled." /> : (
          <div className="mt-3 grid gap-3">
            <Field label="Biometric user ID"><Input value={form.biometric_user_id} onChange={(event) => setForm({ ...form, biometric_user_id: event.target.value })} /></Field>
            <Field label="Biometric user name"><Input value={form.biometric_user_name} onChange={(event) => setForm({ ...form, biometric_user_name: event.target.value })} /></Field>
            <Field label="External employee code"><Input value={form.external_employee_code} onChange={(event) => setForm({ ...form, external_employee_code: event.target.value })} /></Field>
            <CheckboxField label="Biometric mapping not required" checked={form.not_required} onChange={(not_required) => setForm({ ...form, not_required })} />
            {form.not_required ? <Field label="Reason"><Input value={form.reason} onChange={(event) => setForm({ ...form, reason: event.target.value })} /></Field> : null}
            <div className="flex justify-end"><ActionTextButton intent="save" size="sm" onClick={() => onSave(form)}>Save attendance setup</ActionTextButton></div>
          </div>
        )}
      </Panel>
      <Panel className="p-4">
        <h3 className="text-sm font-semibold">Roster readiness</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Info label="Roster eligible" value={employee.roster_eligible ? "Yes" : "No"} />
          <Info label="Worksite/location" value={employee.location_name ?? "Not set"} />
        </div>
        <p className="mt-3 text-sm text-muted-foreground">Roster assignment remains managed by the roster module after worksite and roster eligibility are ready.</p>
      </Panel>
    </div>
  );
}

function AssetsWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  if (optionalSectionUnavailable(workspace, "asset_assignments")) return <OptionalSectionStatePanel workspace={workspace} sectionKey="asset_assignments" fallbackTitle="Assets and uniforms" />;
  const refs = asRow(workspace.refs);
  const [form, setForm] = useState({ asset_item_id: "", issued_date: new Date().toISOString().slice(0, 10), expected_return_date: "", notes: "", not_required: false, waived: false, reason: "" });
  if (isDisabledModule(workspace, "assets_uniforms")) return <Panel className="p-4"><EmptyState title="Assets/uniforms not required" description="Assets and uniforms module is disabled." /></Panel>;
  return (
    <Panel className="p-4">
      <h3 className="text-sm font-semibold">Assets and uniforms</h3>
      <OptionalSectionNotice workspace={workspace} sectionKey="available_assets" fallbackTitle="Available assets and uniforms" />
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <SelectField label="Available asset/uniform" value={form.asset_item_id} onValueChange={(asset_item_id) => setForm({ ...form, asset_item_id })}><option value="">Select asset or mark not required</option>{asRows(refs.available_assets).map((asset) => <option key={String(asset.id)} value={String(asset.id)}>{text(asset.name)} ({text(asset.code)})</option>)}</SelectField>
        <Field label="Issued date"><Input type="date" value={form.issued_date} onChange={(event) => setForm({ ...form, issued_date: event.target.value })} /></Field>
        <Field label="Expected return"><Input type="date" value={form.expected_return_date} onChange={(event) => setForm({ ...form, expected_return_date: event.target.value })} /></Field>
        <CheckboxField label="Not required" checked={form.not_required} onChange={(not_required) => setForm({ ...form, not_required })} />
        <CheckboxField label="Waived" checked={form.waived} onChange={(waived) => setForm({ ...form, waived })} />
        {(form.not_required || form.waived) ? <Field label="Reason"><Input value={form.reason} onChange={(event) => setForm({ ...form, reason: event.target.value })} /></Field> : null}
        <div className="md:col-span-3"><Field label="Notes"><Input value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} /></Field></div>
      </div>
      <div className="mt-4 flex justify-end"><ActionTextButton intent="save" size="sm" onClick={() => onSave(form)}>Save assets/uniforms</ActionTextButton></div>
    </Panel>
  );
}

function UserAccessWorkspaceForm({ workspace, onSave }: { workspace: Row; onSave: (input: Row) => void }) {
  const userAccount = asRow(asRow(workspace.sections).user_account);
  const linked = asRow(userAccount.linked_user);
  const employee = asRow(workspace.employee);
  const employeeEmail = asRow(userAccount.employee_email);
  const availableUsers = asRows(userAccount.available_users);
  const availableRoles = asRows(userAccount.available_roles);
  const availableScopes = asRows(userAccount.available_access_scopes);
  const assignedRoles = asRows(userAccount.roles);
  const assignedScopes = asRows(userAccount.scopes);
  const [mode, setMode] = useState<"provision_new" | "link_existing" | "defer" | "not_required">(linked.id ? "defer" : employeeEmail.recommendation === "LINK_EXISTING_USER" ? "link_existing" : "provision_new");
  const [roleIds, setRoleIds] = useState<string[]>(asRows(userAccount.roles).map((role) => String(role.id)));
  const [scopeIds, setScopeIds] = useState<string[]>(asRows(userAccount.access_scope_ids).map(String));
  const [form, setForm] = useState({
    user_id: String(asRow(employeeEmail.matching_user).id ?? ""),
    name: text(employee.display_name ?? employee.full_name),
    email: String(employeeEmail.email ?? ""),
    username: String(userAccount.suggested_username ?? ""),
    password: "",
    self_service_enabled: userAccount.self_service_enabled !== false,
    reason: ""
  });
  function toggle(list: string[], value: string, checked: boolean) {
    return checked ? Array.from(new Set([...list, value])) : list.filter((item) => item !== value);
  }
  function submit(action: "provision_new" | "link_existing" | "defer" | "not_required") {
    if (action === "provision_new") {
      onSave({
        action,
        name: form.name,
        email: form.email,
        username: form.username,
        password: form.password || undefined,
        self_service_enabled: form.self_service_enabled,
        role_ids: roleIds,
        access_scope_ids: scopeIds,
        reset_required: !form.password,
        email_override_reason: employeeEmail.email && form.email && String(form.email).toLowerCase() !== String(employeeEmail.email).toLowerCase() ? "Provision email manually overridden in onboarding workspace." : null,
        reason: form.reason || "Provisioned from onboarding workspace."
      });
      return;
    }
    if (action === "link_existing") {
      onSave({
        action,
        user_id: form.user_id,
        self_service_enabled: form.self_service_enabled,
        role_ids: roleIds,
        access_scope_ids: scopeIds,
        reason: form.reason || "Linked from onboarding workspace."
      });
      return;
    }
    onSave({ action, reason: form.reason || (action === "not_required" ? "Login is not required for this employee." : "User access setup deferred from onboarding workspace.") });
  }
  return (
    <Panel className="p-4">
      <h3 className="text-sm font-semibold">User account / self-service access</h3>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <Info label="Linked account" value={linked.id ? `${text(linked.name)} (${text(linked.email)})` : "Not linked"} />
        <Info label="User status" value={linked.status ?? "Pending"} />
        <Info label="Invite/reset" value={userAccount.invite_status ? `${text(userAccount.invite_status)}${userAccount.reset_required ? " / reset required" : ""}` : "Not set"} />
        <Info label="Employee email" value={employeeEmail.email ?? employeeEmail.raw_email ?? "No email on file"} />
        <Info label="Email source" value={employeeEmail.message ?? "Enter an account email to continue."} />
        <Info label="Suggested username" value={userAccount.suggested_username ?? "Not set"} />
      </div>
      {linked.id ? (
        <div className="mt-4 space-y-3">
          <div className="rounded-md border bg-slate-50 px-3 py-2 text-sm text-slate-700">
            This onboarding case is linked to a real user account. Manage changes from Employee 360 or use the checklist actions below.
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <SimpleList title="Assigned roles" values={assignedRoles.map((role) => text(role.name))} />
            <SimpleList title="Assigned user scopes" values={assignedScopes.map((scope) => `${text(scope.name)} / ${text(scope.scope_type)} / ${text(scope.module_key ?? "All modules")}`)} />
          </div>
          <div className="flex justify-end">
            <ActionTextButton intent="complete" size="sm" onClick={() => onSave({ action: "complete_existing", reason: "Linked user account reviewed in onboarding workspace." })}>Mark reviewed</ActionTextButton>
          </div>
        </div>
      ) : (
        <div className="mt-4 space-y-4">
          {employeeEmail.recommendation === "LINK_EXISTING_USER" && employeeEmail.matching_user ? (
            <div className="rounded-md border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-900">
              Employee email matches an existing unlinked user. Link that account instead of creating a duplicate.
            </div>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant={mode === "provision_new" ? "primary" : "outline"} onClick={() => setMode("provision_new")}>Provision user account</Button>
            <Button size="sm" variant={mode === "link_existing" ? "primary" : "outline"} onClick={() => setMode("link_existing")}>Link existing user</Button>
            <Button size="sm" variant={mode === "defer" ? "primary" : "outline"} onClick={() => setMode("defer")}>Defer</Button>
            <Button size="sm" variant={mode === "not_required" ? "primary" : "outline"} onClick={() => setMode("not_required")}>Not required</Button>
          </div>
          {mode === "provision_new" ? (
            <div className="grid gap-3 md:grid-cols-3">
              <Field label="Name"><Input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} /></Field>
              <Field label="Email"><Input type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} /></Field>
              <Field label="Username"><Input value={form.username} onChange={(event) => setForm({ ...form, username: event.target.value })} /></Field>
              <Field label="Temporary password"><Input type="password" value={form.password} placeholder="Leave blank for invite/reset pending" onChange={(event) => setForm({ ...form, password: event.target.value })} /></Field>
              <CheckboxField label="Enable self-service scope" checked={form.self_service_enabled} onChange={(self_service_enabled) => setForm({ ...form, self_service_enabled })} />
            </div>
          ) : null}
          {mode === "link_existing" ? (
            <SelectField label="Existing user" value={form.user_id} onValueChange={(user_id) => setForm({ ...form, user_id })}>
              <option value="">Select user</option>
              {availableUsers.map((user) => <option key={String(user.id)} value={String(user.id)}>{text(user.name)} - {text(user.email)}</option>)}
            </SelectField>
          ) : null}
          {(mode === "provision_new" || mode === "link_existing") ? (
            <div className="grid gap-4 lg:grid-cols-2">
              <OnboardingRoleScopeChecklist title="Roles" rows={availableRoles} selected={roleIds} onToggle={(id, checked) => setRoleIds(toggle(roleIds, id, checked))} />
              <OnboardingRoleScopeChecklist title="Access scopes" rows={availableScopes} selected={scopeIds} onToggle={(id, checked) => setScopeIds(toggle(scopeIds, id, checked))} />
            </div>
          ) : null}
          <Field label="Reason / note"><Input value={form.reason} onChange={(event) => setForm({ ...form, reason: event.target.value })} /></Field>
          <div className="flex justify-end">
            <ActionTextButton intent={mode === "not_required" || mode === "defer" ? "save" : "create"} size="sm" disabled={mode === "link_existing" && !form.user_id} onClick={() => submit(mode)}>Save user access setup</ActionTextButton>
          </div>
        </div>
      )}
    </Panel>
  );
}

function SimpleList({ title: listTitle, values }: { title: string; values: string[] }) {
  return (
    <div className="rounded-md border">
      <div className="border-b px-3 py-2 text-sm font-semibold">{listTitle}</div>
      <div className="divide-y">{values.length ? values.map((value, index) => <div key={`${value}-${index}`} className="px-3 py-2 text-sm">{value}</div>) : <div className="px-3 py-3 text-sm text-muted-foreground">None.</div>}</div>
    </div>
  );
}

function OnboardingRoleScopeChecklist({ title: listTitle, rows, selected, onToggle }: { title: string; rows: Row[]; selected: string[]; onToggle: (id: string, checked: boolean) => void }) {
  return (
    <div className="rounded-md border">
      <div className="border-b px-3 py-2 text-sm font-semibold">{listTitle}</div>
      <div className="grid max-h-56 gap-2 overflow-y-auto p-3">
        {rows.length ? rows.map((row) => {
          const id = String(row.id);
          const label = row.scope_type ? `${text(row.name)} / ${text(row.scope_type)} / ${text(row.module_key ?? "All modules")}` : text(row.name);
          return <CheckboxField key={id} label={label} checked={selected.includes(id)} onChange={(checked) => onToggle(id, checked)} />;
        }) : <p className="text-xs text-muted-foreground">No options available.</p>}
      </div>
    </div>
  );
}

function ReasonModal({ title: modalTitle, onClose, onSubmit }: { title: string; onClose: () => void; onSubmit: (reason: string) => Promise<void> }) {
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const validation = useFormValidation();
  async function submit(event: FormEvent) {
    event.preventDefault();
    const issues = validateRequiredField(reason, "reason", "Reason");
    validation.setIssues(issues);
    if (issues.some((issue) => issue.severity === "error")) {
      setTimeout(() => focusFirstInvalidField(issues), 0);
      return;
    }
    try {
      await onSubmit(reason.trim());
    } catch (err) {
      const issuesFromApi = normalizeValidationIssues(err);
      if (issuesFromApi.length) {
        validation.setIssues(issuesFromApi);
        setTimeout(() => focusFirstInvalidField(issuesFromApi), 0);
      }
      setError(issuesFromApi[0]?.message ?? (err instanceof ApiError ? err.message : "Unable to complete action."));
    }
  }
  return (
    <Modal title={modalTitle} onClose={onClose}>
      <form className="space-y-3" onSubmit={(event) => void submit(event)}>
        <FormErrorSummary issues={validation.issues} />
        <ValidatedReasonField required value={reason} issues={validation.issues} onChange={setReason} />
        {error ? <p className="text-sm text-red-600">{error}</p> : null}
        <div className="flex justify-end gap-2"><Button variant="outline" onClick={onClose}>Cancel</Button><ActionTextButton intent="confirm" type="submit">Confirm</ActionTextButton></div>
      </form>
    </Modal>
  );
}

function Modal({ title: modalTitle, children, onClose, wide, hideHeader, bodyClassName }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean; hideHeader?: boolean; bodyClassName?: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden bg-slate-950/35 p-2 sm:p-4">
      <div className={`w-full rounded-md bg-white shadow-lg ${wide ? "flex h-[90vh] max-h-[92vh] w-[94vw] max-w-[1440px] flex-col overflow-hidden" : "max-h-[90vh] max-w-xl overflow-y-auto"}`}>
        {hideHeader ? null : (
          <div className="flex items-center justify-between border-b px-4 py-3">
            <h2 className="text-sm font-semibold">{modalTitle}</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>Close</Button>
          </div>
        )}
        <div className={bodyClassName ?? (wide ? "min-h-0 flex-1 overflow-y-auto p-4" : "p-4")}>{children}</div>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: unknown }) {
  return <div className="rounded-md border px-3 py-2"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 text-sm font-medium">{text(value)}</p></div>;
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <div className="space-y-1.5"><Label>{label}</Label>{children}</div>;
}

function ContractReadinessPanel({ contract }: { contract?: Row }) {
  const display = (contract?.display ?? {}) as Row;
  const warnings = Array.isArray(contract?.warnings) ? contract.warnings : [];
  const blockers = Array.isArray(contract?.blockers) ? contract.blockers : [];
  return (
    <Panel className="p-3">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-sm font-semibold">Contract readiness</h3>
          <p className="text-xs text-muted-foreground">Permanent contracts can leave end dates blank unless the selected contract type requires one.</p>
        </div>
        <Badge tone={contract?.ready ? "success" : contract?.required ? "warning" : "neutral"}>{displayText(contract?.status_label, "Not required")}</Badge>
      </div>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <Info label="Contract" value={display.contract ?? (contract?.required ? "Contract missing" : "Not required")} />
        <Info label="Contract Type" value={display.contract_type ?? "Not selected"} />
        <Info label="Contract Start Date" value={display.contract_start_date ?? "Not set"} />
        <Info label="Contract End Date" value={display.contract_end_date ?? "Not required"} />
        <Info label="Probation" value={display.probation ?? "Not applicable"} />
        <Info label="Confirmation Due" value={display.confirmation_due ?? "Not set"} />
      </div>
      {blockers.length || warnings.length ? (
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <div><p className="text-xs font-medium text-muted-foreground">Contract blockers</p><List values={blockers} /></div>
          <div><p className="text-xs font-medium text-muted-foreground">Contract warnings</p><List values={warnings} /></div>
        </div>
      ) : null}
    </Panel>
  );
}

function List({ values }: { values: unknown[] }) {
  if (!values.length) return <p className="mt-2 text-sm text-muted-foreground">None.</p>;
  return <ul className="mt-2 list-disc space-y-1 pl-4 text-sm text-muted-foreground">{values.map((value, index) => <li key={index}>{objectMessage(value)}</li>)}</ul>;
}
