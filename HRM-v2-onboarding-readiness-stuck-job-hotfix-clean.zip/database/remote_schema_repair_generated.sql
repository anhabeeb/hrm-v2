-- Generated HRM v2 remote D1 schema repair.;

-- Review this file before applying it.;

-- Do not include transaction-control statements in D1/Wrangler command files.;

-- Apply with: npm run apply:remote-schema-repair;

PRAGMA foreign_keys = OFF;

PRAGMA foreign_keys = ON;
