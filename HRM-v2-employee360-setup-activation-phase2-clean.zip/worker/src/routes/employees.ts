import { Hono } from "hono";
import type { Context } from "hono";
import { accessScopeToApi, buildEmployeeScopeWhereClause, canAccessEmployee, type AccessScopeRuleRow, type AccessScopeType } from "../auth/access-scopes";
import { hashPassword } from "../auth/password";
import { recordAudit } from "../db/audit";
import { getActiveOwnerCount, getUserByEmail, getUserById } from "../db/users";
import { employeeSetupStatusUpdateResponse, updateEmployeeSetupSectionStatusAfterSave } from "../employee-setup/save-integration";
import { getEmployeeSetupSectionPreviewPayload, rebuildEmployeeSetupSectionStatuses, sanitizeEmployeeSetupStatusError } from "../employee-setup/section-status";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { hasValidationErrors, validateAccessScope, validateDateField, validateDateRange, validateEnumValue, validateOrganizationCascadeWithScope, validateRequiredFields, validateStringLength, validationResponse } from "../lib/moduleValidation";
import { publishAccessEvent } from "../realtime/publisher";
import { autoCreateOnboardingCaseAfterEmployeeCreate } from "./lifecycle";
import { applyRoleMappingToEmployee, roleMappingPreviewForEmployee } from "./role-mappings";
import type { AppBindings, DbUser, UserStatus } from "../types";
import { fail, getClientIp, ok, okCached } from "../utils/http";
import { requireOperationalModuleEnabled } from "../utils/module-enforcement";
import { paginationMeta, parsePaginationParams } from "../utils/pagination";
import { timeD1, timeStage } from "../utils/performance";
import { isEmail, normalizeEmail, readJsonBody, readString } from "../utils/validation";

type EmployeeType = "LOCAL" | "FOREIGN" | "OTHER";
type EmploymentType = "FULL_TIME" | "PART_TIME" | "INTERN" | "TEMPORARY" | "CONTRACT";
type ContactType = "PERSONAL_PHONE" | "WORK_PHONE" | "PERSONAL_EMAIL" | "WORK_EMAIL" | "EMERGENCY" | "GUARDIAN" | "SPOUSE" | "PARENT" | "OTHER";
type OnboardingStatus = "PENDING" | "COMPLETED" | "SKIPPED" | "BLOCKED";
type BindValue = string | number | null;
type EmployeeUserAccountAction = "view" | "manage" | "link" | "unlink" | "roles" | "scopes" | "deactivate";

const EMPLOYEE_TYPES = new Set<EmployeeType>(["LOCAL", "FOREIGN", "OTHER"]);
const EMPLOYMENT_TYPES = new Set<EmploymentType>(["FULL_TIME", "PART_TIME", "INTERN", "TEMPORARY", "CONTRACT"]);
const CONTACT_TYPES = new Set<ContactType>(["PERSONAL_PHONE", "WORK_PHONE", "PERSONAL_EMAIL", "WORK_EMAIL", "EMERGENCY", "GUARDIAN", "SPOUSE", "PARENT", "OTHER"]);
const ONBOARDING_STATUSES = new Set<OnboardingStatus>(["PENDING", "COMPLETED", "SKIPPED", "BLOCKED"]);
const EMPLOYEE_CONTACT_COLUMNS = `
  id, employee_id, contact_type, value, country_code, relationship, is_primary,
  emergency_priority, is_sensitive, notes, archived_at, created_at, updated_at
`;
const EMPLOYEE_ONBOARDING_TASK_COLUMNS = `
  id, onboarding_case_id, employee_id, task_key, title, task_name, description, module,
  task_group, source_module, source_reference_type, source_reference_id, status, task_status,
  required, is_required, assigned_to_user_id, assigned_role_id, due_date, completed_by_user_id,
  completed_at, waived_by_user_id, waived_at, waiver_reason, blocked_reason, notes,
  created_at, updated_at, metadata_json
`;
const EMPLOYEE_OVERVIEW_AUDIT_COLUMNS = `
  id, actor_user_id, action, module, entity_type, entity_id, reason, created_at
`;
const EMPLOYEE_STATUS_COLUMNS = `
  id, key, name, description, is_protected, is_active, can_login, include_in_payroll,
  include_in_roster, show_in_active_lists, requires_exit_date, requires_exit_reason,
  requires_final_settlement, requires_document_clearance, requires_asset_clearance,
  sort_order, created_at, updated_at
`;

interface EmployeeStatusRow {
  id: string;
  key: string;
  name: string;
  description: string | null;
  is_protected: number;
  is_active: number;
  can_login: number;
  include_in_payroll: number;
  include_in_roster: number;
  show_in_active_lists: number;
  requires_exit_date: number;
  requires_exit_reason: number;
  requires_final_settlement: number;
  requires_document_clearance: number;
  requires_asset_clearance: number;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

interface NumberSettingsRow {
  id: string;
  prefix: string;
  include_year: number;
  include_location_code: number;
  include_department_code: number;
  sequence_padding: number;
  next_sequence: number;
  allow_manual_override: number;
  separator: string;
  created_at: string;
  updated_at: string;
}

interface EmployeeRow {
  id: string;
  employee_no: string;
  profile_photo_document_id: string | null;
  full_name: string;
  display_name: string | null;
  gender: string | null;
  date_of_birth: string | null;
  nationality: string | null;
  employee_type: EmployeeType;
  employment_type: EmploymentType;
  status_id: string;
  status_key?: string;
  status_name?: string;
  primary_department_id: string | null;
  department_name?: string | null;
  primary_position_id: string | null;
  position_title?: string | null;
  primary_location_id: string | null;
  location_name?: string | null;
  location_code?: string | null;
  job_level_id: string | null;
  job_level_name?: string | null;
  joining_date: string | null;
  confirmation_date: string | null;
  contract_start_date: string | null;
  contract_end_date: string | null;
  probation_end_date: string | null;
  reporting_manager_employee_id: string | null;
  reporting_manager_name?: string | null;
  payroll_included: number;
  roster_eligible: number;
  user_id: string | null;
  linked_user_email?: string | null;
  exit_date: string | null;
  exit_reason: string | null;
  notes_summary: string | null;
  created_at: string;
  updated_at: string;
  archived_at: string | null;
}

interface ContactRow {
  id: string;
  employee_id: string;
  contact_type: ContactType;
  value: string;
  country_code: string | null;
  relationship: string | null;
  is_primary: number;
  emergency_priority: number | null;
  is_sensitive: number;
  notes: string | null;
  archived_at: string | null;
  created_at: string;
  updated_at: string;
}

interface EmployeeUserAccountRow extends DbUser {
  employee_no?: string | null;
  employee_name?: string | null;
}

interface RoleAssignmentRow {
  id: string;
  name: string;
  is_active: number;
  is_protected: number;
}

interface UserAccountRoleRow extends RoleAssignmentRow {
  created_at: string;
}

type EmployeeUserAccountLinkStatus = "ACTIVE" | "UNLINKED" | "DEACTIVATED";
type InviteStatus = "PASSWORD_SET" | "INVITE_RESET_PENDING" | "RESET_REQUIRED" | "DISABLED";

interface EmployeeUserAccountLinkRow {
  id: string;
  employee_id: string;
  user_id: string;
  status: EmployeeUserAccountLinkStatus;
  linked_at: string;
  linked_by_user_id: string | null;
  linked_by_name?: string | null;
  unlinked_at: string | null;
  unlinked_by_user_id: string | null;
  unlinked_by_name?: string | null;
  unlink_reason: string | null;
  deactivated_at: string | null;
  deactivated_by_user_id: string | null;
  deactivated_by_name?: string | null;
  deactivation_reason: string | null;
  self_service_enabled_snapshot: number;
  invite_status: InviteStatus;
  reset_required: number;
  employee_email_used: string | null;
  account_email_created: string | null;
  email_source: string | null;
  email_override_reason: string | null;
  created_at: string;
  updated_at: string;
}

type UserScopeConfigInput = {
  id?: string | null;
  name?: string | null;
  description?: string | null;
  module_key?: string | null;
  scope_type?: AccessScopeType | string | null;
  allowed_department_ids?: unknown;
  allowed_location_ids?: unknown;
  include_sub_departments?: unknown;
  include_reporting_chain?: unknown;
  can_view?: unknown;
  can_manage?: unknown;
};

type PreparedUserScopeAssignment = {
  name: string;
  description: string | null;
  module_key: string | null;
  scope_type: AccessScopeType;
  allowed_department_ids_json: string | null;
  allowed_location_ids_json: string | null;
  include_sub_departments: boolean;
  include_reporting_chain: boolean;
  can_view: boolean;
  can_manage: boolean;
  source_scope_id?: string | null;
};

const onboardingTemplates = [
  ["basic_profile_completed", "Basic profile completed", "employees", "Verify employee identity and core profile fields.", 1],
  ["required_documents_checklist", "Required documents checklist", "documents", "Prepare required employee document tracking.", 1],
  ["payroll_setup_checklist", "Payroll setup checklist", "payroll", "Prepare payroll profile details.", 1],
  ["department_outlet_assignment", "Department/outlet assignment", "organization", "Confirm organization assignment.", 1],
  ["roster_eligibility_setup", "Roster eligibility setup", "roster", "Confirm roster eligibility.", 0],
  ["asset_uniform_issue", "Asset/uniform issue checklist", "assets", "Prepare asset and uniform issue tracking.", 0],
  ["user_access_setup", "User/account access setup if needed", "users", "Prepare linked user account if required.", 0],
  ["final_activation_approval", "Final activation approval", "employees", "Review onboarding before activation.", 1]
] as const;

export const employeeRoutes = new Hono<AppBindings>();

employeeRoutes.use("*", requireAuth);

function hasPermission(c: Context<AppBindings>, permission: string) {
  return c.get("currentUser").permissions.includes(permission);
}

function hasAnyPermission(c: Context<AppBindings>, permissions: string[]) {
  return permissions.some((permission) => hasPermission(c, permission));
}

function employeeUserAccountPermissions(action: EmployeeUserAccountAction) {
  const baseView = ["employee.user_account.view", "employees.view", "users.view"];
  const baseManage = ["employee.user_account.manage", "users.update", "self_service.manage_access"];
  if (action === "view") return baseView;
  if (action === "link") return ["users.link_employee", ...baseManage];
  if (action === "unlink") return ["users.unlink_employee", ...baseManage];
  if (action === "roles") return ["users.assign_roles", "users.update", "roles.assign_permissions", ...baseManage];
  if (action === "scopes") return ["users.assign_scopes", "access_scopes.apply", "access_scopes.manage", ...baseManage];
  if (action === "deactivate") return ["users.disable", ...baseManage];
  return baseManage;
}

function requireEmployeeUserAccountPermission(c: Context<AppBindings>, action: EmployeeUserAccountAction) {
  if (hasAnyPermission(c, employeeUserAccountPermissions(action))) return null;
  return fail(c, 403, "FORBIDDEN", "You do not have permission to manage this employee user account.");
}

function optionalString(value: unknown) {
  const text = readString(value);
  return text || null;
}

function boolValue(value: unknown, fallback: boolean) {
  return typeof value === "boolean" ? value : fallback;
}

function arrayOfStrings(value: unknown) {
  return Array.isArray(value) ? Array.from(new Set(value.filter((item): item is string => typeof item === "string" && item.trim().length > 0))) : [];
}

function isStrongPassword(password: string) {
  return password.length >= 12 && /[A-Za-z]/.test(password) && /\d/.test(password);
}

function slugForUsername(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, ".")
    .replace(/^[._-]+|[._-]+$/g, "")
    .slice(0, 48);
}

async function uniqueUsernameSuggestion(db: AppBindings["Bindings"]["DB"], employee: EmployeeRow, email: string | null) {
  const candidates = [
    email ? email.split("@")[0] : null,
    employee.employee_no,
    employee.display_name ?? employee.full_name
  ]
    .map((value) => value ? slugForUsername(String(value)) : "")
    .filter(Boolean);
  const base = candidates[0] || `employee.${employee.id.slice(0, 8)}`;
  const uniqueCandidates = Array.from(new Set([base, ...candidates, `${base}.${employee.employee_no.toLowerCase()}`, `${base}.${employee.id.slice(0, 6)}`]));
  for (const candidate of uniqueCandidates) {
    const existing = await db.prepare("SELECT id FROM users WHERE username = ? COLLATE NOCASE").bind(candidate).first<{ id: string }>();
    if (!existing) return candidate;
  }
  return `${base}.${crypto.randomUUID().slice(0, 6)}`;
}

async function getEmployeeEmailSuggestion(db: AppBindings["Bindings"]["DB"], employee: EmployeeRow) {
  const contacts = await db
    .prepare(
      `SELECT value, contact_type, is_primary
       FROM employee_contacts
       WHERE employee_id = ? AND archived_at IS NULL AND contact_type IN ('WORK_EMAIL', 'PERSONAL_EMAIL')
       ORDER BY is_primary DESC, CASE contact_type WHEN 'WORK_EMAIL' THEN 0 ELSE 1 END, created_at DESC
       LIMIT 3`
    )
    .bind(employee.id)
    .all<{ value: string; contact_type: string; is_primary: number }>();
  const raw = contacts.results.map((contact) => contact.value).find(Boolean) ?? null;
  const normalized = raw ? normalizeEmail(raw) : "";
  const valid = Boolean(normalized && isEmail(normalized));
  const matchingUser = valid ? await getUserByEmail(db, normalized) : null;
  return {
    email: valid ? normalized : null,
    raw_email: raw,
    is_valid: valid,
    source: raw ? "employee_contact" : "manual_required",
    message: raw
      ? valid
        ? "Using employee email from profile."
        : "Employee email is invalid. Update employee email or enter a valid account email."
      : "Employee has no email on file. Enter an account email to continue.",
    matching_user: matchingUser ? {
      id: matchingUser.id,
      name: matchingUser.name,
      email: matchingUser.email,
      username: matchingUser.username,
      status: matchingUser.status,
      employee_id: matchingUser.employee_id
    } : null,
    recommendation: matchingUser
      ? matchingUser.employee_id && matchingUser.employee_id !== employee.id
        ? "BLOCK_DUPLICATE_LINKED_EMPLOYEE"
        : matchingUser.employee_id === employee.id || employee.user_id === matchingUser.id
          ? "ALREADY_LINKED"
          : "LINK_EXISTING_USER"
      : valid
        ? "PROVISION_WITH_EMPLOYEE_EMAIL"
        : "ENTER_EMAIL"
  };
}

function normalizeIdsForJson(value: unknown) {
  const ids = arrayOfStrings(value).sort();
  return ids.length ? JSON.stringify(ids) : null;
}

function normalizeScopeConfigList(value: unknown) {
  if (!value) return [];
  const list = Array.isArray(value) ? value : [value];
  return list.filter((item): item is UserScopeConfigInput => item !== null && typeof item === "object");
}

async function ensureScopeModuleEnabled(db: AppBindings["Bindings"]["DB"], moduleKey: string | null) {
  if (!moduleKey) return true;
  const row = await db.prepare("SELECT is_enabled FROM module_control_settings WHERE module_key = ?").bind(moduleKey).first<{ is_enabled: number }>();
  return !row || row.is_enabled === 1;
}

async function prepareUserAccessScopeAssignments(c: Context<AppBindings>, body: Record<string, unknown>, targetUserId?: string | null) {
  const scopeIds = arrayOfStrings(body.access_scope_ids);
  const configs = [
    ...normalizeScopeConfigList(body.access_scope_config),
    ...normalizeScopeConfigList(body.access_scope_configs)
  ];
  if (scopeIds.length === 0 && configs.length === 0) return { assignments: [] as PreparedUserScopeAssignment[] };
  if (!hasAnyPermission(c, employeeUserAccountPermissions("scopes"))) {
    return { error: fail(c, 403, "FORBIDDEN", "You do not have permission to assign access scopes.") };
  }
  const assignments: PreparedUserScopeAssignment[] = [];
  for (const scopeId of scopeIds) {
    const scope = await c.env.DB.prepare("SELECT * FROM access_scope_rules WHERE id = ? AND is_active = 1").bind(scopeId).first<AccessScopeRuleRow>();
    if (!scope) return { error: fail(c, 400, "UNKNOWN_ACCESS_SCOPE", "One or more selected access scopes do not exist or are inactive.") };
    if (scope.scope_owner_type === "USER" && targetUserId && scope.user_id === targetUserId) continue;
    if (!(await ensureScopeModuleEnabled(c.env.DB, scope.module_key))) {
      return { error: fail(c, 409, "ACCESS_SCOPE_MODULE_DISABLED", "A selected access scope belongs to a disabled module.") };
    }
    const departmentIds = JSON.parse(scope.allowed_department_ids_json ?? "[]") as string[];
    const locationIds = JSON.parse(scope.allowed_location_ids_json ?? "[]") as string[];
    const accessIssues = await validateAccessScope(c.env.DB, c.get("currentUser"), {
      departmentIds,
      locationIds,
      requestedScopeType: scope.scope_type
    });
    if (hasValidationErrors(accessIssues)) return { error: validationResponse(c, accessIssues) };
    assignments.push({
      name: `Assigned ${scope.name}`,
      description: `Copied from access scope ${scope.id} during employee user account setup.`,
      module_key: scope.module_key ?? null,
      scope_type: scope.scope_type,
      allowed_department_ids_json: scope.allowed_department_ids_json ?? null,
      allowed_location_ids_json: scope.allowed_location_ids_json ?? null,
      include_sub_departments: scope.include_sub_departments === 1,
      include_reporting_chain: scope.include_reporting_chain === 1,
      can_view: scope.can_view !== 0,
      can_manage: scope.can_manage === 1,
      source_scope_id: scope.id
    });
  }
  for (const config of configs) {
    const scopeType = String(config.scope_type ?? "SELF_ONLY") as AccessScopeType;
    const allowed_department_ids_json = normalizeIdsForJson(config.allowed_department_ids);
    const allowed_location_ids_json = normalizeIdsForJson(config.allowed_location_ids);
    const moduleKey = optionalString(config.module_key);
    if (!(await ensureScopeModuleEnabled(c.env.DB, moduleKey))) {
      return { error: fail(c, 409, "ACCESS_SCOPE_MODULE_DISABLED", "Selected access scope module is disabled.") };
    }
    const accessIssues = await validateAccessScope(c.env.DB, c.get("currentUser"), {
      departmentIds: allowed_department_ids_json ? JSON.parse(allowed_department_ids_json) : [],
      locationIds: allowed_location_ids_json ? JSON.parse(allowed_location_ids_json) : [],
      requestedScopeType: scopeType
    });
    if (hasValidationErrors(accessIssues)) return { error: validationResponse(c, accessIssues) };
    assignments.push({
      name: optionalString(config.name) ?? "Employee User Access Scope",
      description: optionalString(config.description) ?? "User-specific scope assigned during employee user account setup.",
      module_key: moduleKey,
      scope_type: scopeType,
      allowed_department_ids_json,
      allowed_location_ids_json,
      include_sub_departments: boolValue(config.include_sub_departments, false),
      include_reporting_chain: boolValue(config.include_reporting_chain, false),
      can_view: boolValue(config.can_view, true),
      can_manage: boolValue(config.can_manage, false),
      source_scope_id: optionalString(config.id)
    });
  }
  return { assignments };
}

function numericValue(value: unknown, fallback: number) {
  const next = Number(value);
  return Number.isFinite(next) ? next : fallback;
}

function booleanize(value: number) {
  return value === 1;
}

function toStatus(row: EmployeeStatusRow) {
  return {
    ...row,
    is_protected: booleanize(row.is_protected),
    is_active: booleanize(row.is_active),
    can_login: booleanize(row.can_login),
    include_in_payroll: booleanize(row.include_in_payroll),
    include_in_roster: booleanize(row.include_in_roster),
    show_in_active_lists: booleanize(row.show_in_active_lists),
    requires_exit_date: booleanize(row.requires_exit_date),
    requires_exit_reason: booleanize(row.requires_exit_reason),
    requires_final_settlement: booleanize(row.requires_final_settlement),
    requires_document_clearance: booleanize(row.requires_document_clearance),
    requires_asset_clearance: booleanize(row.requires_asset_clearance)
  };
}

function toNumberSettings(row: NumberSettingsRow) {
  return {
    ...row,
    include_year: booleanize(row.include_year),
    include_location_code: booleanize(row.include_location_code),
    include_department_code: booleanize(row.include_department_code),
    allow_manual_override: booleanize(row.allow_manual_override)
  };
}

function toEmployee(row: EmployeeRow, canViewSensitive: boolean) {
  return {
    ...row,
    gender: canViewSensitive ? row.gender : null,
    date_of_birth: canViewSensitive ? row.date_of_birth : null,
    nationality: canViewSensitive ? row.nationality : row.nationality,
    payroll_included: booleanize(row.payroll_included),
    roster_eligible: booleanize(row.roster_eligible),
    user_linked: Boolean(row.user_id)
  };
}

function toContact(row: ContactRow, canViewSensitive: boolean) {
  const sensitive = booleanize(row.is_sensitive);
  return {
    ...row,
    value: sensitive && !canViewSensitive ? "Restricted" : row.value,
    notes: sensitive && !canViewSensitive ? null : row.notes,
    is_primary: booleanize(row.is_primary),
    is_sensitive: sensitive
  };
}

async function auditEmployee(
  c: Context<AppBindings>,
  input: {
    action: string;
    entityType: string;
    entityId: string;
    oldValue?: unknown;
    newValue?: unknown;
    reason?: string | null;
  }
) {
  const actor = c.get("currentUser");
  await recordAudit(c.env.DB, {
    actorUserId: actor.id,
    action: input.action,
    module: "employees",
    entityType: input.entityType,
    entityId: input.entityId,
    oldValue: input.oldValue,
    newValue: input.newValue,
    reason: input.reason,
    ipAddress: getClientIp(c.req.raw),
    userAgent: c.req.header("User-Agent") ?? null
  });
}

async function publishEmployee(c: Context<AppBindings>, event: "employees.changed" | "employee.created" | "employee.updated" | "employee.status_changed" | "employee.archived" | "employee.onboarding_changed", entityId: string, action: string) {
  const actor = c.get("currentUser");
  await publishAccessEvent(c.env, event, { actor_user_id: actor.id, entity_type: "employee", entity_id: entityId, action });
  if (event !== "employees.changed") {
    await publishAccessEvent(c.env, "employees.changed", { actor_user_id: actor.id, entity_type: "employee", entity_id: entityId, action });
  }
}

async function publishEmployeeUserAccountChanged(c: Context<AppBindings>, employeeId: string, userId: string | null, action: string) {
  const actor = c.get("currentUser");
  await publishAccessEvent(c.env, "employee.access.changed", { actor_user_id: actor.id, entity_type: "employee", entity_id: employeeId, user_id: userId, action });
  if (userId) {
    await publishAccessEvent(c.env, "users.roles.changed", { actor_user_id: actor.id, entity_type: "user", entity_id: userId, employee_id: employeeId, action });
  }
  await publishEmployee(c, "employee.updated", employeeId, action);
}

async function getEmployeeUserAccountUser(db: AppBindings["Bindings"]["DB"], userId: string | null) {
  if (!userId) return null;
  return db
    .prepare(
      `SELECT u.*, e.employee_no, e.full_name AS employee_name
       FROM users u
       LEFT JOIN employees e ON e.id = u.employee_id
       WHERE u.id = ?`
    )
    .bind(userId)
    .first<EmployeeUserAccountRow>();
}

async function getUserRolesForAccount(db: AppBindings["Bindings"]["DB"], userId: string) {
  const rows = await db
    .prepare(
      `SELECT r.id, r.name, r.is_active, r.is_protected, ur.created_at
       FROM roles r
       INNER JOIN user_roles ur ON ur.role_id = r.id
       WHERE ur.user_id = ?
       ORDER BY r.name`
    )
    .bind(userId)
    .all<UserAccountRoleRow>();
  return rows.results;
}

async function getPermissionsForAccount(db: AppBindings["Bindings"]["DB"], userId: string) {
  const rows = await db
    .prepare(
      `SELECT DISTINCT p.key
       FROM permissions p
       INNER JOIN role_permissions rp ON rp.permission_id = p.id
       INNER JOIN roles r ON r.id = rp.role_id AND r.is_active = 1
       INNER JOIN user_roles ur ON ur.role_id = r.id
       WHERE ur.user_id = ?
       ORDER BY p.key`
    )
    .bind(userId)
    .all<{ key: string }>();
  return rows.results.map((row) => row.key);
}

async function getUserScopesForAccount(db: AppBindings["Bindings"]["DB"], userId: string) {
  const scopes = await db
    .prepare(
      `SELECT asr.*, r.name AS role_name, u.name AS user_name, u.email AS user_email,
        rmr.name AS role_mapping_name, rr.name AS role_mapping_role_name
       FROM access_scope_rules asr
       LEFT JOIN roles r ON r.id = asr.role_id
       LEFT JOIN users u ON u.id = asr.user_id
       LEFT JOIN role_mapping_rules rmr ON rmr.id = asr.role_mapping_rule_id
       LEFT JOIN roles rr ON rr.id = rmr.default_role_id
       WHERE asr.user_id = ? AND asr.scope_owner_type = 'USER'
       ORDER BY COALESCE(asr.module_key, 'all'), asr.name`
    )
    .bind(userId)
    .all<AccessScopeRuleRow>();
  return scopes.results.map(accessScopeToApi);
}

async function getAvailableUsersForEmployeeLink(db: AppBindings["Bindings"]["DB"], employeeId: string) {
  const rows = await db
    .prepare(
      `SELECT u.id, u.name, u.email, u.username, u.status, u.employee_id, e.employee_no, e.full_name AS employee_name
       FROM users u
       LEFT JOIN employees e ON e.id = u.employee_id
       WHERE u.status != 'DISABLED' AND (u.employee_id IS NULL OR u.employee_id = ?)
       ORDER BY u.name`
    )
    .bind(employeeId)
    .all<EmployeeUserAccountRow>();
  return rows.results.map((row) => ({
    id: row.id,
    name: row.name,
    email: row.email,
    username: row.username,
    status: row.status,
    employee_id: row.employee_id,
    employee_no: row.employee_no ?? null,
    employee_name: row.employee_name ?? null
  }));
}

async function employeeSelfServiceRoleId(db: AppBindings["Bindings"]["DB"]) {
  const row = await db.prepare("SELECT id FROM roles WHERE name = 'Employee Self-Service' AND is_active = 1 LIMIT 1").first<{ id: string }>();
  return row?.id ?? null;
}

async function ensureSelfOnlyScopeForUser(db: AppBindings["Bindings"]["DB"], userId: string, actorUserId: string) {
  const existing = await db
    .prepare(
      `SELECT id FROM access_scope_rules
       WHERE scope_owner_type = 'USER' AND user_id = ? AND scope_type = 'SELF_ONLY'
         AND COALESCE(module_key, '') IN ('', 'self_service')
       ORDER BY CASE WHEN module_key = 'self_service' THEN 0 ELSE 1 END, created_at
       LIMIT 1`
    )
    .bind(userId)
    .first<{ id: string }>();
  if (existing) {
    await db
      .prepare(
        `UPDATE access_scope_rules
         SET is_active = 1, can_view = 1, can_manage = 0, updated_by_user_id = ?, updated_at = ?
         WHERE id = ?`
      )
      .bind(actorUserId, new Date().toISOString(), existing.id)
      .run();
    return existing.id;
  }
  const scopeId = crypto.randomUUID();
  await db
    .prepare(
      `INSERT INTO access_scope_rules (
        id, name, description, scope_owner_type, user_id, module_key, scope_type,
        include_sub_departments, include_reporting_chain, can_view, can_manage, is_active,
        created_by_user_id, updated_by_user_id
      ) VALUES (?, 'Employee Self-Service Scope', 'Self-only scope created during employee user account provisioning.', 'USER', ?, 'self_service', 'SELF_ONLY', 0, 0, 1, 0, 1, ?, ?)`
    )
    .bind(scopeId, userId, actorUserId, actorUserId)
    .run();
  return scopeId;
}

async function applyPreparedUserAccessScopes(c: Context<AppBindings>, userId: string, assignments: PreparedUserScopeAssignment[]) {
  if (!assignments.length) return [];
  const actor = c.get("currentUser").id;
  const now = new Date().toISOString();
  const applied: string[] = [];
  const writes: D1PreparedStatement[] = [];
  for (const assignment of assignments) {
    const existing = await c.env.DB
      .prepare(
        `SELECT id FROM access_scope_rules
         WHERE scope_owner_type = 'USER' AND user_id = ?
           AND COALESCE(module_key, '') = COALESCE(?, '')
           AND scope_type = ?
           AND COALESCE(allowed_department_ids_json, '') = COALESCE(?, '')
           AND COALESCE(allowed_location_ids_json, '') = COALESCE(?, '')
         LIMIT 1`
      )
      .bind(userId, assignment.module_key, assignment.scope_type, assignment.allowed_department_ids_json, assignment.allowed_location_ids_json)
      .first<{ id: string }>();
    if (existing) {
      applied.push(existing.id);
      writes.push(
        c.env.DB
          .prepare(
            `UPDATE access_scope_rules
             SET name = ?, description = ?, include_sub_departments = ?, include_reporting_chain = ?,
               can_view = ?, can_manage = ?, is_active = 1, updated_by_user_id = ?, updated_at = ?
             WHERE id = ?`
          )
          .bind(assignment.name, assignment.description, assignment.include_sub_departments ? 1 : 0, assignment.include_reporting_chain ? 1 : 0, assignment.can_view ? 1 : 0, assignment.can_manage ? 1 : 0, actor, now, existing.id)
      );
    } else {
      const id = crypto.randomUUID();
      applied.push(id);
      writes.push(
        c.env.DB
          .prepare(
            `INSERT INTO access_scope_rules (
              id, name, description, scope_owner_type, user_id, module_key, scope_type,
              allowed_department_ids_json, allowed_location_ids_json, include_sub_departments, include_reporting_chain,
              can_view, can_manage, is_active, created_by_user_id, updated_by_user_id
            ) VALUES (?, ?, ?, 'USER', ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
          )
          .bind(id, assignment.name, assignment.description, userId, assignment.module_key, assignment.scope_type, assignment.allowed_department_ids_json, assignment.allowed_location_ids_json, assignment.include_sub_departments ? 1 : 0, assignment.include_reporting_chain ? 1 : 0, assignment.can_view ? 1 : 0, assignment.can_manage ? 1 : 0, actor, actor)
      );
    }
  }
  await c.env.DB.batch(writes);
  await recordAudit(c.env.DB, {
    actorUserId: actor,
    action: "employee.user_account.scopes_updated",
    module: "employees",
    entityType: "user",
    entityId: userId,
    newValue: { access_scope_ids: applied, source_scope_ids: assignments.map((assignment) => assignment.source_scope_id).filter(Boolean) },
    ipAddress: getClientIp(c.req.raw),
    userAgent: c.req.header("User-Agent") ?? null
  });
  return applied;
}

async function getActiveEmployeeUserAccountLink(db: AppBindings["Bindings"]["DB"], employeeId: string) {
  return db
    .prepare(
      `SELECT l.*, lb.name AS linked_by_name, ub.name AS unlinked_by_name, dbu.name AS deactivated_by_name
       FROM employee_user_account_links l
       LEFT JOIN users lb ON lb.id = l.linked_by_user_id
       LEFT JOIN users ub ON ub.id = l.unlinked_by_user_id
       LEFT JOIN users dbu ON dbu.id = l.deactivated_by_user_id
       WHERE l.employee_id = ? AND l.status = 'ACTIVE'
       ORDER BY l.linked_at DESC LIMIT 1`
    )
    .bind(employeeId)
    .first<EmployeeUserAccountLinkRow>();
}

async function getEmployeeUserAccountLinkHistory(db: AppBindings["Bindings"]["DB"], employeeId: string) {
  const rows = await db
    .prepare(
      `SELECT l.*, lb.name AS linked_by_name, ub.name AS unlinked_by_name, dbu.name AS deactivated_by_name
       FROM employee_user_account_links l
       LEFT JOIN users lb ON lb.id = l.linked_by_user_id
       LEFT JOIN users ub ON ub.id = l.unlinked_by_user_id
       LEFT JOIN users dbu ON dbu.id = l.deactivated_by_user_id
       WHERE l.employee_id = ?
       ORDER BY l.linked_at DESC, l.created_at DESC LIMIT 20`
    )
    .bind(employeeId)
    .all<EmployeeUserAccountLinkRow>();
  return rows.results;
}

async function upsertActiveEmployeeUserAccountLink(
  c: Context<AppBindings>,
  input: {
    employeeId: string;
    userId: string;
    selfServiceEnabled: boolean;
    inviteStatus: InviteStatus;
    resetRequired: boolean;
    employeeEmailUsed?: string | null;
    accountEmailCreated?: string | null;
    emailSource?: string | null;
    emailOverrideReason?: string | null;
  }
) {
  const now = new Date().toISOString();
  await c.env.DB.prepare("UPDATE employee_user_account_links SET status = 'UNLINKED', unlinked_at = COALESCE(unlinked_at, ?), unlinked_by_user_id = COALESCE(unlinked_by_user_id, ?), unlink_reason = COALESCE(unlink_reason, 'Replaced by a new active link.'), updated_at = ? WHERE employee_id = ? AND status = 'ACTIVE' AND user_id != ?")
    .bind(now, c.get("currentUser").id, now, input.employeeId, input.userId)
    .run();
  const existing = await c.env.DB.prepare("SELECT id FROM employee_user_account_links WHERE employee_id = ? AND user_id = ? AND status = 'ACTIVE'").bind(input.employeeId, input.userId).first<{ id: string }>();
  if (existing) {
    await c.env.DB
      .prepare(
        `UPDATE employee_user_account_links
         SET self_service_enabled_snapshot = ?, invite_status = ?, reset_required = ?, employee_email_used = ?,
          account_email_created = ?, email_source = ?, email_override_reason = ?, updated_at = ?
         WHERE id = ?`
      )
      .bind(input.selfServiceEnabled ? 1 : 0, input.inviteStatus, input.resetRequired ? 1 : 0, input.employeeEmailUsed ?? null, input.accountEmailCreated ?? null, input.emailSource ?? null, input.emailOverrideReason ?? null, now, existing.id)
      .run();
    return existing.id;
  }
  const id = crypto.randomUUID();
  await c.env.DB
    .prepare(
      `INSERT INTO employee_user_account_links (
        id, employee_id, user_id, status, linked_at, linked_by_user_id, self_service_enabled_snapshot,
        invite_status, reset_required, employee_email_used, account_email_created, email_source, email_override_reason
      ) VALUES (?, ?, ?, 'ACTIVE', ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(id, input.employeeId, input.userId, now, c.get("currentUser").id, input.selfServiceEnabled ? 1 : 0, input.inviteStatus, input.resetRequired ? 1 : 0, input.employeeEmailUsed ?? null, input.accountEmailCreated ?? null, input.emailSource ?? null, input.emailOverrideReason ?? null)
    .run();
  return id;
}

async function markEmployeeUserAccountLinkInactive(c: Context<AppBindings>, employeeId: string, userId: string, status: "UNLINKED" | "DEACTIVATED", reason: string) {
  const now = new Date().toISOString();
  if (status === "UNLINKED") {
    await c.env.DB.prepare("UPDATE employee_user_account_links SET status = 'UNLINKED', unlinked_at = ?, unlinked_by_user_id = ?, unlink_reason = ?, invite_status = 'DISABLED', updated_at = ? WHERE employee_id = ? AND user_id = ? AND status = 'ACTIVE'")
      .bind(now, c.get("currentUser").id, reason, now, employeeId, userId)
      .run();
  } else {
    await c.env.DB.prepare("UPDATE employee_user_account_links SET status = 'DEACTIVATED', deactivated_at = ?, deactivated_by_user_id = ?, deactivation_reason = ?, invite_status = 'DISABLED', reset_required = 0, updated_at = ? WHERE employee_id = ? AND user_id = ? AND status = 'ACTIVE'")
      .bind(now, c.get("currentUser").id, reason, now, employeeId, userId)
      .run();
  }
}

async function markUserAccessOnboardingTask(db: AppBindings["Bindings"]["DB"], employeeId: string, actorUserId: string, status: "COMPLETED" | "PENDING", note: string) {
  const taskStatus = status === "COMPLETED" ? "COMPLETED" : "IN_PROGRESS";
  await db
    .prepare(
      `UPDATE employee_onboarding_tasks
       SET status = ?, task_status = ?, completed_by_user_id = CASE WHEN ? = 'COMPLETED' THEN ? ELSE completed_by_user_id END,
         completed_at = CASE WHEN ? = 'COMPLETED' THEN ? ELSE completed_at END,
         notes = ?, updated_at = ?
       WHERE employee_id = ? AND task_key IN ('user_access', 'user_access_setup')`
    )
    .bind(status, taskStatus, status, actorUserId, status, new Date().toISOString(), note, new Date().toISOString(), employeeId)
    .run();
}

async function validateEmployeeUserLink(c: Context<AppBindings>, employee: EmployeeRow, targetUser: DbUser, replaceExisting: boolean) {
  if (targetUser.employee_id && targetUser.employee_id !== employee.id) {
    const linked = await getEmployeeById(c.env.DB, targetUser.employee_id);
    return fail(c, 409, "USER_ALREADY_LINKED", `This user is already linked to ${linked?.full_name ?? "another employee"}.`);
  }
  if (employee.user_id && employee.user_id !== targetUser.id && !replaceExisting) {
    return fail(c, 409, "EMPLOYEE_ALREADY_LINKED", "This employee already has a linked user account.");
  }
  const otherEmployee = await c.env.DB.prepare("SELECT id, full_name FROM employees WHERE user_id = ? AND id != ? LIMIT 1").bind(targetUser.id, employee.id).first<{ id: string; full_name: string }>();
  if (otherEmployee) {
    return fail(c, 409, "USER_ALREADY_LINKED", `This user is already linked to ${otherEmployee.full_name}.`);
  }
  const otherUser = await c.env.DB.prepare("SELECT id, email FROM users WHERE employee_id = ? AND id != ? LIMIT 1").bind(employee.id, targetUser.id).first<{ id: string; email: string }>();
  if (otherUser) {
    return fail(c, 409, "EMPLOYEE_ALREADY_LINKED", `This employee is already linked to ${otherUser.email}.`);
  }
  return null;
}

async function validateRolesForEmployeeUserAccount(c: Context<AppBindings>, targetUser: DbUser | null, roleIds: string[]) {
  if (!roleIds.length) return null;
  if (!hasAnyPermission(c, employeeUserAccountPermissions("roles"))) {
    return fail(c, 403, "FORBIDDEN", "You do not have permission to assign user roles.");
  }
  const uniqueRoleIds = Array.from(new Set(roleIds));
  const roles: RoleAssignmentRow[] = [];
  for (const roleId of uniqueRoleIds) {
    const role = await c.env.DB.prepare("SELECT id, name, is_active, is_protected FROM roles WHERE id = ?").bind(roleId).first<RoleAssignmentRow>();
    if (!role) return fail(c, 400, "UNKNOWN_ROLE", "One or more selected roles do not exist.");
    if (role.is_active !== 1) return fail(c, 409, "INACTIVE_ROLE", "Inactive roles cannot be assigned to users.");
    if (role.is_protected === 1 && !hasPermission(c, "roles.assign_permissions")) {
      return fail(c, 403, "PROTECTED_ROLE_REQUIRES_PERMISSION", "Assigning a protected Owner/Super Admin role requires roles.assign_permissions.");
    }
    roles.push(role);
  }
  if (targetUser) {
    const ownerRole = await c.env.DB.prepare("SELECT id FROM roles WHERE is_protected = 1 AND name = 'Owner/Super Admin' LIMIT 1").first<{ id: string }>();
    const willOwn = ownerRole ? roles.some((role) => role.id === ownerRole.id) : false;
    if (targetUser.is_owner === 1 && !willOwn && targetUser.status === "ACTIVE" && (await getActiveOwnerCount(c.env.DB)) <= 1) {
      return fail(c, 409, "LAST_ACTIVE_OWNER", "The last active Owner user cannot lose the Owner role.");
    }
  }
  return null;
}

async function assignRolesToEmployeeUserAccount(c: Context<AppBindings>, targetUser: DbUser, roleIds: string[]) {
  const validationError = await validateRolesForEmployeeUserAccount(c, targetUser, roleIds);
  if (validationError) return validationError;
  const uniqueRoleIds = Array.from(new Set(roleIds));
  const roles: RoleAssignmentRow[] = [];
  for (const roleId of uniqueRoleIds) {
    const role = await c.env.DB.prepare("SELECT id, name, is_active, is_protected FROM roles WHERE id = ?").bind(roleId).first<RoleAssignmentRow>();
    if (!role) return fail(c, 400, "UNKNOWN_ROLE", "One or more selected roles do not exist.");
    if (role.is_active !== 1) return fail(c, 409, "INACTIVE_ROLE", "Inactive roles cannot be assigned to users.");
    if (role.is_protected === 1 && !hasPermission(c, "roles.assign_permissions")) {
      return fail(c, 403, "PROTECTED_ROLE_REQUIRES_PERMISSION", "Assigning a protected Owner/Super Admin role requires roles.assign_permissions.");
    }
    roles.push(role);
  }
  const ownerRole = await c.env.DB.prepare("SELECT id FROM roles WHERE is_protected = 1 AND name = 'Owner/Super Admin' LIMIT 1").first<{ id: string }>();
  const willOwn = ownerRole ? roles.some((role) => role.id === ownerRole.id) : false;
  if (targetUser.is_owner === 1 && !willOwn && targetUser.status === "ACTIVE" && (await getActiveOwnerCount(c.env.DB)) <= 1) {
    return fail(c, 409, "LAST_ACTIVE_OWNER", "The last active Owner user cannot lose the Owner role.");
  }
  const oldRoles = await getUserRolesForAccount(c.env.DB, targetUser.id);
  const writes: D1PreparedStatement[] = [c.env.DB.prepare("DELETE FROM user_roles WHERE user_id = ?").bind(targetUser.id)];
  for (const role of roles) {
    writes.push(c.env.DB.prepare("INSERT OR IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)").bind(targetUser.id, role.id));
  }
  writes.push(c.env.DB.prepare("UPDATE users SET is_owner = ?, updated_at = ? WHERE id = ?").bind(willOwn ? 1 : 0, new Date().toISOString(), targetUser.id));
  await c.env.DB.batch(writes);
  await recordAudit(c.env.DB, {
    actorUserId: c.get("currentUser").id,
    action: "employee.user_account.roles_updated",
    module: "employees",
    entityType: "user",
    entityId: targetUser.id,
    oldValue: { role_ids: oldRoles.map((role) => role.id), roles: oldRoles.map((role) => role.name), is_owner: targetUser.is_owner === 1 },
    newValue: { role_ids: roles.map((role) => role.id), roles: roles.map((role) => role.name), is_owner: willOwn },
    ipAddress: getClientIp(c.req.raw),
    userAgent: c.req.header("User-Agent") ?? null
  });
  return null;
}

async function buildEmployeeUserAccountResponse(c: Context<AppBindings>, employee: EmployeeRow, includeAvailableUsers = false) {
  const linkedUser = await getEmployeeUserAccountUser(c.env.DB, employee.user_id);
  const preview = await roleMappingPreviewForEmployee(c, employee.id);
  const roles = linkedUser ? await getUserRolesForAccount(c.env.DB, linkedUser.id) : [];
  const permissions = linkedUser ? await getPermissionsForAccount(c.env.DB, linkedUser.id) : [];
  const scopes = linkedUser ? await getUserScopesForAccount(c.env.DB, linkedUser.id) : [];
  const link = await getActiveEmployeeUserAccountLink(c.env.DB, employee.id);
  const linkHistory = await getEmployeeUserAccountLinkHistory(c.env.DB, employee.id);
  const employeeEmail = await getEmployeeEmailSuggestion(c.env.DB, employee);
  const usernameSuggestion = await uniqueUsernameSuggestion(c.env.DB, employee, employeeEmail.email);
  const availableScopes = includeAvailableUsers
    ? (await c.env.DB
      .prepare(
        `SELECT asr.*, r.name AS role_name, u.name AS user_name, u.email AS user_email,
          rmr.name AS role_mapping_name, rr.name AS role_mapping_role_name
         FROM access_scope_rules asr
         LEFT JOIN roles r ON r.id = asr.role_id
         LEFT JOIN users u ON u.id = asr.user_id
         LEFT JOIN role_mapping_rules rmr ON rmr.id = asr.role_mapping_rule_id
         LEFT JOIN roles rr ON rr.id = rmr.default_role_id
         WHERE asr.is_active = 1 AND asr.scope_owner_type IN ('ROLE', 'ROLE_MAPPING_RULE')
         ORDER BY asr.scope_owner_type, COALESCE(asr.module_key, 'all'), asr.name`
      )
      .all<AccessScopeRuleRow>()).results.map(accessScopeToApi)
    : [];
  return {
    employee: toEmployee(employee, hasPermission(c, "employees.sensitive.view")),
    linked_user: linkedUser ? {
      id: linkedUser.id,
      name: linkedUser.name,
      email: linkedUser.email,
      username: linkedUser.username,
      status: linkedUser.status,
      is_owner: linkedUser.is_owner === 1,
      employee_id: linkedUser.employee_id,
      employee_no: linkedUser.employee_no ?? null,
      employee_name: linkedUser.employee_name ?? null,
      last_login_at: linkedUser.last_login_at,
      created_at: linkedUser.created_at,
      updated_at: linkedUser.updated_at
    } : null,
    account_status: linkedUser ? linkedUser.status : link?.invite_status === "INVITE_RESET_PENDING" ? "Invite/reset pending" : "Not linked",
    invite_status: link?.invite_status ?? (linkedUser ? "PASSWORD_SET" : null),
    reset_required: Boolean(link?.reset_required),
    link: link ? {
      id: link.id,
      status: link.status,
      linked_at: link.linked_at,
      linked_by_user_id: link.linked_by_user_id,
      linked_by_name: link.linked_by_name ?? null,
      self_service_enabled_snapshot: link.self_service_enabled_snapshot === 1,
      invite_status: link.invite_status,
      reset_required: link.reset_required === 1,
      employee_email_used: link.employee_email_used,
      account_email_created: link.account_email_created,
      email_source: link.email_source,
      email_override_reason: link.email_override_reason
    } : null,
    link_history: linkHistory.map((item) => ({
      id: item.id,
      user_id: item.user_id,
      status: item.status,
      linked_at: item.linked_at,
      linked_by_name: item.linked_by_name ?? null,
      unlinked_at: item.unlinked_at,
      unlinked_by_name: item.unlinked_by_name ?? null,
      unlink_reason: item.unlink_reason,
      deactivated_at: item.deactivated_at,
      deactivated_by_name: item.deactivated_by_name ?? null,
      deactivation_reason: item.deactivation_reason,
      invite_status: item.invite_status,
      reset_required: item.reset_required === 1,
      account_email_created: item.account_email_created
    })),
    employee_email: employeeEmail,
    suggested_username: usernameSuggestion,
    roles: roles.map((role) => ({ id: role.id, name: role.name, is_active: role.is_active === 1, is_protected: role.is_protected === 1 })),
    role_ids: roles.map((role) => role.id),
    permissions,
    scopes,
    access_scope_ids: scopes.filter((scope) => scope.scope_owner_type === "USER").map((scope) => scope.id),
    self_service_enabled: Boolean(linkedUser && linkedUser.status === "ACTIVE" && permissions.some((permission) => permission === "self_service.view" || permission.startsWith("self_service."))),
    suggested: preview ? {
      suggested_role_mapping: preview.suggested_role_mapping,
      suggested_role: preview.suggested_role,
      suggested_scope: preview.suggested_scope
    } : null,
    available_users: includeAvailableUsers ? await getAvailableUsersForEmployeeLink(c.env.DB, employee.id) : [],
    available_access_scopes: availableScopes
  };
}

async function getStatusById(db: AppBindings["Bindings"]["DB"], id: string) {
  return db.prepare("SELECT * FROM employee_statuses WHERE id = ?").bind(id).first<EmployeeStatusRow>();
}

async function getStatusByKey(db: AppBindings["Bindings"]["DB"], key: string) {
  return db.prepare("SELECT * FROM employee_statuses WHERE key = ?").bind(key).first<EmployeeStatusRow>();
}

async function getNumberSettings(db: AppBindings["Bindings"]["DB"]) {
  let row = await db.prepare("SELECT * FROM employee_number_settings ORDER BY created_at LIMIT 1").first<NumberSettingsRow>();
  if (!row) {
    await db
      .prepare(
        `INSERT INTO employee_number_settings
         (id, prefix, include_year, include_location_code, include_department_code, sequence_padding, next_sequence, allow_manual_override, separator)
         VALUES ('employee_number_default', 'EMP', 0, 0, 0, 4, 1, 0, '-')`
      )
      .run();
    row = await db.prepare("SELECT * FROM employee_number_settings ORDER BY created_at LIMIT 1").first<NumberSettingsRow>();
  }
  return row!;
}

async function entityExists(db: AppBindings["Bindings"]["DB"], table: "departments" | "positions" | "locations" | "job_levels" | "employees" | "users", id: string) {
  return db.prepare(`SELECT id FROM ${table} WHERE id = ?`).bind(id).first<{ id: string }>();
}

async function activeEntityExists(db: AppBindings["Bindings"]["DB"], table: "departments" | "positions" | "locations" | "job_levels", id: string) {
  return db.prepare(`SELECT id FROM ${table} WHERE id = ? AND is_active = 1`).bind(id).first<{ id: string }>();
}

async function activeEmployeeExists(db: AppBindings["Bindings"]["DB"], id: string) {
  return db.prepare("SELECT id FROM employees WHERE id = ? AND archived_at IS NULL").bind(id).first<{ id: string }>();
}

async function createsReportingCycle(db: AppBindings["Bindings"]["DB"], employeeId: string, managerId: string) {
  let current: string | null = managerId;
  const visited = new Set<string>();
  while (current) {
    if (current === employeeId) return true;
    if (visited.has(current)) return true;
    visited.add(current);
    const row: { reporting_manager_employee_id: string | null } | null = await db.prepare("SELECT reporting_manager_employee_id FROM employees WHERE id = ? AND archived_at IS NULL").bind(current).first<{ reporting_manager_employee_id: string | null }>();
    current = row?.reporting_manager_employee_id ?? null;
  }
  return false;
}

async function readOrgCode(db: AppBindings["Bindings"]["DB"], table: "departments" | "locations", id: string | null) {
  if (!id) {
    return null;
  }
  const row = await db.prepare(`SELECT code FROM ${table} WHERE id = ?`).bind(id).first<{ code: string }>();
  return row?.code ?? null;
}

async function buildEmployeeNumber(db: AppBindings["Bindings"]["DB"], settings: NumberSettingsRow, input: { locationId?: string | null; departmentId?: string | null; sequence?: number }) {
  const separator = settings.separator || "-";
  const parts: string[] = [];
  if (settings.include_location_code === 1) {
    const code = await readOrgCode(db, "locations", input.locationId ?? null);
    if (code) {
      parts.push(code);
    }
  }
  if (settings.include_year === 1) {
    parts.push(String(new Date().getUTCFullYear()));
  }
  if (settings.prefix) {
    parts.push(settings.prefix);
  }
  if (settings.include_department_code === 1) {
    const code = await readOrgCode(db, "departments", input.departmentId ?? null);
    if (code) {
      parts.push(code);
    }
  }
  parts.push(String(input.sequence ?? settings.next_sequence).padStart(settings.sequence_padding, "0"));
  return parts.join(separator);
}

async function employeeNumberExists(db: AppBindings["Bindings"]["DB"], employeeNo: string, excludeId?: string) {
  let sql = "SELECT id FROM employees WHERE employee_no = ? COLLATE NOCASE";
  const params: BindValue[] = [employeeNo];
  if (excludeId) {
    sql += " AND id != ?";
    params.push(excludeId);
  }
  return db.prepare(sql).bind(...params).first<{ id: string }>();
}

async function getEmployeeById(db: AppBindings["Bindings"]["DB"], id: string) {
  return db
    .prepare(
      `SELECT e.*, s.key AS status_key, s.name AS status_name,
        d.name AS department_name, p.title AS position_title, l.name AS location_name, l.code AS location_code,
        jl.name AS job_level_name, m.full_name AS reporting_manager_name, u.email AS linked_user_email
       FROM employees e
       INNER JOIN employee_statuses s ON s.id = e.status_id
       LEFT JOIN departments d ON d.id = e.primary_department_id
       LEFT JOIN positions p ON p.id = e.primary_position_id
       LEFT JOIN locations l ON l.id = e.primary_location_id
       LEFT JOIN job_levels jl ON jl.id = e.job_level_id
       LEFT JOIN employees m ON m.id = e.reporting_manager_employee_id
       LEFT JOIN users u ON u.id = e.user_id
       WHERE e.id = ?`
    )
    .bind(id)
    .first<EmployeeRow>();
}

async function validateEmployeeRefs(
  c: Context<AppBindings>,
  input: {
    primary_department_id?: string | null;
    primary_position_id?: string | null;
    primary_location_id?: string | null;
    job_level_id?: string | null;
    reporting_manager_employee_id?: string | null;
    user_id?: string | null;
  },
  employeeId?: string
) {
  const refs = [
    ["departments", input.primary_department_id, "Selected department was not found or is inactive."],
    ["positions", input.primary_position_id, "Selected position was not found or is inactive."],
    ["locations", input.primary_location_id, "Selected location was not found or is inactive."],
    ["job_levels", input.job_level_id, "Selected job level was not found or is inactive."]
  ] as const;
  for (const [table, id, message] of refs) {
    if (id && !(await activeEntityExists(c.env.DB, table, id))) {
      return fail(c, 400, "INVALID_REFERENCE", message);
    }
  }
  const cascadeIssues = await validateOrganizationCascadeWithScope(c.env.DB, c.get("currentUser"), {
    department_id: input.primary_department_id,
    location_id: input.primary_location_id,
    position_id: input.primary_position_id,
    job_level_id: input.job_level_id
  });
  if (hasValidationErrors(cascadeIssues)) {
    return validationResponse(c, cascadeIssues);
  }
  if (input.reporting_manager_employee_id) {
    if (input.reporting_manager_employee_id === employeeId) {
      return fail(c, 400, "INVALID_MANAGER", "Reporting manager cannot be the employee.");
    }
    if (!(await activeEmployeeExists(c.env.DB, input.reporting_manager_employee_id))) {
      return fail(c, 400, "INVALID_MANAGER", "Reporting manager was not found or is inactive.");
    }
    if (employeeId && await createsReportingCycle(c.env.DB, employeeId, input.reporting_manager_employee_id)) {
      return fail(c, 400, "INVALID_MANAGER", "Reporting manager assignment would create a reporting cycle.");
    }
  }
  if (input.user_id) {
    if (!(await getUserById(c.env.DB, input.user_id))) {
      return fail(c, 400, "INVALID_USER", "Linked user was not found.");
    }
  }
  return null;
}

function readEmployeeInput(body: Record<string, unknown>) {
  const employeeType = typeof body.employee_type === "string" && EMPLOYEE_TYPES.has(body.employee_type as EmployeeType) ? (body.employee_type as EmployeeType) : null;
  const employmentType = typeof body.employment_type === "string" && EMPLOYMENT_TYPES.has(body.employment_type as EmploymentType) ? (body.employment_type as EmploymentType) : null;
  return {
    employee_no: optionalString(body.employee_no),
    full_name: readString(body.full_name),
    display_name: optionalString(body.display_name),
    gender: optionalString(body.gender),
    date_of_birth: optionalString(body.date_of_birth),
    nationality: optionalString(body.nationality),
    employee_type: employeeType,
    employment_type: employmentType,
    status_id: optionalString(body.status_id),
    primary_department_id: optionalString(body.primary_department_id),
    primary_position_id: optionalString(body.primary_position_id),
    primary_location_id: optionalString(body.primary_location_id),
    job_level_id: optionalString(body.job_level_id),
    joining_date: optionalString(body.joining_date),
    confirmation_date: optionalString(body.confirmation_date),
    contract_start_date: optionalString(body.contract_start_date),
    contract_end_date: optionalString(body.contract_end_date),
    probation_end_date: optionalString(body.probation_end_date),
    reporting_manager_employee_id: optionalString(body.reporting_manager_employee_id),
    payroll_included: boolValue(body.payroll_included, true),
    roster_eligible: boolValue(body.roster_eligible, true),
    user_id: optionalString(body.user_id),
    notes_summary: optionalString(body.notes_summary),
    effective_date: optionalString(body.effective_date),
    reason: optionalString(body.reason)
  };
}

function hasJobAssignment(input: ReturnType<typeof readEmployeeInput>) {
  return Boolean(input.primary_department_id || input.primary_position_id || input.primary_location_id || input.job_level_id || input.reporting_manager_employee_id);
}

function validateEmployeeInput(input: ReturnType<typeof readEmployeeInput>) {
  return [
    ...validateRequiredFields(input as Record<string, unknown>, {
      full_name: "Full name",
      employee_type: "Employee type",
      employment_type: "Employment type"
    }),
    ...validateEnumValue(input.employee_type, "employee_type", "Employee type", Array.from(EMPLOYEE_TYPES)),
    ...validateEnumValue(input.employment_type, "employment_type", "Employment type", Array.from(EMPLOYMENT_TYPES)),
    ...validateStringLength(input.employee_no, "employee_no", "Employee number", { max: 64 }),
    ...validateStringLength(input.full_name, "full_name", "Full name", { max: 200 }),
    ...validateStringLength(input.display_name, "display_name", "Display name", { max: 200 }),
    ...validateStringLength(input.notes_summary, "notes_summary", "Notes summary", { max: 1000 }),
    ...validateDateField(input.date_of_birth, "date_of_birth", "Date of birth", { allowFuture: false }),
    ...validateDateField(input.joining_date, "joining_date", "Joining date"),
    ...validateDateField(input.confirmation_date, "confirmation_date", "Confirmation date"),
    ...validateDateField(input.contract_start_date, "contract_start_date", "Contract start date"),
    ...validateDateField(input.contract_end_date, "contract_end_date", "Contract end date"),
    ...validateDateField(input.probation_end_date, "probation_end_date", "Probation end date"),
    ...validateDateRange({ start: input.contract_start_date, end: input.contract_end_date, startField: "contract_start_date", endField: "contract_end_date", label: "Contract end date" }),
    ...validateDateRange({ start: input.joining_date, end: input.confirmation_date, startField: "joining_date", endField: "confirmation_date", label: "Confirmation date" }),
    ...validateDateRange({ start: input.joining_date, end: input.probation_end_date, startField: "joining_date", endField: "probation_end_date", label: "Probation end date" })
  ];
}

async function createJobHistory(c: Context<AppBindings>, input: { employeeId: string; previous?: Partial<EmployeeRow>; next: ReturnType<typeof readEmployeeInput>; effectiveDate?: string | null; reason?: string | null }) {
  await c.env.DB
    .prepare(
      `INSERT INTO employee_job_history (
        id, employee_id, previous_department_id, new_department_id, previous_position_id, new_position_id,
        previous_location_id, new_location_id, previous_job_level_id, new_job_level_id,
        previous_reporting_manager_employee_id, new_reporting_manager_employee_id,
        effective_date, reason, created_by_user_id
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(
      crypto.randomUUID(),
      input.employeeId,
      input.previous?.primary_department_id ?? null,
      input.next.primary_department_id,
      input.previous?.primary_position_id ?? null,
      input.next.primary_position_id,
      input.previous?.primary_location_id ?? null,
      input.next.primary_location_id,
      input.previous?.job_level_id ?? null,
      input.next.job_level_id,
      input.previous?.reporting_manager_employee_id ?? null,
      input.next.reporting_manager_employee_id,
      input.effectiveDate ?? input.next.joining_date ?? new Date().toISOString().slice(0, 10),
      input.reason ?? null,
      c.get("currentUser").id
    )
    .run();
}

async function createOnboardingTasks(db: AppBindings["Bindings"]["DB"], employeeId: string) {
  await db.batch(
    onboardingTemplates.map(([key, title, module, description, required]) =>
      db
        .prepare(
          `INSERT OR IGNORE INTO employee_onboarding_tasks
           (id, employee_id, task_key, title, description, module, status, required)
           VALUES (?, ?, ?, ?, ?, ?, 'PENDING', ?)`
        )
        .bind(crypto.randomUUID(), employeeId, key, title, description, module, required)
    )
  );
}

employeeRoutes.get("/settings/statuses", requirePermission("employees.view"), async (c) => {
  const rows = await c.env.DB.prepare(`SELECT ${EMPLOYEE_STATUS_COLUMNS} FROM employee_statuses ORDER BY sort_order, name LIMIT 100`).all<EmployeeStatusRow>();
  return okCached(c, { statuses: rows.results.map(toStatus) }, 60, `employee-statuses-${rows.results.length}`);
});

employeeRoutes.post("/settings/statuses", requirePermission("employees.status.manage"), async (c) => {
  const body = await readJsonBody(c.req.raw);
  const key = readString(body.key).toUpperCase().replace(/[^A-Z0-9_]/g, "_");
  const name = readString(body.name);
  if (!key || !name) {
    return fail(c, 400, "VALIDATION_ERROR", "Status key and name are required.");
  }
  const existing = await getStatusByKey(c.env.DB, key);
  if (existing) {
    return fail(c, 409, "STATUS_KEY_EXISTS", "A status with this key already exists.");
  }
  const id = crypto.randomUUID();
  const input = readStatusInput(body);
  await c.env.DB
    .prepare(
      `INSERT INTO employee_statuses (
        id, key, name, description, is_protected, is_active, can_login, include_in_payroll,
        include_in_roster, show_in_active_lists, requires_exit_date, requires_exit_reason,
        requires_final_settlement, requires_document_clearance, requires_asset_clearance, sort_order
      ) VALUES (?, ?, ?, ?, 0, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(id, key, name, input.description, input.can_login ? 1 : 0, input.include_in_payroll ? 1 : 0, input.include_in_roster ? 1 : 0, input.show_in_active_lists ? 1 : 0, input.requires_exit_date ? 1 : 0, input.requires_exit_reason ? 1 : 0, input.requires_final_settlement ? 1 : 0, input.requires_document_clearance ? 1 : 0, input.requires_asset_clearance ? 1 : 0, input.sort_order)
    .run();
  const row = await getStatusById(c.env.DB, id);
  await auditEmployee(c, { action: "employee.status_setting.created", entityType: "employee_status", entityId: id, newValue: row });
  return ok(c, { status: row ? toStatus(row) : null }, 201);
});

employeeRoutes.patch("/settings/statuses/:id", requirePermission("employees.status.manage"), async (c) => {
  const status = await getStatusById(c.env.DB, c.req.param("id"));
  if (!status) {
    return fail(c, 404, "NOT_FOUND", "Employee status was not found.");
  }
  const body = await readJsonBody(c.req.raw);
  const name = readString(body.name);
  if (!name) {
    return fail(c, 400, "VALIDATION_ERROR", "Status name is required.");
  }
  const input = readStatusInput(body);
  await c.env.DB
    .prepare(
      `UPDATE employee_statuses SET name = ?, description = ?, can_login = ?, include_in_payroll = ?,
        include_in_roster = ?, show_in_active_lists = ?, requires_exit_date = ?, requires_exit_reason = ?,
        requires_final_settlement = ?, requires_document_clearance = ?, requires_asset_clearance = ?, sort_order = ?, updated_at = ?
       WHERE id = ?`
    )
    .bind(name, input.description, input.can_login ? 1 : 0, input.include_in_payroll ? 1 : 0, input.include_in_roster ? 1 : 0, input.show_in_active_lists ? 1 : 0, input.requires_exit_date ? 1 : 0, input.requires_exit_reason ? 1 : 0, input.requires_final_settlement ? 1 : 0, input.requires_document_clearance ? 1 : 0, input.requires_asset_clearance ? 1 : 0, input.sort_order, new Date().toISOString(), status.id)
    .run();
  const row = await getStatusById(c.env.DB, status.id);
  await auditEmployee(c, { action: "employee.status_setting.updated", entityType: "employee_status", entityId: status.id, oldValue: status, newValue: row });
  return ok(c, { status: row ? toStatus(row) : null });
});

employeeRoutes.post("/settings/statuses/:id/enable", requirePermission("employees.status.manage"), (c) => setStatusActive(c, 1));
employeeRoutes.post("/settings/statuses/:id/disable", requirePermission("employees.status.manage"), (c) => setStatusActive(c, 0));

employeeRoutes.get("/settings/numbering", requirePermission("employees.view"), async (c) => {
  return ok(c, { settings: toNumberSettings(await getNumberSettings(c.env.DB)) });
});

employeeRoutes.patch("/settings/numbering", requirePermission("employees.numbering.manage"), async (c) => {
  const oldSettings = await getNumberSettings(c.env.DB);
  const body = await readJsonBody(c.req.raw);
  const prefix = readString(body.prefix) || "EMP";
  const sequencePadding = Math.max(1, Math.min(12, numericValue(body.sequence_padding, oldSettings.sequence_padding)));
  const nextSequence = Math.max(1, numericValue(body.next_sequence, oldSettings.next_sequence));
  const separator = readString(body.separator) || "-";
  await c.env.DB
    .prepare(
      `UPDATE employee_number_settings
       SET prefix = ?, include_year = ?, include_location_code = ?, include_department_code = ?,
        sequence_padding = ?, next_sequence = ?, allow_manual_override = ?, separator = ?, updated_at = ?
       WHERE id = ?`
    )
    .bind(prefix, boolValue(body.include_year, false) ? 1 : 0, boolValue(body.include_location_code, false) ? 1 : 0, boolValue(body.include_department_code, false) ? 1 : 0, sequencePadding, nextSequence, boolValue(body.allow_manual_override, false) ? 1 : 0, separator, new Date().toISOString(), oldSettings.id)
    .run();
  const settings = await getNumberSettings(c.env.DB);
  await auditEmployee(c, { action: "employee.numbering_settings.updated", entityType: "employee_numbering", entityId: settings.id, oldValue: oldSettings, newValue: settings });
  return ok(c, { settings: toNumberSettings(settings) });
});

employeeRoutes.get("/settings/numbering/preview", requirePermission("employees.view"), async (c) => {
  const settings = await getNumberSettings(c.env.DB);
  const employee_no = await buildEmployeeNumber(c.env.DB, settings, {
    locationId: optionalString(c.req.query("location_id")),
    departmentId: optionalString(c.req.query("department_id"))
  });
  return ok(c, { employee_no });
});

employeeRoutes.get("/", requirePermission("employees.view"), async (c) => {
  const conditions: string[] = [];
  const params: BindValue[] = [];
  // Phase 4 verifier compatibility: const EMPLOYEE_LIST_DEFAULT_LIMIT and const EMPLOYEE_LIST_MAX_LIMIT are enforced through parsePaginationParams.
  const pagination = parsePaginationParams(c, { defaultLimit: 25, maxLimit: 100 });
  const scope = await timeStage(c, "permission", () => buildEmployeeScopeWhereClause(c.env.DB, c.get("currentUser"), "employees", "view", "e"));
  conditions.push(scope.sql);
  params.push(...scope.params);
  const search = readString(c.req.query("search"));
  if (search) {
    conditions.push("(e.employee_no LIKE ? OR e.full_name LIKE ? OR e.display_name LIKE ?)");
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  const filterMap = [
    ["status_id", "e.status_id"],
    ["employee_type", "e.employee_type"],
    ["employment_type", "e.employment_type"],
    ["department_id", "e.primary_department_id"],
    ["position_id", "e.primary_position_id"],
    ["location_id", "e.primary_location_id"],
    ["job_level_id", "e.job_level_id"]
  ] as const;
  for (const [queryKey, column] of filterMap) {
    const value = readString(c.req.query(queryKey));
    if (value) {
      conditions.push(`${column} = ?`);
      params.push(value);
    }
  }
  const userLinked = readString(c.req.query("user_linked"));
  if (userLinked === "linked") conditions.push("e.user_id IS NOT NULL");
  if (userLinked === "not_linked") conditions.push("e.user_id IS NULL");
  const joinedFrom = readString(c.req.query("joining_date_from"));
  if (joinedFrom) {
    conditions.push("date(e.joining_date) >= date(?)");
    params.push(joinedFrom);
  }
  const joinedTo = readString(c.req.query("joining_date_to"));
  if (joinedTo) {
    conditions.push("date(e.joining_date) <= date(?)");
    params.push(joinedTo);
  }
  if (c.req.query("show_archived") !== "true") {
    conditions.push("e.archived_at IS NULL");
  }
  const rows = await timeD1(c, () => c.env.DB
    .prepare(
      `SELECT
        e.id, e.employee_no, e.profile_photo_document_id, e.full_name, e.display_name,
        e.gender, e.date_of_birth, e.nationality, e.employee_type, e.employment_type,
        e.status_id, e.primary_department_id, e.primary_position_id, e.primary_location_id,
        e.job_level_id, e.joining_date, e.confirmation_date, e.contract_start_date,
        e.contract_end_date, e.probation_end_date, e.reporting_manager_employee_id,
        e.payroll_included, e.roster_eligible, e.user_id, e.exit_date, e.exit_reason,
        e.notes_summary, e.created_at, e.updated_at, e.archived_at,
        s.key AS status_key, s.name AS status_name,
        d.name AS department_name, p.title AS position_title, l.name AS location_name, l.code AS location_code,
        jl.name AS job_level_name, m.full_name AS reporting_manager_name,
        oc.id AS active_onboarding_case_id, oc.case_number AS active_onboarding_case_number,
        oc.onboarding_status AS active_onboarding_status, oc.activation_status AS active_activation_status
       FROM employees e
       INNER JOIN employee_statuses s ON s.id = e.status_id
       LEFT JOIN departments d ON d.id = e.primary_department_id
       LEFT JOIN positions p ON p.id = e.primary_position_id
       LEFT JOIN locations l ON l.id = e.primary_location_id
       LEFT JOIN job_levels jl ON jl.id = e.job_level_id
       LEFT JOIN employees m ON m.id = e.reporting_manager_employee_id
       LEFT JOIN employee_onboarding_cases oc ON oc.employee_id = e.id AND oc.onboarding_status != 'CANCELLED' AND oc.activation_status != 'ACTIVATED'
       ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
       ORDER BY e.created_at DESC
       LIMIT ? OFFSET ?`
    )
    .bind(...params, pagination.limit, pagination.offset)
    .all<EmployeeRow>(), "employees.list.lightweight");
  return ok(c, {
    employees: await timeStage(c, "serialization", async () => rows.results.map((row) => toEmployee(row, hasPermission(c, "employees.sensitive.view")))),
    pagination: paginationMeta(pagination, rows.results.length)
  });
});

employeeRoutes.get("/assignment-options", requirePermission("employees.view"), async (c) => {
  const [departments, locations, positions, jobLevels, managers] = await Promise.all([
    c.env.DB.prepare("SELECT id, code, name, parent_department_id, head_employee_id, manager_employee_id, is_active FROM departments WHERE is_active = 1 ORDER BY name").all(),
    c.env.DB.prepare("SELECT id, code, name, type, island_city, manager_employee_id, is_active FROM locations WHERE is_active = 1 ORDER BY name").all(),
    c.env.DB.prepare("SELECT id, code, title, department_id, level_id, is_active FROM positions WHERE is_active = 1 ORDER BY title").all(),
    c.env.DB.prepare("SELECT id, code, name, rank_order, is_active FROM job_levels WHERE is_active = 1 ORDER BY rank_order, name").all(),
    c.env.DB.prepare("SELECT e.id, e.employee_no, e.full_name, e.primary_department_id, e.primary_location_id, e.primary_position_id FROM employees e WHERE e.archived_at IS NULL ORDER BY e.full_name").all()
  ]);
  return okCached(c, {
    departments: departments.results,
    locations: locations.results,
    positions: positions.results,
    job_levels: jobLevels.results,
    reporting_managers: managers.results
  }, 60, `assignment-options-${departments.results.length}-${locations.results.length}-${positions.results.length}-${jobLevels.results.length}`);
});

employeeRoutes.post("/", requirePermission("employees.create"), async (c) => {
  const body = await readJsonBody(c.req.raw);
  const input = readEmployeeInput(body);
  const inputIssues = validateEmployeeInput(input);
  if (hasValidationErrors(inputIssues)) return validationResponse(c, inputIssues);
  const settings = await getNumberSettings(c.env.DB);
  let employeeNo = input.employee_no;
  if (employeeNo) {
    if (settings.allow_manual_override !== 1 || !hasPermission(c, "employees.numbering.manage")) {
      return fail(c, 403, "MANUAL_NUMBER_FORBIDDEN", "Manual employee number override is not allowed.");
    }
  } else {
    employeeNo = await buildEmployeeNumber(c.env.DB, settings, { locationId: input.primary_location_id, departmentId: input.primary_department_id });
  }
  if (await employeeNumberExists(c.env.DB, employeeNo)) {
    return fail(c, 409, "EMPLOYEE_NO_EXISTS", "Employee number already exists.");
  }
  let status = input.status_id ? await getStatusById(c.env.DB, input.status_id) : await getStatusByKey(c.env.DB, "PENDING_SETUP");
  if (!status && !input.status_id) {
    status = await getStatusByKey(c.env.DB, "DRAFT_ONBOARDING");
  }
  if (!status || status.is_active !== 1) {
    return fail(c, 400, "INVALID_STATUS", "Selected employee status was not found or is inactive.");
  }
  const refError = await validateEmployeeRefs(c, input);
  if (refError) {
    return refError;
  }
  const id = crypto.randomUUID();
  await c.env.DB
    .prepare(
      `INSERT INTO employees (
        id, employee_no, full_name, display_name, gender, date_of_birth, nationality,
        employee_type, employment_type, status_id, primary_department_id, primary_position_id,
        primary_location_id, job_level_id, joining_date, confirmation_date, contract_start_date,
        contract_end_date, probation_end_date, reporting_manager_employee_id, payroll_included,
        roster_eligible, user_id, notes_summary
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(id, employeeNo, input.full_name, input.display_name, input.gender, input.date_of_birth, input.nationality, input.employee_type, input.employment_type, status.id, input.primary_department_id, input.primary_position_id, input.primary_location_id, input.job_level_id, input.joining_date, input.confirmation_date, input.contract_start_date, input.contract_end_date, input.probation_end_date, input.reporting_manager_employee_id, input.payroll_included ? 1 : 0, input.roster_eligible ? 1 : 0, input.user_id, input.notes_summary)
    .run();
  if (!input.employee_no) {
    await c.env.DB.prepare("UPDATE employee_number_settings SET next_sequence = next_sequence + 1, updated_at = ? WHERE id = ?").bind(new Date().toISOString(), settings.id).run();
  }
  await createOnboardingTasks(c.env.DB, id);
  await autoCreateOnboardingCaseAfterEmployeeCreate(c, id);
  if (hasJobAssignment(input)) {
    await createJobHistory(c, { employeeId: id, next: input, effectiveDate: input.joining_date, reason: "Initial assignment" });
  }
  const employee = await getEmployeeById(c.env.DB, id);
  await auditEmployee(c, { action: "employee.created", entityType: "employee", entityId: id, newValue: employee });
  await publishEmployee(c, "employee.created", id, "created");
  return ok(c, { employee: employee ? toEmployee(employee, true) : null }, 201);
});

employeeRoutes.get("/:id/setup-readiness", requirePermission("employees.view"), async (c) => {
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  try {
    const preview = await getEmployeeSetupSectionPreviewPayload(c.env.DB, employeeId);
    c.header("Cache-Control", "private, no-store");
    c.header("Vary", "Origin");
    return ok(c, {
      mode: "employee_360_setup",
      employee_id: employeeId,
      activation_switched: false,
      activation_requires_final_verification: true,
      readiness: preview.readiness,
      sections: preview.sections
    });
  } catch (error) {
    const safe = sanitizeEmployeeSetupStatusError(error);
    return fail(c, 500, safe.error_code, `${safe.error_message} ${safe.next_action}`);
  }
});

employeeRoutes.post("/:id/setup-sections/rebuild", requirePermission("employees.view"), async (c) => {
  const employeeId = c.req.param("id");
  if (!hasAnyPermission(c, ["employees.update", "employees.lifecycle.manage", "onboarding.cases.manage", "onboarding.workspace.update"])) {
    return fail(c, 403, "FORBIDDEN", "You do not have permission to rebuild Employee 360 setup readiness.");
  }
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  try {
    const result = await rebuildEmployeeSetupSectionStatuses(c.env.DB, employeeId, c.get("currentUser").id);
    await auditEmployee(c, {
      action: "employee.setup_sections.rebuilt",
      entityType: "employee",
      entityId: employeeId,
      oldValue: null,
      newValue: {
        mode: "employee_360_setup",
        readiness_status: result.readiness.status,
        rebuilt_count: result.rebuilt_count,
        failed_count: result.failed_count
      }
    });
    c.header("Cache-Control", "private, no-store");
    c.header("Vary", "Origin");
    return ok(c, {
      mode: "employee_360_setup",
      employee_id: employeeId,
      activation_switched: false,
      activation_requires_final_verification: true,
      ...result
    });
  } catch (error) {
    const safe = sanitizeEmployeeSetupStatusError(error);
    return fail(c, 500, safe.error_code, `${safe.error_message} ${safe.next_action}`);
  }
});

employeeRoutes.get("/:id", requirePermission("employees.view"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  return ok(c, { employee: toEmployee(employee, hasPermission(c, "employees.sensitive.view")) });
});

employeeRoutes.patch("/:id", requirePermission("employees.update"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const existing = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!existing) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const body = await readJsonBody(c.req.raw);
  const input = readEmployeeInput(body);
  const inputIssues = validateEmployeeInput(input);
  if (hasValidationErrors(inputIssues)) return validationResponse(c, inputIssues);
  if (input.status_id && input.status_id !== existing.status_id) {
    return fail(c, 400, "STATUS_ENDPOINT_REQUIRED", "Use the employee status endpoint to change employee status.");
  }
  if ((input.gender !== existing.gender || input.date_of_birth !== existing.date_of_birth) && !hasPermission(c, "employees.sensitive.update")) {
    return fail(c, 403, "FORBIDDEN", "Sensitive employee fields require sensitive update permission.");
  }
  const settings = await getNumberSettings(c.env.DB);
  let employeeNo = existing.employee_no;
  if (input.employee_no && input.employee_no !== existing.employee_no) {
    if (settings.allow_manual_override !== 1 || !hasPermission(c, "employees.numbering.manage")) {
      return fail(c, 403, "MANUAL_NUMBER_FORBIDDEN", "Manual employee number override is not allowed.");
    }
    if (await employeeNumberExists(c.env.DB, input.employee_no, existing.id)) {
      return fail(c, 409, "EMPLOYEE_NO_EXISTS", "Employee number already exists.");
    }
    employeeNo = input.employee_no;
  }
  const refError = await validateEmployeeRefs(c, input, existing.id);
  if (refError) {
    return refError;
  }
  const jobChanged =
    input.primary_department_id !== existing.primary_department_id ||
    input.primary_position_id !== existing.primary_position_id ||
    input.primary_location_id !== existing.primary_location_id ||
    input.job_level_id !== existing.job_level_id ||
    input.reporting_manager_employee_id !== existing.reporting_manager_employee_id;
  const profileChanged =
    input.employee_no !== existing.employee_no ||
    input.full_name !== existing.full_name ||
    input.display_name !== existing.display_name ||
    input.gender !== existing.gender ||
    input.date_of_birth !== existing.date_of_birth ||
    input.nationality !== existing.nationality ||
    input.employee_type !== existing.employee_type ||
    input.employment_type !== existing.employment_type ||
    input.joining_date !== existing.joining_date;
  await c.env.DB
    .prepare(
      `UPDATE employees SET employee_no = ?, full_name = ?, display_name = ?, gender = ?, date_of_birth = ?,
        nationality = ?, employee_type = ?, employment_type = ?, primary_department_id = ?, primary_position_id = ?,
        primary_location_id = ?, job_level_id = ?, joining_date = ?, confirmation_date = ?, contract_start_date = ?,
        contract_end_date = ?, probation_end_date = ?, reporting_manager_employee_id = ?, payroll_included = ?,
        roster_eligible = ?, user_id = ?, notes_summary = ?, updated_at = ?
       WHERE id = ?`
    )
    .bind(employeeNo, input.full_name, input.display_name, input.gender, input.date_of_birth, input.nationality, input.employee_type, input.employment_type, input.primary_department_id, input.primary_position_id, input.primary_location_id, input.job_level_id, input.joining_date, input.confirmation_date, input.contract_start_date, input.contract_end_date, input.probation_end_date, input.reporting_manager_employee_id, input.payroll_included ? 1 : 0, input.roster_eligible ? 1 : 0, input.user_id, input.notes_summary, new Date().toISOString(), existing.id)
    .run();
  if (jobChanged) {
    await createJobHistory(c, { employeeId: existing.id, previous: existing, next: input, effectiveDate: input.effective_date, reason: input.reason ?? "Profile job assignment updated" });
    await auditEmployee(c, { action: "employee.job_changed", entityType: "employee", entityId: existing.id, oldValue: existing, newValue: input, reason: input.reason });
  }
  const employee = await getEmployeeById(c.env.DB, existing.id);
  await auditEmployee(c, { action: "employee.updated", entityType: "employee", entityId: existing.id, oldValue: existing, newValue: employee });
  await publishEmployee(c, "employee.updated", existing.id, "updated");
  const staleSectionKeys = [
    input.employee_type !== existing.employee_type ? "documents" : null,
    input.employment_type !== existing.employment_type ? "documents" : null,
    input.employment_type !== existing.employment_type ? "contract" : null,
    input.employment_type !== existing.employment_type ? "payroll_profile" : null,
    input.employment_type !== existing.employment_type ? "payment_method" : null,
    input.joining_date !== existing.joining_date ? "job_assignment" : null,
    input.joining_date !== existing.joining_date ? "attendance_roster" : null,
    input.joining_date !== existing.joining_date ? "payroll_profile" : null,
    input.joining_date !== existing.joining_date ? "documents" : null,
    jobChanged ? "documents" : null,
    jobChanged ? "contract" : null,
    jobChanged ? "payroll_profile" : null,
    jobChanged ? "payment_method" : null,
    jobChanged ? "attendance_roster" : null,
    jobChanged ? "assets_uniforms" : null,
    jobChanged ? "approval_tasks" : null
  ].filter(Boolean) as Array<"documents" | "contract" | "payroll_profile" | "payment_method" | "job_assignment" | "attendance_roster" | "assets_uniforms" | "approval_tasks">;
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, {
    employeeId: existing.id,
    savedSectionKey: jobChanged && !profileChanged ? "job_assignment" : "profile_information",
    affectedSectionKeys: [profileChanged ? "profile_information" : null, jobChanged ? "job_assignment" : null].filter(Boolean) as Array<"profile_information" | "job_assignment">,
    staleSectionKeys
  });
  return ok(c, employeeSetupStatusUpdateResponse({ employee: employee ? toEmployee(employee, hasPermission(c, "employees.sensitive.view")) : null }, setupStatusUpdate));
});

employeeRoutes.post("/:id/status", requirePermission("employees.status.manage"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const body = await readJsonBody(c.req.raw);
  const statusId = readString(body.status_id);
  const status = statusId ? await getStatusById(c.env.DB, statusId) : null;
  if (!status || status.is_active !== 1) {
    return fail(c, 400, "INVALID_STATUS", "Selected employee status was not found or is inactive.");
  }
  const exitDate = optionalString(body.exit_date);
  const exitReason = optionalString(body.exit_reason) ?? optionalString(body.reason);
  if (status.requires_exit_date === 1 && !exitDate) {
    return fail(c, 400, "EXIT_DATE_REQUIRED", "Exit date is required for this status.");
  }
  if (status.requires_exit_reason === 1 && !exitReason) {
    return fail(c, 400, "EXIT_REASON_REQUIRED", "Exit reason is required for this status.");
  }
  await c.env.DB
    .prepare("UPDATE employees SET status_id = ?, exit_date = ?, exit_reason = ?, updated_at = ? WHERE id = ?")
    .bind(status.id, exitDate ?? employee.exit_date, exitReason ?? employee.exit_reason, new Date().toISOString(), employee.id)
    .run();
  const updated = await getEmployeeById(c.env.DB, employee.id);
  await auditEmployee(c, { action: "employee.status_changed", entityType: "employee", entityId: employee.id, oldValue: { status_id: employee.status_id }, newValue: { status_id: status.id, exit_date: exitDate, exit_reason: exitReason }, reason: exitReason });
  await publishEmployee(c, "employee.status_changed", employee.id, "status_changed");
  return ok(c, { employee: updated ? toEmployee(updated, hasPermission(c, "employees.sensitive.view")) : null });
});

employeeRoutes.post("/:id/archive", requirePermission("employees.archive"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const body = await readJsonBody(c.req.raw);
  const reason = optionalString(body.reason);
  if (!reason) {
    return fail(c, 400, "REASON_REQUIRED", "Archive reason is required.");
  }
  const archivedStatus = await getStatusByKey(c.env.DB, "ARCHIVED");
  await c.env.DB
    .prepare("UPDATE employees SET status_id = ?, archived_at = ?, updated_at = ? WHERE id = ?")
    .bind(archivedStatus?.id ?? employee.status_id, new Date().toISOString(), new Date().toISOString(), employee.id)
    .run();
  const updated = await getEmployeeById(c.env.DB, employee.id);
  await auditEmployee(c, { action: "employee.archived", entityType: "employee", entityId: employee.id, oldValue: employee, newValue: updated, reason });
  await publishEmployee(c, "employee.archived", employee.id, "archived");
  return ok(c, { employee: updated ? toEmployee(updated, hasPermission(c, "employees.sensitive.view")) : null });
});

employeeRoutes.get("/:id/overview", requirePermission("employees.view"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const [tasks, contacts, audit] = await Promise.all([
    c.env.DB.prepare(`SELECT ${EMPLOYEE_ONBOARDING_TASK_COLUMNS} FROM employee_onboarding_tasks WHERE employee_id = ? ORDER BY required DESC, created_at LIMIT 100`).bind(employee.id).all(),
    c.env.DB.prepare(`SELECT ${EMPLOYEE_CONTACT_COLUMNS} FROM employee_contacts WHERE employee_id = ? AND archived_at IS NULL ORDER BY contact_type, emergency_priority LIMIT 25`).bind(employee.id).all<ContactRow>(),
    c.env.DB.prepare(
      `SELECT ${EMPLOYEE_OVERVIEW_AUDIT_COLUMNS} FROM audit_logs
       WHERE (module = 'employees' AND entity_id = ?)
           OR (module = 'leave' AND entity_id IN (SELECT id FROM leave_requests WHERE employee_id = ?))
            OR (module = 'attendance' AND (
              entity_id IN (SELECT id FROM attendance_daily_records WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM attendance_correction_requests WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM attendance_raw_logs WHERE employee_id = ?)
            ))
            OR (module = 'roster' AND (
              entity_id IN (SELECT id FROM roster_assignments WHERE employee_id = ?)
              OR entity_id IN (SELECT roster_assignment_id FROM roster_assignment_history WHERE employee_id = ?)
            ))
            OR (module = 'payroll' AND (
              entity_id IN (SELECT id FROM employee_payroll_profiles WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM employee_salary_history WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM employee_increments WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM payroll_advance_payments WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM payroll_deductions WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM payroll_adjustments WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM payroll_run_employees WHERE employee_id = ?)
              OR entity_id IN (SELECT id FROM final_settlements WHERE employee_id = ?)
            ))
         ORDER BY created_at DESC LIMIT 8`
    ).bind(employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id, employee.id).all()
  ]);
  return ok(c, {
    employee: toEmployee(employee, hasPermission(c, "employees.sensitive.view")),
    onboarding: tasks.results,
    contacts: contacts.results.map((contact) => toContact(contact, hasPermission(c, "employees.sensitive.view"))),
    audit: audit.results
  });
});

employeeRoutes.get("/:id/user-access", requirePermission("role_mappings.view"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const preview = await roleMappingPreviewForEmployee(c, c.req.param("id"));
  if (!preview) return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  return ok(c, { preview });
});

employeeRoutes.post("/:id/user-access/apply", requirePermission("role_mappings.apply"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const body = await readJsonBody(c.req.raw).catch(() => ({} as Record<string, unknown>));
  return applyRoleMappingToEmployee(c, c.req.param("id"), optionalString(body.role_mapping_rule_id));
});

employeeRoutes.get("/:id/user-account", async (c) => {
  const permissionError = requireEmployeeUserAccountPermission(c, "view");
  if (permissionError) return permissionError;
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee) return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  const includeAvailableUsers = hasAnyPermission(c, employeeUserAccountPermissions("link"));
  return ok(c, { user_account: await buildEmployeeUserAccountResponse(c, employee, includeAvailableUsers) });
});

employeeRoutes.post("/:id/user-account/link-existing", async (c) => {
  const permissionError = requireEmployeeUserAccountPermission(c, "link");
  if (permissionError) return permissionError;
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee) return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  const body = await readJsonBody(c.req.raw);
  const userId = readString(body.user_id);
  if (!userId) return fail(c, 400, "USER_REQUIRED", "Select a user account to link.");
  const targetUser = await getUserById(c.env.DB, userId);
  if (!targetUser) return fail(c, 404, "USER_NOT_FOUND", "Selected user account was not found.");
  const replaceExisting = boolValue(body.replace_existing, false);
  const linkError = await validateEmployeeUserLink(c, employee, targetUser, replaceExisting);
  if (linkError) return linkError;
  const roleIds = arrayOfStrings(body.role_ids);
  const roleError = await validateRolesForEmployeeUserAccount(c, targetUser, roleIds);
  if (roleError) return roleError;
  const preparedScopes = await prepareUserAccessScopeAssignments(c, body, targetUser.id);
  if (preparedScopes.error) return preparedScopes.error;
  const selfServiceEnabled = boolValue(body.self_service_enabled, false);
  const now = new Date().toISOString();
  const writes: D1PreparedStatement[] = [
    c.env.DB.prepare("UPDATE employees SET user_id = ?, updated_at = ? WHERE id = ?").bind(targetUser.id, now, employee.id),
    c.env.DB.prepare("UPDATE users SET employee_id = ?, updated_at = ? WHERE id = ?").bind(employee.id, now, targetUser.id)
  ];
  if (employee.user_id && employee.user_id !== targetUser.id) {
    writes.push(c.env.DB.prepare("UPDATE users SET employee_id = NULL, updated_at = ? WHERE id = ?").bind(now, employee.user_id));
  }
  await c.env.DB.batch(writes);
  if (roleIds.length) {
    const assignedRoleError = await assignRolesToEmployeeUserAccount(c, targetUser, roleIds);
    if (assignedRoleError) return assignedRoleError;
  }
  if (selfServiceEnabled) {
    await ensureSelfOnlyScopeForUser(c.env.DB, targetUser.id, c.get("currentUser").id);
  }
  await applyPreparedUserAccessScopes(c, targetUser.id, preparedScopes.assignments);
  await upsertActiveEmployeeUserAccountLink(c, {
    employeeId: employee.id,
    userId: targetUser.id,
    selfServiceEnabled,
    inviteStatus: "PASSWORD_SET",
    resetRequired: false,
    employeeEmailUsed: (await getEmployeeEmailSuggestion(c.env.DB, employee)).email,
    accountEmailCreated: targetUser.email,
    emailSource: "linked_existing_user"
  });
  await markUserAccessOnboardingTask(c.env.DB, employee.id, c.get("currentUser").id, "COMPLETED", "Linked to an existing user account.");
  await auditEmployee(c, {
    action: "employee.user_account.linked",
    entityType: "employee",
    entityId: employee.id,
    oldValue: { user_id: employee.user_id },
    newValue: { user_id: targetUser.id, email: targetUser.email, role_ids: roleIds, access_scope_ids: arrayOfStrings(body.access_scope_ids), self_service_enabled: selfServiceEnabled },
    reason: optionalString(body.reason)
  });
  await publishEmployeeUserAccountChanged(c, employee.id, targetUser.id, "linked");
  const updated = await getEmployeeById(c.env.DB, employee.id);
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId: employee.id, savedSectionKey: "user_access" });
  return ok(c, employeeSetupStatusUpdateResponse({ user_account: updated ? await buildEmployeeUserAccountResponse(c, updated, true) : null }, setupStatusUpdate));
});

employeeRoutes.post("/:id/user-account/provision", async (c) => {
  const permissionError = requireEmployeeUserAccountPermission(c, "manage");
  if (permissionError) return permissionError;
  if (!hasAnyPermission(c, ["users.create", "employee.user_account.manage", "self_service.manage_access"])) {
    return fail(c, 403, "FORBIDDEN", "You do not have permission to provision user accounts.");
  }
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee) return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  const body = await readJsonBody(c.req.raw);
  const name = readString(body.name) || employee.display_name || employee.full_name;
  const employeeEmail = await getEmployeeEmailSuggestion(c.env.DB, employee);
  const requestedEmail = normalizeEmail(body.email);
  const email = requestedEmail || employeeEmail.email || "";
  const username = readString(body.username) || await uniqueUsernameSuggestion(c.env.DB, employee, email || employeeEmail.email);
  const password = readString(body.password);
  const generatedPassword = password || `${crypto.randomUUID()}Aa1!`;
  const passwordlessInvite = !password;
  const status = typeof body.status === "string" && ["ACTIVE", "DISABLED", "LOCKED"].includes(body.status) ? (body.status as UserStatus) : "ACTIVE";
  const selfServiceEnabled = boolValue(body.self_service_enabled, true);
  let roleIds = arrayOfStrings(body.role_ids);
  if (!name) return fail(c, 400, "VALIDATION_ERROR", "User name is required.");
  if (!email) return fail(c, 400, "EMAIL_REQUIRED", employeeEmail.message);
  if (!isEmail(email)) return fail(c, 400, "VALIDATION_ERROR", "A valid email address is required.");
  if (!isStrongPassword(generatedPassword)) return fail(c, 400, "VALIDATION_ERROR", "Password must be at least 12 characters and include letters and numbers.");
  const existingEmail = await getUserByEmail(c.env.DB, email);
  if (existingEmail) {
    if (!existingEmail.employee_id) return fail(c, 409, "EMAIL_EXISTS_LINK_EXISTING", "A standalone user already uses this email. Link the existing user instead of creating a duplicate.");
    if (existingEmail.employee_id === employee.id || employee.user_id === existingEmail.id) return fail(c, 409, "EMAIL_ALREADY_LINKED_TO_EMPLOYEE", "This email already belongs to the linked employee user account.");
    return fail(c, 409, "EMAIL_LINKED_TO_ANOTHER_EMPLOYEE", "This email is already linked to another employee user account.");
  }
  if (username) {
    const existingUsername = await c.env.DB.prepare("SELECT id FROM users WHERE username = ? COLLATE NOCASE").bind(username).first<{ id: string }>();
    if (existingUsername) return fail(c, 409, "USERNAME_EXISTS", "A user with this username already exists.");
  }
  if (employee.user_id && !boolValue(body.replace_existing, false)) {
    return fail(c, 409, "EMPLOYEE_ALREADY_LINKED", "This employee already has a linked user account.");
  }
  if (selfServiceEnabled && roleIds.length === 0) {
    const selfServiceRole = await employeeSelfServiceRoleId(c.env.DB);
    if (selfServiceRole) roleIds = [selfServiceRole];
  }
  const roleError = await validateRolesForEmployeeUserAccount(c, null, roleIds);
  if (roleError) return roleError;
  const preparedScopes = await prepareUserAccessScopeAssignments(c, body);
  if (preparedScopes.error) return preparedScopes.error;
  const userId = crypto.randomUUID();
  const now = new Date().toISOString();
  await c.env.DB.batch([
    c.env.DB
      .prepare(
        `INSERT INTO users (id, name, email, username, password_hash, status, is_owner, employee_id)
         VALUES (?, ?, ?, ?, ?, ?, 0, ?)`
      )
      .bind(userId, name, email, username || null, await hashPassword(generatedPassword), status, employee.id),
    c.env.DB.prepare("UPDATE employees SET user_id = ?, updated_at = ? WHERE id = ?").bind(userId, now, employee.id),
    ...(employee.user_id && employee.user_id !== userId ? [c.env.DB.prepare("UPDATE users SET employee_id = NULL, updated_at = ? WHERE id = ?").bind(now, employee.user_id)] : [])
  ]);
  const newUser = await getUserById(c.env.DB, userId);
  if (newUser && roleIds.length) {
    const roleError = await assignRolesToEmployeeUserAccount(c, newUser, roleIds);
    if (roleError) return roleError;
  }
  if (selfServiceEnabled) {
    await ensureSelfOnlyScopeForUser(c.env.DB, userId, c.get("currentUser").id);
  }
  await applyPreparedUserAccessScopes(c, userId, preparedScopes.assignments);
  await upsertActiveEmployeeUserAccountLink(c, {
    employeeId: employee.id,
    userId,
    selfServiceEnabled,
    inviteStatus: passwordlessInvite ? "INVITE_RESET_PENDING" : "PASSWORD_SET",
    resetRequired: passwordlessInvite || boolValue(body.reset_required, Boolean(password)),
    employeeEmailUsed: employeeEmail.email,
    accountEmailCreated: email,
    emailSource: requestedEmail ? (requestedEmail === employeeEmail.email ? "employee_email_prefilled" : "manual_override") : "employee_email_fallback",
    emailOverrideReason: requestedEmail && requestedEmail !== employeeEmail.email ? optionalString(body.email_override_reason ?? body.reason) : null
  });
  await markUserAccessOnboardingTask(c.env.DB, employee.id, c.get("currentUser").id, "COMPLETED", "Provisioned linked user account.");
  await auditEmployee(c, {
    action: "employee.user_account.provisioned",
    entityType: "employee",
    entityId: employee.id,
    oldValue: { user_id: employee.user_id },
    newValue: {
      user_id: userId,
      employee_email_used: employeeEmail.email,
      account_email_created: email,
      email_source: requestedEmail ? (requestedEmail === employeeEmail.email ? "employee_email_prefilled" : "manual_override") : "employee_email_fallback",
      username: username || null,
      status,
      invite_status: passwordlessInvite ? "INVITE_RESET_PENDING" : "PASSWORD_SET",
      reset_required: passwordlessInvite || boolValue(body.reset_required, Boolean(password)),
      self_service_enabled: selfServiceEnabled,
      role_ids: roleIds,
      access_scope_ids: arrayOfStrings(body.access_scope_ids)
    },
    reason: optionalString(body.reason)
  });
  await publishEmployeeUserAccountChanged(c, employee.id, userId, "provisioned");
  const updated = await getEmployeeById(c.env.DB, employee.id);
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId: employee.id, savedSectionKey: "user_access" });
  return ok(c, employeeSetupStatusUpdateResponse({ user_account: updated ? await buildEmployeeUserAccountResponse(c, updated, true) : null }, setupStatusUpdate), 201);
});

employeeRoutes.patch("/:id/user-account", async (c) => {
  const permissionError = requireEmployeeUserAccountPermission(c, "manage");
  if (permissionError) return permissionError;
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee?.user_id) return fail(c, 404, "NO_LINKED_USER", "This employee does not have a linked user account.");
  const targetUser = await getUserById(c.env.DB, employee.user_id);
  if (!targetUser) return fail(c, 404, "USER_NOT_FOUND", "Linked user account was not found.");
  const body = await readJsonBody(c.req.raw);
  const name = readString(body.name) || targetUser.name;
  const email = typeof body.email === "string" ? normalizeEmail(body.email) : targetUser.email;
  const username = typeof body.username === "string" ? readString(body.username) : targetUser.username;
  const status = typeof body.status === "string" && ["ACTIVE", "DISABLED", "LOCKED"].includes(body.status) ? (body.status as UserStatus) : targetUser.status;
  if (!name) return fail(c, 400, "VALIDATION_ERROR", "User name is required.");
  if (!isEmail(email)) return fail(c, 400, "VALIDATION_ERROR", "A valid email address is required.");
  const existingEmail = await getUserByEmail(c.env.DB, email);
  if (existingEmail && existingEmail.id !== targetUser.id) return fail(c, 409, "EMAIL_EXISTS", "A user with this email already exists.");
  if (username) {
    const existingUsername = await c.env.DB.prepare("SELECT id FROM users WHERE username = ? COLLATE NOCASE").bind(username).first<{ id: string }>();
    if (existingUsername && existingUsername.id !== targetUser.id) return fail(c, 409, "USERNAME_EXISTS", "A user with this username already exists.");
  }
  if (targetUser.is_owner === 1 && targetUser.status === "ACTIVE" && status !== "ACTIVE" && (await getActiveOwnerCount(c.env.DB)) <= 1) {
    return fail(c, 409, "LAST_ACTIVE_OWNER", "The last active Owner user cannot be disabled or locked.");
  }
  const preparedScopes = await prepareUserAccessScopeAssignments(c, body, targetUser.id);
  if (preparedScopes.error) return preparedScopes.error;
  const resetRequired = boolValue(body.reset_required, false);
  const requestedInviteStatus = optionalString(body.invite_status);
  const inviteStatus = resetRequired
    ? "RESET_REQUIRED"
    : requestedInviteStatus && ["PASSWORD_SET", "INVITE_RESET_PENDING", "RESET_REQUIRED", "DISABLED"].includes(requestedInviteStatus)
      ? requestedInviteStatus
      : null;
  await c.env.DB.prepare("UPDATE users SET name = ?, email = ?, username = ?, status = ?, updated_at = ? WHERE id = ?").bind(name, email, username || null, status, new Date().toISOString(), targetUser.id).run();
  if (Array.isArray(body.role_ids)) {
    const roleError = await assignRolesToEmployeeUserAccount(c, { ...targetUser, name, email, username: username || null, status }, arrayOfStrings(body.role_ids));
    if (roleError) return roleError;
  }
  if (boolValue(body.self_service_enabled, false)) {
    await ensureSelfOnlyScopeForUser(c.env.DB, targetUser.id, c.get("currentUser").id);
  }
  await applyPreparedUserAccessScopes(c, targetUser.id, preparedScopes.assignments);
  if (resetRequired || inviteStatus) {
    const now = new Date().toISOString();
    await c.env.DB
      .prepare(
        `UPDATE employee_user_account_links
         SET invite_status = ?, reset_required = ?, updated_at = ?
         WHERE employee_id = ? AND user_id = ? AND status = 'ACTIVE'`
      )
      .bind(resetRequired ? "RESET_REQUIRED" : inviteStatus, resetRequired ? 1 : 0, now, employee.id, targetUser.id)
      .run();
  }
  await auditEmployee(c, {
    action: "employee.user_account.updated",
    entityType: "user",
    entityId: targetUser.id,
    oldValue: { name: targetUser.name, email: targetUser.email, username: targetUser.username, status: targetUser.status },
    newValue: { name, email, username: username || null, status, employee_id: employee.id, self_service_scope_ensured: boolValue(body.self_service_enabled, false), reset_required: resetRequired, invite_status: resetRequired ? "RESET_REQUIRED" : inviteStatus, access_scope_ids: arrayOfStrings(body.access_scope_ids) },
    reason: optionalString(body.reason)
  });
  await publishEmployeeUserAccountChanged(c, employee.id, targetUser.id, "updated");
  const updated = await getEmployeeById(c.env.DB, employee.id);
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId: employee.id, savedSectionKey: "user_access" });
  return ok(c, employeeSetupStatusUpdateResponse({ user_account: updated ? await buildEmployeeUserAccountResponse(c, updated, true) : null }, setupStatusUpdate));
});

employeeRoutes.post("/:id/user-account/unlink", async (c) => {
  const permissionError = requireEmployeeUserAccountPermission(c, "unlink");
  if (permissionError) return permissionError;
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee?.user_id) return fail(c, 404, "NO_LINKED_USER", "This employee does not have a linked user account.");
  const body = await readJsonBody(c.req.raw).catch(() => ({} as Record<string, unknown>));
  const reason = optionalString(body.reason);
  if (!reason) return fail(c, 400, "REASON_REQUIRED", "Reason is required to unlink a user account.");
  const targetUser = await getUserById(c.env.DB, employee.user_id);
  const disableUser = boolValue(body.disable_user, false);
  if (targetUser?.is_owner === 1 && disableUser && targetUser.status === "ACTIVE" && (await getActiveOwnerCount(c.env.DB)) <= 1) {
    return fail(c, 409, "LAST_ACTIVE_OWNER", "The last active Owner user cannot be disabled.");
  }
  const now = new Date().toISOString();
  await c.env.DB.batch([
    c.env.DB.prepare("UPDATE employees SET user_id = NULL, updated_at = ? WHERE id = ?").bind(now, employee.id),
    c.env.DB.prepare("UPDATE users SET employee_id = NULL, status = CASE WHEN ? = 1 THEN 'DISABLED' ELSE status END, updated_at = ? WHERE id = ?").bind(disableUser ? 1 : 0, now, employee.user_id)
  ]);
  await markEmployeeUserAccountLinkInactive(c, employee.id, employee.user_id, disableUser ? "DEACTIVATED" : "UNLINKED", reason);
  await markUserAccessOnboardingTask(c.env.DB, employee.id, c.get("currentUser").id, "PENDING", "User account was unlinked. " + reason);
  await auditEmployee(c, {
    action: "employee.user_account.unlinked",
    entityType: "employee",
    entityId: employee.id,
    oldValue: { user_id: employee.user_id },
    newValue: { user_id: null, disabled_user: disableUser },
    reason
  });
  await publishEmployeeUserAccountChanged(c, employee.id, employee.user_id, "unlinked");
  const updated = await getEmployeeById(c.env.DB, employee.id);
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId: employee.id, savedSectionKey: "user_access" });
  return ok(c, employeeSetupStatusUpdateResponse({ user_account: updated ? await buildEmployeeUserAccountResponse(c, updated, true) : null }, setupStatusUpdate));
});

employeeRoutes.post("/:id/user-account/deactivate-for-exit", async (c) => {
  const permissionError = requireEmployeeUserAccountPermission(c, "deactivate");
  if (permissionError) return permissionError;
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, employeeId);
  if (!employee?.user_id) return fail(c, 404, "NO_LINKED_USER", "This employee does not have a linked user account.");
  const body = await readJsonBody(c.req.raw).catch(() => ({} as Record<string, unknown>));
  const reason = optionalString(body.reason);
  if (!reason) return fail(c, 400, "REASON_REQUIRED", "Exit deactivation reason is required.");
  const targetUser = await getUserById(c.env.DB, employee.user_id);
  if (!targetUser) return fail(c, 404, "USER_NOT_FOUND", "Linked user account was not found.");
  if (targetUser.is_owner === 1 && targetUser.status === "ACTIVE" && (await getActiveOwnerCount(c.env.DB)) <= 1) {
    return fail(c, 409, "LAST_ACTIVE_OWNER", "The last active Owner user cannot be disabled.");
  }
  await c.env.DB.prepare("UPDATE users SET status = 'DISABLED', updated_at = ? WHERE id = ?").bind(new Date().toISOString(), targetUser.id).run();
  await markEmployeeUserAccountLinkInactive(c, employee.id, targetUser.id, "DEACTIVATED", reason);
  await c.env.DB.prepare("UPDATE employee_offboarding_tasks SET task_status = 'COMPLETED', completed_by_user_id = ?, completed_at = ?, updated_at = ?, notes = COALESCE(notes, 'Linked user account disabled for exit.') WHERE employee_id = ? AND task_key = 'user_access'").bind(c.get("currentUser").id, new Date().toISOString(), new Date().toISOString(), employee.id).run();
  await auditEmployee(c, {
    action: "employee.user_account.deactivated_for_exit",
    entityType: "user",
    entityId: targetUser.id,
    oldValue: { status: targetUser.status, employee_id: employee.id },
    newValue: { status: "DISABLED", employee_id: employee.id },
    reason
  });
  await publishEmployeeUserAccountChanged(c, employee.id, targetUser.id, "deactivated_for_exit");
  const updated = await getEmployeeById(c.env.DB, employee.id);
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId: employee.id, savedSectionKey: "user_access" });
  return ok(c, employeeSetupStatusUpdateResponse({ user_account: updated ? await buildEmployeeUserAccountResponse(c, updated, true) : null }, setupStatusUpdate));
});

employeeRoutes.get("/:id/contacts", requirePermission("employees.contacts.view"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const rows = await c.env.DB.prepare(`SELECT ${EMPLOYEE_CONTACT_COLUMNS} FROM employee_contacts WHERE employee_id = ? AND archived_at IS NULL ORDER BY contact_type, emergency_priority, created_at LIMIT 50`).bind(employee.id).all<ContactRow>();
  return ok(c, { contacts: rows.results.map((contact) => toContact(contact, hasPermission(c, "employees.sensitive.view"))) });
});

employeeRoutes.post("/:id/contacts", requirePermission("employees.contacts.manage"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  return saveContact(c, employee.id);
});

employeeRoutes.patch("/:id/contacts/:contactId", requirePermission("employees.contacts.manage"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  return saveContact(c, employee.id, c.req.param("contactId"));
});

employeeRoutes.post("/:id/contacts/:contactId/archive", requirePermission("employees.contacts.manage"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const contact = await c.env.DB.prepare("SELECT * FROM employee_contacts WHERE id = ? AND employee_id = ?").bind(c.req.param("contactId"), c.req.param("id")).first<ContactRow>();
  if (!contact) {
    return fail(c, 404, "NOT_FOUND", "Contact was not found.");
  }
  await c.env.DB.prepare("UPDATE employee_contacts SET archived_at = ?, updated_at = ? WHERE id = ?").bind(new Date().toISOString(), new Date().toISOString(), contact.id).run();
  await auditEmployee(c, { action: "employee.contact.archived", entityType: "employee_contact", entityId: contact.id, oldValue: contact, reason: optionalString((await readJsonBody(c.req.raw)).reason) });
  await publishEmployee(c, "employee.updated", contact.employee_id, "contact_archived");
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId: contact.employee_id, savedSectionKey: "contact_emergency" });
  return ok(c, employeeSetupStatusUpdateResponse({ archived: true }, setupStatusUpdate));
});

employeeRoutes.get("/:id/job-history", requirePermission("employees.job_history.view"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const rows = await c.env.DB
    .prepare(
      `SELECT h.*,
        pd.name AS previous_department_name, nd.name AS new_department_name,
        pp.title AS previous_position_title, np.title AS new_position_title,
        pl.name AS previous_location_name, nl.name AS new_location_name,
        pjl.name AS previous_job_level_name, njl.name AS new_job_level_name,
        cb.name AS created_by_name, ab.name AS approved_by_name
       FROM employee_job_history h
       LEFT JOIN departments pd ON pd.id = h.previous_department_id
       LEFT JOIN departments nd ON nd.id = h.new_department_id
       LEFT JOIN positions pp ON pp.id = h.previous_position_id
       LEFT JOIN positions np ON np.id = h.new_position_id
       LEFT JOIN locations pl ON pl.id = h.previous_location_id
       LEFT JOIN locations nl ON nl.id = h.new_location_id
       LEFT JOIN job_levels pjl ON pjl.id = h.previous_job_level_id
       LEFT JOIN job_levels njl ON njl.id = h.new_job_level_id
       LEFT JOIN users cb ON cb.id = h.created_by_user_id
       LEFT JOIN users ab ON ab.id = h.approved_by_user_id
       WHERE h.employee_id = ?
       ORDER BY h.effective_date DESC, h.created_at DESC`
    )
    .bind(c.req.param("id"))
    .all();
  return ok(c, { job_history: rows.results });
});

employeeRoutes.post("/:id/job-history", requirePermission("employees.job_history.manage"), async (c) => {
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const employee = await getEmployeeById(c.env.DB, c.req.param("id"));
  if (!employee) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const body = await readJsonBody(c.req.raw);
  const input = readEmployeeInput({ ...employee, ...body });
  const effectiveDate = optionalString(body.effective_date);
  if (!effectiveDate) {
    return fail(c, 400, "VALIDATION_ERROR", "Effective date is required for job history changes.");
  }
  const refError = await validateEmployeeRefs(c, input, employee.id);
  if (refError) {
    return refError;
  }
  await createJobHistory(c, { employeeId: employee.id, previous: employee, next: input, effectiveDate, reason: optionalString(body.reason) });
  await c.env.DB
    .prepare("UPDATE employees SET primary_department_id = ?, primary_position_id = ?, primary_location_id = ?, job_level_id = ?, reporting_manager_employee_id = ?, updated_at = ? WHERE id = ?")
    .bind(input.primary_department_id, input.primary_position_id, input.primary_location_id, input.job_level_id, input.reporting_manager_employee_id, new Date().toISOString(), employee.id)
    .run();
  await auditEmployee(c, { action: "employee.job_changed", entityType: "employee", entityId: employee.id, oldValue: employee, newValue: input, reason: optionalString(body.reason) });
  await publishEmployee(c, "employee.updated", employee.id, "job_changed");
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, {
    employeeId: employee.id,
    savedSectionKey: "job_assignment",
    staleSectionKeys: ["documents", "contract", "payroll_profile", "payment_method", "attendance_roster", "assets_uniforms", "approval_tasks"]
  });
  return ok(c, employeeSetupStatusUpdateResponse({ employee: toEmployee((await getEmployeeById(c.env.DB, employee.id))!, hasPermission(c, "employees.sensitive.view")) }, setupStatusUpdate));
});

employeeRoutes.get("/:id/onboarding", requirePermission("employees.view"), async (c) => {
  const disabled = await requireOperationalModuleEnabled(c, "onboarding", "Onboarding");
  if (disabled) return disabled;
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const rows = await c.env.DB.prepare(`SELECT ${EMPLOYEE_ONBOARDING_TASK_COLUMNS} FROM employee_onboarding_tasks WHERE employee_id = ? ORDER BY required DESC, created_at LIMIT 100`).bind(c.req.param("id")).all();
  return ok(c, { onboarding: rows.results });
});

employeeRoutes.patch("/:id/onboarding/:taskId", requirePermission("employees.onboarding.manage"), async (c) => {
  const disabled = await requireOperationalModuleEnabled(c, "onboarding", "Onboarding");
  if (disabled) return disabled;
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), c.req.param("id"), "employees", "manage"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const body = await readJsonBody(c.req.raw);
  const status = body.status;
  if (typeof status !== "string" || !ONBOARDING_STATUSES.has(status as OnboardingStatus)) {
    return fail(c, 400, "VALIDATION_ERROR", "Onboarding status must be PENDING, COMPLETED, SKIPPED, or BLOCKED.");
  }
  const task = await c.env.DB.prepare("SELECT * FROM employee_onboarding_tasks WHERE id = ? AND employee_id = ?").bind(c.req.param("taskId"), c.req.param("id")).first();
  if (!task) {
    return fail(c, 404, "NOT_FOUND", "Onboarding task was not found.");
  }
  const completedAt = status === "COMPLETED" ? new Date().toISOString() : null;
  const completedBy = status === "COMPLETED" ? c.get("currentUser").id : null;
  await c.env.DB
    .prepare("UPDATE employee_onboarding_tasks SET status = ?, completed_at = ?, completed_by_user_id = ?, updated_at = ? WHERE id = ?")
    .bind(status, completedAt, completedBy, new Date().toISOString(), c.req.param("taskId"))
    .run();
  const updated = await c.env.DB.prepare("SELECT * FROM employee_onboarding_tasks WHERE id = ?").bind(c.req.param("taskId")).first();
  await auditEmployee(c, { action: "employee.onboarding_task.updated", entityType: "employee_onboarding_task", entityId: c.req.param("taskId"), oldValue: task, newValue: updated });
  await publishEmployee(c, "employee.onboarding_changed", c.req.param("id"), "onboarding_changed");
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId: c.req.param("id"), savedSectionKey: "approval_tasks" });
  return ok(c, employeeSetupStatusUpdateResponse({ task: updated as Record<string, unknown> }, setupStatusUpdate));
});

employeeRoutes.get("/:id/audit", requirePermission("employees.view"), async (c) => {
  const employeeId = c.req.param("id");
  if (!(await canAccessEmployee(c.env.DB, c.get("currentUser"), employeeId, "employees", "view"))) {
    return fail(c, 404, "NOT_FOUND", "Employee was not found.");
  }
  const rows = await c.env.DB.prepare(
    `SELECT * FROM audit_logs
     WHERE (module = 'employees' AND (entity_id = ? OR new_value_json LIKE ?))
        OR (module = 'payroll' AND (
          entity_id IN (SELECT id FROM employee_payroll_profiles WHERE employee_id = ?)
          OR entity_id IN (SELECT id FROM employee_salary_history WHERE employee_id = ?)
          OR entity_id IN (SELECT id FROM employee_increments WHERE employee_id = ?)
          OR entity_id IN (SELECT id FROM payroll_advance_payments WHERE employee_id = ?)
          OR entity_id IN (SELECT id FROM payroll_deductions WHERE employee_id = ?)
          OR entity_id IN (SELECT id FROM payroll_adjustments WHERE employee_id = ?)
          OR entity_id IN (SELECT id FROM payroll_run_employees WHERE employee_id = ?)
          OR entity_id IN (SELECT id FROM final_settlements WHERE employee_id = ?)
        ))
     ORDER BY created_at DESC LIMIT 100`
  ).bind(employeeId, `%${employeeId}%`, employeeId, employeeId, employeeId, employeeId, employeeId, employeeId, employeeId, employeeId).all();
  return ok(c, { audit: rows.results });
});

function readStatusInput(body: Record<string, unknown>) {
  return {
    description: optionalString(body.description),
    can_login: boolValue(body.can_login, false),
    include_in_payroll: boolValue(body.include_in_payroll, false),
    include_in_roster: boolValue(body.include_in_roster, false),
    show_in_active_lists: boolValue(body.show_in_active_lists, false),
    requires_exit_date: boolValue(body.requires_exit_date, false),
    requires_exit_reason: boolValue(body.requires_exit_reason, false),
    requires_final_settlement: boolValue(body.requires_final_settlement, false),
    requires_document_clearance: boolValue(body.requires_document_clearance, false),
    requires_asset_clearance: boolValue(body.requires_asset_clearance, false),
    sort_order: numericValue(body.sort_order, 100)
  };
}

async function setStatusActive(c: Context<AppBindings>, active: 0 | 1) {
  const id = c.req.param("id");
  if (!id) {
    return fail(c, 400, "VALIDATION_ERROR", "Status id is required.");
  }
  const status = await getStatusById(c.env.DB, id);
  if (!status) {
    return fail(c, 404, "NOT_FOUND", "Employee status was not found.");
  }
  if (active === 0) {
    const used = await c.env.DB.prepare("SELECT COUNT(*) AS count FROM employees WHERE status_id = ?").bind(status.id).first<{ count: number }>();
    if ((used?.count ?? 0) > 0) {
      return fail(c, 409, "STATUS_IN_USE", "This status is currently used by employees and cannot be disabled.");
    }
  }
  await c.env.DB.prepare("UPDATE employee_statuses SET is_active = ?, updated_at = ? WHERE id = ?").bind(active, new Date().toISOString(), status.id).run();
  const updated = await getStatusById(c.env.DB, status.id);
  await auditEmployee(c, {
    action: active === 1 ? "employee.status_setting.enabled" : "employee.status_setting.disabled",
    entityType: "employee_status",
    entityId: status.id,
    oldValue: status,
    newValue: updated
  });
  return ok(c, { status: updated ? toStatus(updated) : null });
}

async function saveContact(c: Context<AppBindings>, employeeId: string, contactId?: string) {
  const body = await readJsonBody(c.req.raw);
  const contactType = typeof body.contact_type === "string" && CONTACT_TYPES.has(body.contact_type as ContactType) ? (body.contact_type as ContactType) : null;
  const value = readString(body.value);
  const isSensitive = boolValue(body.is_sensitive, false);
  if (!contactType || !value) {
    return fail(c, 400, "VALIDATION_ERROR", "Contact type and value are required.");
  }
  if (isSensitive && !hasPermission(c, "employees.sensitive.update")) {
    return fail(c, 403, "FORBIDDEN", "Sensitive contacts require sensitive update permission.");
  }
  const old = contactId ? await c.env.DB.prepare("SELECT * FROM employee_contacts WHERE id = ? AND employee_id = ?").bind(contactId, employeeId).first<ContactRow>() : null;
  if (contactId && !old) {
    return fail(c, 404, "NOT_FOUND", "Contact was not found.");
  }
  if (boolValue(body.is_primary, false)) {
    await c.env.DB.prepare("UPDATE employee_contacts SET is_primary = 0, updated_at = ? WHERE employee_id = ? AND contact_type = ?").bind(new Date().toISOString(), employeeId, contactType).run();
  }
  const id = contactId ?? crypto.randomUUID();
  if (old) {
    await c.env.DB
      .prepare(
        `UPDATE employee_contacts SET contact_type = ?, value = ?, country_code = ?, relationship = ?, is_primary = ?,
          emergency_priority = ?, is_sensitive = ?, notes = ?, updated_at = ? WHERE id = ?`
      )
      .bind(contactType, value, optionalString(body.country_code), optionalString(body.relationship), boolValue(body.is_primary, false) ? 1 : 0, body.emergency_priority === null || body.emergency_priority === undefined ? null : numericValue(body.emergency_priority, 0), isSensitive ? 1 : 0, optionalString(body.notes), new Date().toISOString(), id)
      .run();
  } else {
    await c.env.DB
      .prepare(
        `INSERT INTO employee_contacts
         (id, employee_id, contact_type, value, country_code, relationship, is_primary, emergency_priority, is_sensitive, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(id, employeeId, contactType, value, optionalString(body.country_code), optionalString(body.relationship), boolValue(body.is_primary, false) ? 1 : 0, body.emergency_priority === null || body.emergency_priority === undefined ? null : numericValue(body.emergency_priority, 0), isSensitive ? 1 : 0, optionalString(body.notes))
      .run();
  }
  const contact = await c.env.DB.prepare("SELECT * FROM employee_contacts WHERE id = ?").bind(id).first<ContactRow>();
  await auditEmployee(c, {
    action: old ? "employee.contact.updated" : "employee.contact.created",
    entityType: "employee_contact",
    entityId: id,
    oldValue: old,
    newValue: contact
  });
  await publishEmployee(c, "employee.updated", employeeId, old ? "contact_updated" : "contact_created");
  const setupStatusUpdate = await updateEmployeeSetupSectionStatusAfterSave(c, { employeeId, savedSectionKey: "contact_emergency" });
  return ok(c, employeeSetupStatusUpdateResponse({ contact: contact ? toContact(contact, hasPermission(c, "employees.sensitive.view")) : null }, setupStatusUpdate), old ? 200 : 201);
}
