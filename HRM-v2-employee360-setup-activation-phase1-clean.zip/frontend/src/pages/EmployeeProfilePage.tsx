import { Archive, ArrowLeft, CheckCircle2, Pencil } from "lucide-react";
import { type FormEvent, type ReactNode, useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ChangeEmployeeStatusModal } from "../components/employee/ChangeEmployeeStatusModal";
import { EmployeeAttendancePanel } from "../components/attendance/EmployeeAttendancePanel";
import { EmployeeAuditPanel } from "../components/audit/EmployeeAuditPanel";
import { EmployeeAssetsPanel } from "../components/assets/EmployeeAssetsPanel";
import { EmployeeAvatar } from "../components/employee/EmployeeAvatar";
import { EmployeeContractsPanel } from "../components/employee/EmployeeContractsPanel";
import { EmployeeDocumentsPanel } from "../components/employee/EmployeeDocumentsPanel";
import { EmployeeProfileCard } from "../components/employee/EmployeeIdentityCell";
import { EmployeeProfilePhotoControls } from "../components/employee/EmployeeProfilePhotoControls";
import { EmployeeLeavePanel } from "../components/leave/EmployeeLeavePanel";
import { EmployeeFinalSettlementPanel } from "../components/payroll/EmployeeFinalSettlementPanel";
import { EmployeeNotesPanel } from "../components/notes/EmployeeNotesPanel";
import { EmployeePayrollPanel } from "../components/payroll/EmployeePayrollPanel";
import { EmployeeRosterPanel } from "../components/roster/EmployeeRosterPanel";
import { PageLoader, TableSkeleton } from "../components/loading";
import { Badge } from "../components/ui/badge";
import { Button, RowActionButton } from "../components/ui/button";
import { EmptyState } from "../components/ui/empty-state";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { AlertBanner, CheckboxField, PageShell, ResponsiveTabs, SelectField } from "../components/ui/page-shell";
import { Panel } from "../components/ui/panel";
import { StatusBadge } from "../components/ui/status-badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { useAuth } from "../hooks/useAuth";
import { useWorkspaceQuery } from "../hooks/useWorkspaceQuery";
import { ApiError, api } from "../lib/api";
import { queryKeys } from "../lib/queryKeys";
import type { AccessScopeRule, EmployeeUserAccessPreview, EmployeeUserAccount, Role, UserStatus } from "../types/auth";
import type { Employee, EmployeeContact, EmployeeContactInput, EmployeeSetupReadinessResponse, EmployeeSetupSectionStatusRow, EmployeeStatusSetting, OnboardingStatus, OnboardingTask } from "../types/employees";
import type { LifecycleSummary, LifecycleTask } from "../types/lifecycle";

const profileTabs = ["Overview", "Personal Info", "Job Info", "Contracts", "Contacts", "User Access", "Lifecycle", "Payroll", "Final Settlement", "Attendance", "Roster", "Leave", "Documents", "Assets & Uniforms", "Notes", "Audit Log"] as const;
type ProfileTab = (typeof profileTabs)[number];
type EmployeeProfileWorkspacePayload = {
  overview: {
    employee: Employee;
    onboarding: OnboardingTask[];
    contacts: EmployeeContact[];
    audit: Record<string, unknown>[];
  };
  statuses: EmployeeStatusSetting[];
  lifecycle: LifecycleSummary | null;
  setup: EmployeeSetupReadinessResponse | null;
};

function tone(status?: string) {
  if (status === "ACTIVE" || status === "ON_LEAVE") return "success";
  if (status === "DRAFT_ONBOARDING" || status === "PENDING_SETUP" || status === "PENDING_FINAL_VERIFICATION" || status === "PENDING_APPROVAL") return "warning";
  if (status === "ARCHIVED") return "neutral";
  return "danger";
}

function setupTone(status?: string) {
  if (status === "ready" || status === "complete" || status === "verified" || status === "not_required") return "success";
  if (status === "blocked" || status === "incomplete" || status === "not_started" || status === "stale") return "warning";
  if (status === "failed") return "danger";
  return "neutral";
}

export function EmployeeProfilePage() {
  const { id } = useParams();
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<ProfileTab>("Overview");
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [statuses, setStatuses] = useState<EmployeeStatusSetting[]>([]);
  const [contacts, setContacts] = useState<EmployeeContact[]>([]);
  const [onboarding, setOnboarding] = useState<OnboardingTask[]>([]);
  const [jobHistory, setJobHistory] = useState<Record<string, unknown>[]>([]);
  const [audit, setAudit] = useState<Record<string, unknown>[]>([]);
  const [profileRequests, setProfileRequests] = useState<Record<string, unknown>[]>([]);
  const [userAccess, setUserAccess] = useState<EmployeeUserAccessPreview | null>(null);
  const [userAccount, setUserAccount] = useState<EmployeeUserAccount | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [lifecycle, setLifecycle] = useState<LifecycleSummary | null>(null);
  const [setupReadiness, setSetupReadiness] = useState<EmployeeSetupReadinessResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [contactModal, setContactModal] = useState<{ mode: "create" | "edit"; contact?: EmployeeContact } | null>(null);
  const [archiveReason, setArchiveReason] = useState("");
  const [contactArchiveTarget, setContactArchiveTarget] = useState<EmployeeContact | null>(null);
  const [contactArchiveReason, setContactArchiveReason] = useState("");
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [statusModalError, setStatusModalError] = useState<string | null>(null);
  const [statusSaving, setStatusSaving] = useState(false);
  const [setupRebuilding, setSetupRebuilding] = useState(false);
  const [loadedTabs, setLoadedTabs] = useState<Partial<Record<ProfileTab, boolean>>>({});
  const [tabLoading, setTabLoading] = useState<Partial<Record<ProfileTab, boolean>>>({});

  const permissions = new Set(user?.permissions ?? []);
  const assetsUniformsVisible = user?.module_visibility?.assets_uniforms !== false;
  const visibleProfileTabs = useMemo(
    () => assetsUniformsVisible ? [...profileTabs] : profileTabs.filter((tab) => tab !== "Assets & Uniforms"),
    [assetsUniformsVisible]
  );
  const canView = permissions.has("employees.view");
  const canArchive = permissions.has("employees.archive");
  const canStatus = permissions.has("employees.status.manage");
  const canContacts = permissions.has("employees.contacts.manage");
  const canOnboarding = permissions.has("employees.onboarding.manage");
  const canLeave = permissions.has("employees.leave.view") || permissions.has("leave.view");
  const canAttendance = permissions.has("employees.attendance.view") || permissions.has("attendance.view");
  const canRoster = permissions.has("employees.roster.view") || permissions.has("roster.view");
  const canContracts = permissions.has("employees.contracts.view") || permissions.has("contracts.view");
  const canPayroll = permissions.has("employees.payroll.view") || permissions.has("payroll.view");
  const canFinalSettlement = permissions.has("employees.final_settlement.view") || permissions.has("final_settlement.view") || permissions.has("final_settlement.cases.view");
  const canAssets = assetsUniformsVisible && (permissions.has("employees.assets.view") || permissions.has("assets.view"));
  const canNotes = permissions.has("employee_notes.view");
  const canAudit = permissions.has("employees.audit.view") || permissions.has("audit.view");
  const canViewUserAccess = permissions.has("employee.user_account.view") || permissions.has("users.view") || permissions.has("role_mappings.view");
  const canManageUserAccess = permissions.has("employee.user_account.manage") || permissions.has("users.link_employee") || permissions.has("users.update") || permissions.has("self_service.manage_access");
  const canApplyUserAccess = permissions.has("role_mappings.apply");
  const canViewLifecycle = permissions.has("employees.lifecycle.view") || permissions.has("onboarding.cases.view") || permissions.has("offboarding.cases.view");
  const canRebuildSetup = permissions.has("employees.update") || permissions.has("employees.lifecycle.manage") || permissions.has("onboarding.cases.manage") || permissions.has("onboarding.workspace.update");
  const canUploadPhoto = permissions.has("documents.upload");
  const canClearPhoto = permissions.has("documents.archive");
  const canViewDuringOnboarding = permissions.has("employees.360.view_during_onboarding");

  const profileWorkspaceQuery = useWorkspaceQuery<EmployeeProfileWorkspacePayload>({
    workspaceName: "employee-profile",
    queryKey: (scope) => queryKeys.employee.workspace(scope, id ?? "unknown"),
    enabled: Boolean(id && canView),
    placeholderData: (previousData) => previousData?.overview.employee.id === id ? previousData : undefined,
    queryFn: async ({ token, signal }) => {
      const [overview, statusesResult, lifecycleResult, setupResult] = await Promise.all([
        api.getEmployeeOverview(token, id!, signal),
        api.listEmployeeStatuses(token, signal),
        canViewLifecycle
          ? api.getEmployeeLifecycleSummary(token, id!, signal).then((result) => result.summary).catch(() => null)
          : Promise.resolve(null),
        api.getEmployeeSetupReadiness(token, id!, signal).catch(() => null)
      ]);
      return {
        overview,
        statuses: statusesResult.statuses,
        lifecycle: lifecycleResult,
        setup: setupResult
      };
    }
  });

  useEffect(() => {
    const payload = profileWorkspaceQuery.data;
    if (!payload) return;
    setEmployee(payload.overview.employee);
    setStatuses(payload.statuses);
    setContacts(payload.overview.contacts);
    setOnboarding(payload.overview.onboarding);
    setAudit(payload.overview.audit);
    setLifecycle(payload.lifecycle);
    setSetupReadiness(payload.setup);
    setError(null);
  }, [profileWorkspaceQuery.data]);

  useEffect(() => {
    if (profileWorkspaceQuery.error && !profileWorkspaceQuery.data) {
      setError(profileWorkspaceQuery.error instanceof ApiError ? profileWorkspaceQuery.error.message : "Unable to load Employee 360 profile.");
    }
  }, [profileWorkspaceQuery.data, profileWorkspaceQuery.error]);

  const load = useCallback(async () => {
    if (!token || !id || !canView) return;
    setError(null);
    try {
      const result = await profileWorkspaceQuery.refetch();
      if (result.error) throw result.error;
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to load Employee 360 profile.");
    }
  }, [token, id, canView, profileWorkspaceQuery]);

  const loadTabData = useCallback(async (tab: ProfileTab, force = false) => {
    if (!token || !id || !employee) return;
    if (!force && loadedTabs[tab]) return;
    const needsData = tab === "Personal Info" || tab === "Job Info" || tab === "User Access";
    if (!needsData) return;
    setTabLoading((current) => ({ ...current, [tab]: true }));
    try {
      if (tab === "Job Info") {
        try {
          setJobHistory((await api.listEmployeeJobHistory(token, id)).job_history);
        } catch {
          setJobHistory([]);
        }
      }
      if (tab === "Personal Info") {
        try {
          const requests = (await api.listKycRequests(token, { search: employee.employee_no })).requests;
          setProfileRequests(requests.filter((request) => request.employee_id === id));
        } catch {
          setProfileRequests([]);
        }
      }
      if (tab === "User Access") {
        if (canViewUserAccess) {
          try {
            const account = (await api.getEmployeeUserAccount(token, id)).user_account;
            setUserAccount(account);
            setUserAccess((await api.getEmployeeUserAccess(token, id)).preview);
          } catch {
            setUserAccount(null);
            setUserAccess(null);
          }
        }
        if (canManageUserAccess || canApplyUserAccess) {
          try {
            setRoles((await api.listRoles(token)).roles);
          } catch {
            setRoles([]);
          }
        }
      }
      setLoadedTabs((current) => ({ ...current, [tab]: true }));
    } finally {
      setTabLoading((current) => ({ ...current, [tab]: false }));
    }
  }, [canApplyUserAccess, canManageUserAccess, canViewUserAccess, employee, id, loadedTabs, token]);

  useEffect(() => {
    if (!visibleProfileTabs.includes(activeTab)) setActiveTab("Overview");
  }, [activeTab, visibleProfileTabs]);

  useEffect(() => {
    setLoadedTabs({});
    setTabLoading({});
  }, [id]);

  useEffect(() => {
    void loadTabData(activeTab);
  }, [activeTab, loadTabData]);

  async function archive() {
    if (!token || !employee) return;
    try {
      await api.archiveEmployee(token, employee.id, archiveReason.trim());
      setArchiveReason("");
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to archive employee.");
    }
  }

  async function changeStatus(input: { status_id: string; reason?: string | null; exit_date?: string | null; exit_reason?: string | null }) {
    if (!token || !employee) return;
    setStatusSaving(true);
    setStatusModalError(null);
    try {
      await api.changeEmployeeStatus(token, employee.id, input);
      setStatusModalOpen(false);
      await load();
    } catch (err) {
      setStatusModalError(err instanceof ApiError ? err.message : "Unable to change status.");
    } finally {
      setStatusSaving(false);
    }
  }

  async function updateTask(task: OnboardingTask, status: OnboardingStatus) {
    if (!token || !employee) return;
    try {
      await api.updateEmployeeOnboardingTask(token, employee.id, task.id, status);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to update onboarding task.");
    }
  }

  async function saveContact(input: EmployeeContactInput) {
    if (!token || !employee) return;
    try {
      if (contactModal?.mode === "edit" && contactModal.contact) {
        await api.updateEmployeeContact(token, employee.id, contactModal.contact.id, input);
      } else {
        await api.createEmployeeContact(token, employee.id, input);
      }
      setContactModal(null);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to save contact.");
    }
  }

  async function archiveContact(contact: EmployeeContact) {
    if (!token || !employee) return;
    try {
      await api.archiveEmployeeContact(token, employee.id, contact.id, contactArchiveReason);
      setContactArchiveTarget(null);
      setContactArchiveReason("");
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to archive contact.");
    }
  }

  async function applyUserAccessMapping(mappingId?: string | null) {
    if (!token || !employee) return;
    try {
      setUserAccess((await api.applyEmployeeRoleMapping(token, employee.id, mappingId)).preview);
      await loadTabData("User Access", true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to apply user access mapping.");
    }
  }

  async function rebuildSetupReadiness() {
    if (!token || !employee) return;
    setSetupRebuilding(true);
    setError(null);
    try {
      setSetupReadiness(await api.rebuildEmployeeSetupSections(token, employee.id));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to rebuild Employee 360 setup readiness.");
    } finally {
      setSetupRebuilding(false);
    }
  }

  if (!canView) {
    return <Panel><EmptyState title="Employee profile unavailable" description="Your account needs employees.view permission." /></Panel>;
  }
  if (!employee) {
    return <PageLoader title="Loading Employee 360" description={error ?? "Fetching employee profile."} />;
  }

  const activeOnboardingCase = lifecycle?.onboarding && lifecycle.onboarding.activation_status !== "ACTIVATED" && lifecycle.onboarding.onboarding_status !== "CANCELLED" ? lifecycle.onboarding : null;
  const preActivationStatus = ["DRAFT", "DRAFT_ONBOARDING", "ONBOARDING", "NOT_ACTIVE"].includes(employee.status_key ?? "");
  const employee360SetupStatus = ["PENDING_SETUP", "PENDING_FINAL_VERIFICATION", "PENDING_APPROVAL"].includes(employee.status_key ?? "");
  if ((activeOnboardingCase || preActivationStatus) && !employee360SetupStatus && !canViewDuringOnboarding) {
    return (
      <PageShell>
        <Panel className="p-6">
          <EmptyState
            title="Employee 360 is locked during onboarding"
            description="Complete employee setup from the onboarding case first. Employee 360 unlocks after onboarding is verified, approved, and the employee is activated."
          />
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {activeOnboardingCase ? (
              <Link to={`/onboarding/cases?case_id=${activeOnboardingCase.id}`}>
                <Button>Open Onboarding Case</Button>
              </Link>
            ) : (
              <Link to="/onboarding/cases">
                <Button>Open Onboarding Cases</Button>
              </Link>
            )}
            <Link to="/employees"><Button variant="outline">Back to Employees</Button></Link>
          </div>
        </Panel>
      </PageShell>
    );
  }

  const completed = onboarding.filter((task) => task.status === "COMPLETED").length;

  return (
    <PageShell constrained={false}>
      <EmployeeProfileCard
        employee={employee}
        token={token}
        actions={
          <>
            <EmployeeProfilePhotoControls employee={employee} token={token!} canUpload={canUploadPhoto} canClear={canClearPhoto} onChanged={load} />
            <Link to="/employees"><Button variant="outline" size="sm"><ArrowLeft className="h-4 w-4" /> Back</Button></Link>
            <Button variant="outline" size="sm" onClick={() => navigate("/employees")}><Pencil className="h-4 w-4" /> Edit</Button>
            {canStatus ? <Button variant="outline" size="sm" onClick={() => { setStatusModalError(null); setStatusModalOpen(true); }}>Change status</Button> : null}
            {canArchive ? <Button variant="danger" size="sm" onClick={() => setArchiveReason(" ")}><Archive className="h-4 w-4" /> Archive</Button> : null}
          </>
        }
      />
      <div className="hidden flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-3">
          <EmployeeAvatar employee={employee} token={token} size="lg" />
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-lg font-semibold">{employee.full_name}</h1>
              <Badge tone={tone(employee.status_key)}>{employee.status_name}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">{employee.employee_no} · {employee.department_name ?? "No department"} · {employee.position_title ?? "No position"}</p>
            <p className="text-xs text-muted-foreground">{employee.location_name ?? "No location"} · {employee.job_level_name ?? "No job level"} · Joined {employee.joining_date ?? "-"}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <EmployeeProfilePhotoControls employee={employee} token={token!} canUpload={canUploadPhoto} canClear={canClearPhoto} onChanged={load} />
          <Link to="/employees"><Button variant="outline" size="sm"><ArrowLeft className="h-4 w-4" /> Back</Button></Link>
          <Button variant="outline" size="sm" onClick={() => navigate("/employees")}><Pencil className="h-4 w-4" /> Edit</Button>
          {canStatus ? <Button variant="outline" size="sm" onClick={() => { setStatusModalError(null); setStatusModalOpen(true); }}>Change status</Button> : null}
          {canArchive ? <Button variant="danger" size="sm" onClick={() => setArchiveReason(" ")}><Archive className="h-4 w-4" /> Archive</Button> : null}
        </div>
      </div>

      {error ? <AlertBanner tone="danger">{error}</AlertBanner> : null}

      <Panel className="overflow-hidden">
        <div className="border-b p-2">
          <ResponsiveTabs
            items={visibleProfileTabs.map((tab) => ({ key: tab, label: tab }))}
            active={activeTab}
            onChange={(tab) => setActiveTab(tab as ProfileTab)}
          />
        </div>
        <div className="p-4">
          {activeTab === "Overview" ? (
            <Overview
              employee={employee}
              token={token!}
              contacts={contacts}
              onboarding={onboarding}
              completed={completed}
              audit={audit}
              setupReadiness={setupReadiness}
              canRebuildSetup={canRebuildSetup}
              setupRebuilding={setupRebuilding}
              photoControls={<EmployeeProfilePhotoControls employee={employee} token={token!} canUpload={canUploadPhoto} canClear={canClearPhoto} onChanged={load} compact />}
              onTask={canOnboarding ? updateTask : undefined}
              onRebuildSetup={() => void rebuildSetupReadiness()}
            />
          ) : null}
          {activeTab === "Personal Info" ? <div className="space-y-4"><DetailGrid rows={[
            ["Full name", employee.full_name], ["Display name", employee.display_name], ["Gender", employee.gender], ["Date of birth", employee.date_of_birth], ["Nationality", employee.nationality], ["Employee type", employee.employee_type], ["Employment type", employee.employment_type], ["Profile photo", employee.profile_photo_document_id ? "Uploaded" : "Not uploaded"]
          ]} />{tabLoading["Personal Info"] ? <TableSkeleton rows={3} columns={4} label="Loading profile update requests" /> : <ProfileUpdateRequests rows={profileRequests} />}</div> : null}
          {activeTab === "Job Info" ? tabLoading["Job Info"] ? <TableSkeleton rows={4} columns={5} label="Loading job history" /> : <JobInfo employee={employee} jobHistory={jobHistory} /> : null}
          {activeTab === "Contracts" ? canContracts ? <EmployeeContractsPanel employee={employee} token={token!} permissions={permissions} /> : <EmptyState title="Contracts unavailable" description="Your account needs employee contract access." /> : null}
          {activeTab === "Contacts" ? <Contacts contacts={contacts} canManage={canContacts} onAdd={() => setContactModal({ mode: "create" })} onEdit={(contact) => setContactModal({ mode: "edit", contact })} onArchive={(contact) => setContactArchiveTarget(contact)} /> : null}
          {activeTab === "User Access" ? canViewUserAccess ? (tabLoading["User Access"] ? <TableSkeleton rows={4} columns={4} label="Loading user access" /> :
            <UserAccessPanel
              employee={employee}
              token={token}
              account={userAccount}
              preview={userAccess}
              roles={roles}
              canManage={canManageUserAccess}
              canApply={canApplyUserAccess}
              onRefresh={() => void loadTabData("User Access", true)}
              onApply={(mappingId) => void applyUserAccessMapping(mappingId)}
            />
          ) : <EmptyState title="User access unavailable" description="Your account needs employee.user_account.view or users.view permission." /> : null}
          {activeTab === "Lifecycle" ? canViewLifecycle ? <LifecyclePanel summary={lifecycle} /> : <EmptyState title="Lifecycle unavailable" description="Your account needs employee lifecycle access." /> : null}
          {activeTab === "Payroll" ? (canPayroll ? <EmployeePayrollPanel employee={employee} /> : <Panel><EmptyState title="Payroll unavailable" description="Your account needs employee payroll access." /></Panel>) : null}
          {activeTab === "Final Settlement" ? (canFinalSettlement ? <EmployeeFinalSettlementPanel employee={employee} /> : <Panel><EmptyState title="Final settlement unavailable" description="Your account needs employee final settlement access." /></Panel>) : null}
          {activeTab === "Attendance" ? canAttendance ? <EmployeeAttendancePanel employee={employee} token={token!} permissions={permissions} /> : <EmptyState title="Attendance unavailable" description="Your account needs employees.attendance.view permission." /> : null}
          {activeTab === "Roster" ? canRoster ? <EmployeeRosterPanel employee={employee} token={token!} permissions={permissions} /> : <EmptyState title="Roster unavailable" description="Your account needs employees.roster.view permission." /> : null}
          {activeTab === "Leave" ? canLeave ? <EmployeeLeavePanel employee={employee} token={token!} permissions={permissions} /> : <EmptyState title="Leave unavailable" description="Your account needs employees.leave.view permission." /> : null}
          {activeTab === "Documents" ? <EmployeeDocumentsPanel employee={employee} token={token!} permissions={permissions} onChanged={load} /> : null}
          {activeTab === "Assets & Uniforms" ? canAssets ? <EmployeeAssetsPanel employee={employee} /> : <EmptyState title="Assets unavailable" description="Your account needs employee asset access." /> : null}
          {activeTab === "Notes" ? canNotes ? <EmployeeNotesPanel employee={employee} /> : <EmptyState title="Notes unavailable" description="Your account needs employee_notes.view permission." /> : null}
          {activeTab === "Audit Log" ? canAudit ? <EmployeeAuditPanel employee={employee} initialAudit={audit} /> : <EmptyState title="Audit unavailable" description="Your account needs employee audit access." /> : null}
        </div>
      </Panel>

      {contactModal ? <ContactModal contact={contactModal.contact} onClose={() => setContactModal(null)} onSave={(input) => void saveContact(input)} /> : null}
      {archiveReason ? (
        <ReasonModal
          title="Archive employee"
          description={`Archive ${employee.full_name}. Existing history is retained.`}
          value={archiveReason.trim() === "" ? "" : archiveReason}
          onChange={setArchiveReason}
          onClose={() => setArchiveReason("")}
          onConfirm={() => void archive()}
        />
      ) : null}
      {contactArchiveTarget ? (
        <ReasonModal
          title="Archive contact"
          description={`Archive ${contactArchiveTarget.contact_type} contact ${contactArchiveTarget.value}.`}
          value={contactArchiveReason}
          onChange={setContactArchiveReason}
          onClose={() => { setContactArchiveTarget(null); setContactArchiveReason(""); }}
          onConfirm={() => void archiveContact(contactArchiveTarget)}
        />
      ) : null}
      {statusModalOpen ? (
        <ChangeEmployeeStatusModal
          employee={employee}
          statuses={statuses}
          error={statusModalError}
          saving={statusSaving}
          onClose={() => setStatusModalOpen(false)}
          onSubmit={(input) => void changeStatus(input)}
        />
      ) : null}
    </PageShell>
  );
}

function Overview({
  employee,
  token,
  contacts,
  onboarding,
  completed,
  audit,
  setupReadiness,
  canRebuildSetup,
  setupRebuilding,
  photoControls,
  onTask,
  onRebuildSetup
}: {
  employee: Employee;
  token: string;
  contacts: EmployeeContact[];
  onboarding: OnboardingTask[];
  completed: number;
  audit: Record<string, unknown>[];
  setupReadiness: EmployeeSetupReadinessResponse | null;
  canRebuildSetup: boolean;
  setupRebuilding: boolean;
  photoControls: ReactNode;
  onTask?: (task: OnboardingTask, status: OnboardingStatus) => Promise<void>;
  onRebuildSetup: () => void;
}) {
  return (
    <div className="grid gap-4 xl:grid-cols-3">
      <div className="xl:col-span-3">
        <EmployeeSetupReadinessPanel
          setup={setupReadiness}
          canRebuild={canRebuildSetup}
          rebuilding={setupRebuilding}
          onRebuild={onRebuildSetup}
        />
      </div>
      <div className="rounded-md border">
        <div className="border-b px-3 py-2 text-sm font-semibold">Profile photo</div>
        <div className="flex items-center gap-3 p-3">
          <EmployeeAvatar employee={employee} token={token} size="lg" />
          <div className="min-w-0 space-y-2">
            <div>
              <p className="truncate text-sm font-medium">{employee.full_name}</p>
              <p className="text-xs text-muted-foreground">{employee.profile_photo_document_id ? "Photo uploaded" : "Initials placeholder"}</p>
            </div>
            {photoControls}
          </div>
        </div>
      </div>
      <Summary title="Personal summary" rows={[["Display name", employee.display_name ?? "-"], ["Employee type", employee.employee_type], ["Employment type", employee.employment_type]]} />
      <Summary title="Job summary" rows={[["Department", employee.department_name ?? "-"], ["Position", employee.position_title ?? "-"], ["Location", employee.location_name ?? "-"], ["Manager", employee.reporting_manager_name ?? "-"]]} />
      <Summary title="Contact summary" rows={[["Contacts", String(contacts.length)], ["Primary", contacts.find((c) => c.is_primary)?.value ?? "-"], ["Emergency", contacts.find((c) => c.contact_type === "EMERGENCY")?.value ?? "-"]]} />
      <div className="xl:col-span-2"><OnboardingTable tasks={onboarding} completed={completed} onTask={onTask} /></div>
      <Placeholder title="Alerts" items={["Missing documents", "Expiring documents", "Attendance issues", "Pending leave", "Asset clearance"]} />
      <div className="xl:col-span-3"><AuditTable audit={audit.slice(0, 6)} /></div>
    </div>
  );
}

function readableStatus(value?: string | null) {
  if (!value) return "Not checked";
  return value
    .split("_")
    .join(" ")
    .split("-")
    .join(" ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function blockingSummary(section: EmployeeSetupSectionStatusRow) {
  if (section.status_message) return section.status_message;
  if (section.missing_fields.length) return `Missing: ${section.missing_fields.map(String).join(", ")}`;
  return section.is_required ? "Required setup has not been completed." : "No blocker.";
}

function EmployeeSetupReadinessPanel({
  setup,
  canRebuild,
  rebuilding,
  onRebuild
}: {
  setup: EmployeeSetupReadinessResponse | null;
  canRebuild: boolean;
  rebuilding: boolean;
  onRebuild: () => void;
}) {
  const sections = setup?.sections ?? [];
  const readiness = setup?.readiness;
  const completion = readiness?.completion;
  const complete = completion?.complete ?? sections.filter((section) => section.is_complete).length;
  const total = completion?.total ?? sections.length;
  const blockers = readiness?.blockers ?? [];
  return (
    <div className="rounded-md border border-slate-200 bg-white">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b px-4 py-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-sm font-semibold">Employee 360 setup readiness</h3>
            <Badge tone={setupTone(readiness?.status)}>{readableStatus(readiness?.status)}</Badge>
            <Badge tone="neutral">Preview only</Badge>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            {total ? `${complete}/${total} sections complete or not required.` : "No section status has been rebuilt yet."} Final activation still requires server verification.
          </p>
        </div>
        <div className="flex flex-wrap justify-end gap-2">
          <Button type="button" variant="outline" size="sm" disabled={!canRebuild} loading={rebuilding} loadingLabel="Rebuilding readiness" onClick={onRebuild}>
            Rebuild readiness
          </Button>
          <Button type="button" variant="outline" size="sm" disabled>
            Activation locked
          </Button>
        </div>
      </div>
      {blockers.length ? (
        <div className="border-b bg-amber-50 px-4 py-2 text-xs text-amber-900">
          {String((blockers[0] as Record<string, unknown>).message ?? "Required setup is still blocking activation.")}
        </div>
      ) : null}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Section</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Required</TableHead>
              <TableHead>Message</TableHead>
              <TableHead>Next action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sections.length ? sections.map((section) => (
              <TableRow key={section.section_key}>
                <TableCell className="font-medium">{section.section_label}</TableCell>
                <TableCell><Badge tone={setupTone(section.status)}>{readableStatus(section.status)}</Badge></TableCell>
                <TableCell>{section.is_required ? "Yes" : "No"}</TableCell>
                <TableCell className="max-w-[360px] whitespace-normal text-muted-foreground">{blockingSummary(section)}</TableCell>
                <TableCell className="max-w-[280px] whitespace-normal">{section.next_action ?? "-"}</TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan={5}>
                  <EmptyState title="Setup readiness not built" description="Rebuild readiness to generate Employee 360 section statuses for this employee." />
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function UserAccessPanel({
  employee,
  token,
  account,
  preview,
  roles,
  canManage,
  canApply,
  onRefresh,
  onApply
}: {
  employee: Employee;
  token: string | null;
  account: EmployeeUserAccount | null;
  preview: EmployeeUserAccessPreview | null;
  roles: Role[];
  canManage: boolean;
  canApply: boolean;
  onRefresh: () => void;
  onApply: (mappingId?: string | null) => void;
}) {
  const linked = account?.linked_user ?? null;
  const suggested = account?.suggested ?? (preview ? { suggested_role_mapping: preview.suggested_role_mapping, suggested_role: preview.suggested_role, suggested_scope: preview.suggested_scope } : null);
  const mapping = suggested?.suggested_role_mapping ?? null;
  const employeeEmail = account?.employee_email;
  const availableScopes = account?.available_access_scopes ?? [];
  const [linkUserId, setLinkUserId] = useState("");
  const [provision, setProvision] = useState({
    name: employee.display_name || employee.full_name,
    email: employeeEmail?.email || employee.linked_user_email || "",
    username: account?.suggested_username ?? "",
    password: "",
    self_service_enabled: true
  });
  const [update, setUpdate] = useState({
    name: linked?.name ?? "",
    email: linked?.email ?? "",
    username: linked?.username ?? "",
    status: (linked?.status ?? "ACTIVE") as UserStatus,
    self_service_enabled: account?.self_service_enabled ?? false,
    role_ids: account?.role_ids ?? [],
    access_scope_ids: account?.access_scope_ids ?? []
  });
  const [reason, setReason] = useState("");
  const [disableOnUnlink, setDisableOnUnlink] = useState(false);
  const [busy, setBusy] = useState("");
  const [localError, setLocalError] = useState<string | null>(null);

  useEffect(() => {
    setUpdate({
      name: linked?.name ?? "",
      email: linked?.email ?? "",
      username: linked?.username ?? "",
      status: (linked?.status ?? "ACTIVE") as UserStatus,
      self_service_enabled: account?.self_service_enabled ?? false,
      role_ids: account?.role_ids ?? [],
      access_scope_ids: account?.access_scope_ids ?? []
    });
  }, [account?.linked_user?.id, account?.linked_user?.updated_at, account?.self_service_enabled, account?.role_ids.join(","), account?.access_scope_ids.join(",")]);

  useEffect(() => {
    if (linked) return;
    setProvision((current) => ({
      ...current,
      name: current.name || employee.display_name || employee.full_name,
      email: current.email || employeeEmail?.email || employee.linked_user_email || "",
      username: current.username || account?.suggested_username || ""
    }));
  }, [linked?.id, employeeEmail?.email, account?.suggested_username, employee.id]);

  if (!account && !preview) return <EmptyState title="User access loading" description="Fetching linked user roles and access scopes." />;
  const listIds = (value?: string[]) => value?.length ? value.join(", ") : "-";
  const scopeSource = (scope: EmployeeUserAccessPreview["assigned_scopes"][number]) => {
    if (scope.scope_owner_type === "ROLE") return "Role";
    if (scope.scope_owner_type === "ROLE_MAPPING_RULE") return "Mapping template";
    return scope.role_mapping_rule_id ? "Applied mapping" : "Manual user scope";
  };
  async function run(label: string, action: () => Promise<unknown>) {
    if (!token) return;
    setBusy(label);
    setLocalError(null);
    try {
      await action();
      setReason("");
      onRefresh();
    } catch (err) {
      setLocalError(err instanceof ApiError ? err.message : "User account action could not be completed.");
    } finally {
      setBusy("");
    }
  }

  function toggleRole(roleId: string, checked: boolean) {
    setUpdate((current) => ({
      ...current,
      role_ids: checked ? Array.from(new Set([...current.role_ids, roleId])) : current.role_ids.filter((id) => id !== roleId)
    }));
  }

  function toggleScope(scopeId: string, checked: boolean) {
    setUpdate((current) => ({
      ...current,
      access_scope_ids: checked ? Array.from(new Set([...current.access_scope_ids, scopeId])) : current.access_scope_ids.filter((id) => id !== scopeId)
    }));
  }

  async function submitProvision(event: FormEvent) {
    event.preventDefault();
    await run("provision", () => api.provisionEmployeeUserAccount(token!, employee.id, {
      ...provision,
      password: provision.password || undefined,
      status: "ACTIVE",
      role_ids: update.role_ids,
      access_scope_ids: update.access_scope_ids,
      reset_required: !provision.password,
      email_override_reason: employeeEmail?.email && provision.email && provision.email.toLowerCase() !== employeeEmail.email.toLowerCase() ? "Provision email manually overridden from Employee 360 User Access." : null,
      reason: "Provisioned from Employee 360 User Access"
    }));
  }

  async function submitLink(event: FormEvent) {
    event.preventDefault();
    if (!linkUserId) {
      setLocalError("Select an existing user to link.");
      return;
    }
    await run("link", () => api.linkEmployeeExistingUser(token!, employee.id, { user_id: linkUserId, role_ids: update.role_ids, access_scope_ids: update.access_scope_ids, self_service_enabled: provision.self_service_enabled, reason: "Linked from Employee 360 User Access" }));
  }

  async function submitUpdate(event: FormEvent) {
    event.preventDefault();
    await run("update", () => api.updateEmployeeUserAccount(token!, employee.id, update));
  }

  const assignedScopes = account?.scopes ?? preview?.assigned_scopes ?? [];
  const assignedRoles = account?.roles ?? preview?.assigned_roles ?? [];
  const availableUsers = account?.available_users ?? [];
  return (
    <div className="space-y-4">
      {localError ? <AlertBanner tone="danger">{localError}</AlertBanner> : null}
      <div className="grid gap-3 lg:grid-cols-3">
        <Summary title="Linked user" rows={[["Status", account?.account_status ?? (linked ? linked.status : "No linked user")], ["Email", linked?.email ?? "-"], ["Invite/reset", account?.invite_status ? `${account.invite_status}${account.reset_required ? " / reset required" : ""}` : "-"], ["Last login", linked?.last_login_at ?? "Never"]]} />
        <Summary title="Suggested role" rows={[["Role", suggested?.suggested_role?.name ?? "-"], ["Mapping", mapping?.name ?? "-"], ["Priority", mapping ? String(mapping.priority) : "-"]]} />
        <Summary title="Suggested scope" rows={[["Scope", suggested?.suggested_scope?.scope_type ?? "-"], ["Departments", listIds(suggested?.suggested_scope?.allowed_department_ids)], ["Locations", listIds(suggested?.suggested_scope?.allowed_location_ids)], ["Manage", suggested?.suggested_scope?.can_manage ? "Yes" : "No"]]} />
      </div>
      <div className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm">
        <span className="font-medium">Employee email: </span>
        <span>{employeeEmail?.email ?? employeeEmail?.raw_email ?? "No email on file"}</span>
        {employeeEmail?.email ? <Badge tone="success" className="ml-2">Using employee email from profile</Badge> : null}
        <span className="ml-2 text-muted-foreground">{employeeEmail?.message ?? "Provisioning will require an account email."}</span>
        {employeeEmail?.recommendation === "LINK_EXISTING_USER" && employeeEmail.matching_user ? (
          <Badge tone="info" className="ml-2">Existing user found: {employeeEmail.matching_user.email}</Badge>
        ) : null}
      </div>
      <div className="rounded-md border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-950">
        Roles define permissions. Access scopes define which employee, department, and location records those permissions can reach. This section links a real login account to the selected employee profile.
      </div>
      <div className="flex flex-wrap justify-end gap-2">
        {canApply && linked && mapping ? <Button size="sm" onClick={() => onApply(mapping.id)}>Apply suggested role + scope</Button> : null}
      </div>
      {canManage && !linked ? (
        <div className="grid gap-4 xl:grid-cols-2">
          <Panel className="p-4">
            <form className="space-y-3" onSubmit={(event) => void submitProvision(event)}>
              <div>
                <h3 className="text-sm font-semibold">Provision login account</h3>
                <p className="mt-1 text-xs text-muted-foreground">Creates a real user record and links it to this employee.</p>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <div><Label>Name</Label><Input value={provision.name} onChange={(event) => setProvision({ ...provision, name: event.target.value })} /></div>
                <div><Label>Email</Label><Input type="email" value={provision.email} onChange={(event) => setProvision({ ...provision, email: event.target.value })} /></div>
                <div><Label>Username</Label><Input value={provision.username} onChange={(event) => setProvision({ ...provision, username: event.target.value })} /></div>
                <div><Label>Temporary password</Label><Input type="password" value={provision.password} placeholder="Leave blank for invite/reset pending" onChange={(event) => setProvision({ ...provision, password: event.target.value })} /></div>
              </div>
              <CheckboxField label="Enable self-service scope" checked={provision.self_service_enabled} onChange={(checked) => setProvision({ ...provision, self_service_enabled: checked })} />
              <RoleChecklist roles={roles} selected={update.role_ids} onToggle={toggleRole} />
              <ScopeChecklist scopes={availableScopes} selected={update.access_scope_ids} onToggle={toggleScope} />
              <div className="flex justify-end"><Button type="submit" size="sm" disabled={busy === "provision"}>Provision account</Button></div>
            </form>
          </Panel>
          <Panel className="p-4">
            <form className="space-y-3" onSubmit={(event) => void submitLink(event)}>
              <div>
                <h3 className="text-sm font-semibold">Link existing user</h3>
                <p className="mt-1 text-xs text-muted-foreground">Only standalone or already-linked-to-this-employee users are available.</p>
              </div>
              <SelectField label="Existing user" value={linkUserId} onValueChange={setLinkUserId}>
                <option value="">Select user</option>
                {availableUsers.map((user) => <option key={user.id} value={user.id}>{user.name} - {user.email}</option>)}
              </SelectField>
              <RoleChecklist roles={roles} selected={update.role_ids} onToggle={toggleRole} />
              <ScopeChecklist scopes={availableScopes} selected={update.access_scope_ids} onToggle={toggleScope} />
              <div className="flex justify-end"><Button type="submit" size="sm" disabled={busy === "link" || !linkUserId}>Link user</Button></div>
            </form>
          </Panel>
        </div>
      ) : null}
      {canManage && linked ? (
        <Panel className="p-4">
          <form className="space-y-4" onSubmit={(event) => void submitUpdate(event)}>
            <div>
              <h3 className="text-sm font-semibold">Linked account settings</h3>
              <p className="mt-1 text-xs text-muted-foreground">Update identity, login status, assigned roles, and self-only scope setup.</p>
            </div>
            <div className="grid gap-3 md:grid-cols-4">
              <div><Label>Name</Label><Input value={update.name} onChange={(event) => setUpdate({ ...update, name: event.target.value })} /></div>
              <div><Label>Email</Label><Input type="email" value={update.email} onChange={(event) => setUpdate({ ...update, email: event.target.value })} /></div>
              <div><Label>Username</Label><Input value={update.username} onChange={(event) => setUpdate({ ...update, username: event.target.value })} /></div>
              <SelectField label="Status" value={update.status} onValueChange={(status) => setUpdate({ ...update, status: status as UserStatus })}>
                <option value="ACTIVE">Active</option>
                <option value="LOCKED">Locked</option>
                <option value="DISABLED">Disabled</option>
              </SelectField>
            </div>
            <CheckboxField label="Ensure self-service SELF_ONLY scope" checked={update.self_service_enabled} onChange={(checked) => setUpdate({ ...update, self_service_enabled: checked })} />
            <RoleChecklist roles={roles} selected={update.role_ids} onToggle={toggleRole} />
            <ScopeChecklist scopes={availableScopes} selected={update.access_scope_ids} onToggle={toggleScope} />
            <div className="flex flex-wrap justify-end gap-2">
              <Button type="button" variant="outline" size="sm" disabled={busy === "reset"} onClick={() => void run("reset", () => api.updateEmployeeUserAccount(token!, employee.id, { reset_required: true, invite_status: "RESET_REQUIRED", reason: "Reset required from Employee 360 User Access" }))}>Require reset / invite placeholder</Button>
              <Button type="submit" size="sm" disabled={busy === "update"}>Save account access</Button>
            </div>
          </form>
          <div className="mt-4 grid gap-3 border-t pt-4 md:grid-cols-[1fr_auto_auto]">
            <div><Label>Reason for unlink/deactivation</Label><Input value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Required for unlink or exit deactivation" /></div>
            <CheckboxField label="Disable on unlink" checked={disableOnUnlink} onChange={setDisableOnUnlink} />
            <div className="flex items-end gap-2">
              <Button variant="outline" size="sm" disabled={!reason.trim() || busy === "unlink"} onClick={() => void run("unlink", () => api.unlinkEmployeeUserAccount(token!, employee.id, { reason, disable_user: disableOnUnlink }))}>Unlink</Button>
              <Button variant="danger" size="sm" disabled={!reason.trim() || busy === "deactivate"} onClick={() => void run("deactivate", () => api.deactivateEmployeeUserForExit(token!, employee.id, { reason }))}>Deactivate for exit</Button>
            </div>
          </div>
        </Panel>
      ) : null}
      <div className="grid gap-4 xl:grid-cols-2">
        <div className="rounded-md border">
          <div className="border-b px-3 py-2 text-sm font-semibold">Assigned roles</div>
          <div className="divide-y">{assignedRoles.length ? assignedRoles.map((role) => <div key={role.id} className="px-3 py-2 text-sm">{role.name}</div>) : <div className="px-3 py-4 text-sm text-muted-foreground">No roles assigned.</div>}</div>
        </div>
        <div className="rounded-md border">
          <div className="border-b px-3 py-2 text-sm font-semibold">Assigned scopes</div>
          <div className="overflow-x-auto">
            <Table className="min-w-[760px]">
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Source</TableHead><TableHead>Scope</TableHead><TableHead>Module</TableHead><TableHead>Departments</TableHead><TableHead>Locations</TableHead><TableHead>Rights</TableHead></TableRow></TableHeader>
              <TableBody>{assignedScopes.map((scope) => <TableRow key={scope.id}><TableCell>{scope.name}</TableCell><TableCell>{scopeSource(scope)}</TableCell><TableCell>{scope.scope_type}</TableCell><TableCell>{scope.module_key ?? "All"}</TableCell><TableCell>{listIds(scope.allowed_department_ids)}</TableCell><TableCell>{listIds(scope.allowed_location_ids)}</TableCell><TableCell>{scope.can_manage ? "Manage" : scope.can_view ? "View" : "-"}</TableCell></TableRow>)}</TableBody>
            </Table>
            {!assignedScopes.length ? <div className="px-3 py-4 text-sm text-muted-foreground">No user-specific scopes assigned.</div> : null}
          </div>
        </div>
      </div>
      {account?.link_history?.length ? (
        <div className="rounded-md border">
          <div className="border-b px-3 py-2 text-sm font-semibold">Link history</div>
          <div className="overflow-x-auto">
            <Table className="min-w-[760px]">
              <TableHeader><TableRow><TableHead>Status</TableHead><TableHead>User</TableHead><TableHead>Linked</TableHead><TableHead>Unlinked/deactivated</TableHead><TableHead>Reason</TableHead><TableHead>Invite</TableHead></TableRow></TableHeader>
              <TableBody>{account.link_history.map((link) => <TableRow key={link.id}><TableCell><StatusBadge value={link.status} /></TableCell><TableCell>{link.account_email_created ?? link.user_id}</TableCell><TableCell>{link.linked_at}{link.linked_by_name ? ` by ${link.linked_by_name}` : ""}</TableCell><TableCell>{link.deactivated_at ?? link.unlinked_at ?? "-"}</TableCell><TableCell>{link.deactivation_reason ?? link.unlink_reason ?? "-"}</TableCell><TableCell>{link.invite_status ?? "-"}</TableCell></TableRow>)}</TableBody>
            </Table>
          </div>
        </div>
      ) : null}
      {!linked ? <EmptyState title="No linked system user" description="Provision a login account or link an existing user before applying suggested role mapping." /> : null}
    </div>
  );
}

function RoleChecklist({ roles, selected, onToggle }: { roles: Role[]; selected: string[]; onToggle: (roleId: string, checked: boolean) => void }) {
  if (!roles.length) return <p className="text-xs text-muted-foreground">Role options are unavailable or require roles.view permission.</p>;
  return (
    <div className="rounded-md border">
      <div className="border-b px-3 py-2 text-sm font-semibold">Assigned roles</div>
      <div className="grid max-h-56 gap-2 overflow-y-auto p-3 md:grid-cols-2">
        {roles.filter((role) => role.is_active).map((role) => (
          <CheckboxField
            key={role.id}
            label={<span className="flex items-center gap-2">{role.name}{role.is_protected ? <Badge tone="warning">Protected</Badge> : null}</span>}
            checked={selected.includes(role.id)}
            onChange={(checked) => onToggle(role.id, checked)}
          />
        ))}
      </div>
    </div>
  );
}

function ScopeChecklist({ scopes, selected, onToggle }: { scopes: AccessScopeRule[]; selected: string[]; onToggle: (scopeId: string, checked: boolean) => void }) {
  if (!scopes.length) return <p className="text-xs text-muted-foreground">Reusable access scope options are unavailable or require access scope permissions.</p>;
  return (
    <div className="rounded-md border">
      <div className="border-b px-3 py-2 text-sm font-semibold">Apply reusable access scopes</div>
      <div className="grid max-h-56 gap-2 overflow-y-auto p-3 md:grid-cols-2">
        {scopes.map((scope) => (
          <CheckboxField
            key={scope.id}
            label={<span className="flex min-w-0 flex-col"><span className="truncate">{scope.name}</span><span className="text-xs text-muted-foreground">{scope.scope_type} / {scope.module_key ?? "All modules"}</span></span>}
            checked={selected.includes(scope.id)}
            onChange={(checked) => onToggle(scope.id, checked)}
          />
        ))}
      </div>
    </div>
  );
}

function LifecyclePanel({ summary }: { summary: LifecycleSummary | null }) {
  if (!summary) return <EmptyState title="Lifecycle summary unavailable" description="Onboarding and offboarding details will appear here after a case is created." />;
  const lifecycleRows = [
    ["Onboarding case", summary.onboarding?.case_number ?? "-"],
    ["Onboarding status", summary.onboarding?.onboarding_status ?? "-"],
    ["Activation status", summary.onboarding?.activation_status ?? "-"],
    ["Offboarding case", summary.offboarding?.case_number ?? "-"],
    ["Offboarding status", summary.offboarding?.offboarding_status ?? "-"],
    ["Finalization status", summary.offboarding?.finalization_status ?? "-"]
  ] as Array<[string, string]>;
  return (
    <div className="space-y-4">
      <div className="grid gap-3 lg:grid-cols-3">
        <Summary title="Lifecycle status" rows={lifecycleRows} />
        <Summary title="Onboarding tasks" rows={[["Total", String(summary.onboarding_tasks.length)], ["Completed", String(summary.onboarding_tasks.filter((task) => task.task_status === "COMPLETED").length)], ["Blocked", String(summary.onboarding_tasks.filter((task) => task.task_status === "BLOCKED").length)]]} />
        <Summary title="Offboarding tasks" rows={[["Total", String(summary.offboarding_tasks.length)], ["Completed", String(summary.offboarding_tasks.filter((task) => task.task_status === "COMPLETED").length)], ["Blocked", String(summary.offboarding_tasks.filter((task) => task.task_status === "BLOCKED").length)]]} />
      </div>
      <LifecycleTaskTable title="Onboarding checklist" rows={summary.onboarding_tasks} />
      <LifecycleTaskTable title="Offboarding checklist" rows={summary.offboarding_tasks} />
      <SimpleRows title="Lifecycle events" rows={summary.events.map((event) => ({ ...event }))} columns={["action", "case_type", "previous_status", "new_status", "reason", "created_at"]} />
    </div>
  );
}

function LifecycleTaskTable({ title, rows }: { title: string; rows: LifecycleTask[] }) {
  return (
    <div className="rounded-md border">
      <div className="border-b px-3 py-2 text-sm font-semibold">{title}</div>
      {rows.length === 0 ? <EmptyState title="No checklist rows" description="Tasks will be generated after the related lifecycle case is created." /> : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Task</TableHead><TableHead>Group</TableHead><TableHead>Status</TableHead><TableHead>Required</TableHead><TableHead>Due</TableHead><TableHead>Reason</TableHead></TableRow></TableHeader>
            <TableBody>{rows.map((task) => <TableRow key={String(task.id)}><TableCell>{String(task.task_name ?? task.title ?? task.task_key ?? "-")}</TableCell><TableCell>{String(task.task_group ?? "-")}</TableCell><TableCell><Badge tone={task.task_status === "COMPLETED" ? "success" : task.task_status === "BLOCKED" ? "danger" : task.task_status === "WAIVED" ? "warning" : "neutral"}>{String(task.task_status ?? task.status ?? "-")}</Badge></TableCell><TableCell>{task.is_required || task.required ? "Yes" : "No"}</TableCell><TableCell>{String(task.due_date ?? "-")}</TableCell><TableCell>{String(task.waiver_reason ?? task.blocked_reason ?? "-")}</TableCell></TableRow>)}</TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}

function Summary({ title, rows }: { title: string; rows: Array<[string, string]> }) {
  return <div className="rounded-md border"><div className="border-b px-3 py-2 text-sm font-semibold">{title}</div><div className="divide-y">{rows.map(([k, v]) => <div key={k} className="flex justify-between gap-3 px-3 py-2 text-sm"><span className="text-muted-foreground">{k}</span><span className="font-medium">{v}</span></div>)}</div></div>;
}

function DetailGrid({ rows }: { rows: Array<[string, string | null | undefined]> }) {
  return <div className="grid gap-3 md:grid-cols-3">{rows.map(([k, v]) => <div key={k} className="rounded-md border px-3 py-2"><p className="text-xs text-muted-foreground">{k}</p><p className="text-sm font-medium">{v || "-"}</p></div>)}</div>;
}

function parseFieldValue(json?: unknown) {
  if (!json) return "-";
  try {
    const parsed = typeof json === "string" ? JSON.parse(json) : json;
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return Object.entries(parsed as Record<string, unknown>).map(([key, value]) => `${key}: ${String(value ?? "-")}`).join(", ");
    }
    return String(parsed ?? "-");
  } catch {
    return String(json);
  }
}

function ProfileUpdateRequests({ rows }: { rows: Record<string, unknown>[] }) {
  return (
    <div className="rounded-md border">
      <div className="border-b px-3 py-2 text-sm font-semibold">Profile update requests</div>
      {rows.length === 0 ? <EmptyState title="No profile update requests" description="Pending and recent self-service profile requests for this employee will appear here." /> : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Field</TableHead><TableHead>Old/current value</TableHead><TableHead>Requested value</TableHead><TableHead>Reason</TableHead><TableHead>Status</TableHead><TableHead>Reviewer note</TableHead><TableHead>Created</TableHead></TableRow></TableHeader>
            <TableBody>{rows.map((row) => <TableRow key={String(row.id)}><TableCell>{String(row.field_key ?? row.section ?? "-")}</TableCell><TableCell>{parseFieldValue(row.old_value_json)}</TableCell><TableCell>{parseFieldValue(row.requested_value_json)}</TableCell><TableCell>{String(row.reason ?? "-")}</TableCell><TableCell><Badge tone={row.status === "APPROVED" ? "success" : row.status === "REJECTED" ? "danger" : "warning"}>{String(row.status ?? "-")}</Badge></TableCell><TableCell>{String(row.review_note ?? "-")}</TableCell><TableCell>{String(row.created_at ?? "-")}</TableCell></TableRow>)}</TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}

function ReasonModal({ title, description, value, onChange, onClose, onConfirm }: { title: string; description: string; value: string; onChange: (value: string) => void; onClose: () => void; onConfirm: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/25 p-4">
      <div className="w-full max-w-md rounded-lg border bg-white p-4 shadow-xl">
        <h2 className="text-sm font-semibold">{title}</h2>
        <p className="mt-1 text-xs text-muted-foreground">{description}</p>
        <Input className="mt-3" placeholder="Reason" value={value === " " ? "" : value} onChange={(event) => onChange(event.target.value || " ")} />
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" disabled={!value.trim()} onClick={onConfirm}>Confirm</Button>
        </div>
      </div>
    </div>
  );
}

function JobInfo({ employee, jobHistory }: { employee: Employee; jobHistory: Record<string, unknown>[] }) {
  return <div className="space-y-4"><DetailGrid rows={[["Department", employee.department_name], ["Position", employee.position_title], ["Outlet/location", employee.location_name], ["Job level", employee.job_level_name], ["Reporting manager", employee.reporting_manager_name], ["Joining date", employee.joining_date], ["Confirmation date", employee.confirmation_date], ["Contract dates", `${employee.contract_start_date ?? "-"} to ${employee.contract_end_date ?? "-"}`], ["Probation end", employee.probation_end_date], ["Payroll included", employee.payroll_included ? "Yes" : "No"], ["Roster eligible", employee.roster_eligible ? "Yes" : "No"]]} /><SimpleRows title="Job history" rows={jobHistory} columns={["effective_date", "previous_department_name", "new_department_name", "previous_position_title", "new_position_title", "reason", "created_by_name", "created_at"]} /></div>;
}

function Contacts({
  contacts,
  canManage,
  onAdd,
  onEdit,
  onArchive
}: {
  contacts: EmployeeContact[];
  canManage: boolean;
  onAdd: () => void;
  onEdit: (contact: EmployeeContact) => void;
  onArchive: (contact: EmployeeContact) => void;
}) {
  return (
    <div className="space-y-3">
      <div className="flex justify-end">{canManage ? <Button size="sm" onClick={onAdd}>Add contact</Button> : null}</div>
      <div className="overflow-x-auto rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type</TableHead>
              <TableHead>Value</TableHead>
              <TableHead>Country</TableHead>
              <TableHead>Relationship</TableHead>
              <TableHead>Primary</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Sensitive</TableHead>
              <TableHead>Notes</TableHead>
              {canManage ? <TableHead className="text-right">Actions</TableHead> : null}
            </TableRow>
          </TableHeader>
          <TableBody>
            {contacts.map((contact) => (
              <TableRow key={contact.id}>
                <TableCell>{contact.contact_type}</TableCell>
                <TableCell>{contact.value}</TableCell>
                <TableCell>{contact.country_code ?? "-"}</TableCell>
                <TableCell>{contact.relationship ?? "-"}</TableCell>
                <TableCell>{contact.is_primary ? "Yes" : "No"}</TableCell>
                <TableCell>{contact.emergency_priority ?? "-"}</TableCell>
                <TableCell>{contact.is_sensitive ? <Badge tone="warning">Sensitive</Badge> : "-"}</TableCell>
                <TableCell>{contact.notes ?? "-"}</TableCell>
                {canManage ? (
                  <TableCell>
                    <div className="flex justify-end gap-1">
                      <RowActionButton intent="edit" size="sm" title="Edit" onClick={() => onEdit(contact)}>Edit</RowActionButton>
                      <RowActionButton intent="archive" size="sm" title="Archive" onClick={() => onArchive(contact)}>Archive</RowActionButton>
                    </div>
                  </TableCell>
                ) : null}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function OnboardingTable({ tasks, completed, onTask }: { tasks: OnboardingTask[]; completed: number; onTask?: (task: OnboardingTask, status: OnboardingStatus) => Promise<void> }) {
  return <div className="rounded-md border"><div className="flex items-center justify-between border-b px-3 py-2"><div><h3 className="text-sm font-semibold">Onboarding checklist</h3><p className="text-xs text-muted-foreground">{completed}/{tasks.length} completed</p></div><CheckCircle2 className="h-4 w-4 text-muted-foreground" /></div><div className="overflow-x-auto"><Table><TableHeader><TableRow><TableHead>Task</TableHead><TableHead>Module</TableHead><TableHead>Required</TableHead><TableHead>Status</TableHead><TableHead>Completed at</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader><TableBody>{tasks.map((task) => <TableRow key={task.id}><TableCell>{task.title}</TableCell><TableCell>{task.module}</TableCell><TableCell>{task.required ? "Yes" : "No"}</TableCell><TableCell><Badge tone={task.status === "COMPLETED" ? "success" : task.status === "BLOCKED" ? "danger" : "neutral"}>{task.status}</Badge></TableCell><TableCell>{task.completed_at ?? "-"}</TableCell><TableCell>{onTask ? <div className="flex gap-1"><RowActionButton intent="complete" size="sm" title="Mark task done" onClick={() => void onTask(task, "COMPLETED")}>Done</RowActionButton><RowActionButton intent="neutral" size="sm" title="Skip task" onClick={() => void onTask(task, "SKIPPED")}>Skip</RowActionButton><RowActionButton intent="warning" size="sm" title="Block task" onClick={() => void onTask(task, "BLOCKED")}>Block</RowActionButton>{task.status !== "PENDING" ? <RowActionButton intent="restore" size="sm" title="Reopen task" onClick={() => void onTask(task, "PENDING")}>Reopen</RowActionButton> : null}</div> : "-"}</TableCell></TableRow>)}</TableBody></Table></div></div>;
}

function Placeholder({ title, items }: { title: string; items: string[] }) {
  return <div className="rounded-md border"><div className="border-b px-3 py-2"><h3 className="text-sm font-semibold">{title} not implemented yet</h3><p className="text-xs text-muted-foreground">Foundation sections prepared for a later module prompt.</p></div><div className="grid gap-2 p-3 md:grid-cols-3">{items.map((item) => <Badge key={item} tone="neutral">{item}</Badge>)}</div></div>;
}

function AuditTable({ audit }: { audit: Record<string, unknown>[] }) {
  return <SimpleRows title="Recent audit activity" rows={audit} columns={["action", "entity_type", "reason", "created_at"]} />;
}

function SimpleRows({ title, rows, columns }: { title: string; rows: Record<string, unknown>[]; columns: string[] }) {
  return <div className="rounded-md border"><div className="border-b px-3 py-2 text-sm font-semibold">{title}</div>{rows.length === 0 ? <EmptyState title="No records yet" description="Activity will appear here as Employee 360 changes are made." /> : <div className="overflow-x-auto"><Table><TableHeader><TableRow>{columns.map((c) => <TableHead key={c}>{c.replace(/_/g, " ")}</TableHead>)}</TableRow></TableHeader><TableBody>{rows.map((row, index) => <TableRow key={index}>{columns.map((c) => <TableCell key={c}>{String(row[c] ?? "-")}</TableCell>)}</TableRow>)}</TableBody></Table></div>}</div>;
}

function ContactModal({ contact, onClose, onSave }: { contact?: EmployeeContact; onClose: () => void; onSave: (input: EmployeeContactInput) => void }) {
  const [form, setForm] = useState<EmployeeContactInput>({
    contact_type: contact?.contact_type ?? "PERSONAL_PHONE",
    value: contact?.value ?? "",
    country_code: contact?.country_code ?? "",
    relationship: contact?.relationship ?? "",
    is_primary: contact?.is_primary ?? false,
    emergency_priority: contact?.emergency_priority ?? null,
    is_sensitive: contact?.is_sensitive ?? false,
    notes: contact?.notes ?? ""
  });
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/25 p-4">
      <div className="w-full max-w-xl rounded-lg border bg-white shadow-xl">
        <div className="flex justify-between border-b px-4 py-3">
          <h2 className="text-sm font-semibold">{contact ? "Edit contact" : "Add contact"}</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>Close</Button>
        </div>
        <div className="grid gap-3 p-4 md:grid-cols-2">
          <SelectField label="Type" value={form.contact_type} onChange={(event) => setForm({ ...form, contact_type: event.target.value as EmployeeContactInput["contact_type"] })}>
            {["PERSONAL_PHONE", "WORK_PHONE", "PERSONAL_EMAIL", "WORK_EMAIL", "EMERGENCY", "GUARDIAN", "SPOUSE", "PARENT", "OTHER"].map((type) => <option key={type} value={type}>{type}</option>)}
          </SelectField>
          <Field label="Value" value={form.value} onChange={(value) => setForm({ ...form, value })} />
          <Field label="Country code" value={form.country_code ?? ""} onChange={(country_code) => setForm({ ...form, country_code })} />
          <Field label="Relationship" value={form.relationship ?? ""} onChange={(relationship) => setForm({ ...form, relationship })} />
          <Field label="Priority" value={form.emergency_priority?.toString() ?? ""} onChange={(value) => setForm({ ...form, emergency_priority: value ? Number(value) : null })} />
          <Field label="Notes" value={form.notes ?? ""} onChange={(notes) => setForm({ ...form, notes })} />
          <CheckboxField label="Primary" checked={form.is_primary} onChange={(checked) => setForm({ ...form, is_primary: checked })} />
          <CheckboxField label="Sensitive" checked={form.is_sensitive} onChange={(checked) => setForm({ ...form, is_sensitive: checked })} />
        </div>
        <div className="flex justify-end gap-2 border-t px-4 py-3">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" onClick={() => onSave(form)}>Save</Button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return <div className="space-y-1.5"><Label>{label}</Label><Input value={value} onChange={(event) => onChange(event.target.value)} /></div>;
}
