import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

function read(file) {
  return fs.readFileSync(path.join(root, file), "utf8");
}

function assert(condition, message) {
  if (!condition) {
    console.error(`FAIL: ${message}`);
    process.exitCode = 1;
  } else {
    console.log(`PASS: ${message}`);
  }
}

function includes(file, marker, message = `${file} contains ${marker}`) {
  assert(read(file).includes(marker), message);
}

function notMatches(file, pattern, message) {
  assert(!pattern.test(read(file)), message);
}

const lifecycle = read("worker/src/routes/lifecycle.ts");
const documents = read("worker/src/routes/documents.ts");
const employeesRoute = read("worker/src/routes/employees.ts");
const lifecyclePage = read("frontend/src/pages/LifecyclePage.tsx");
const employeeProfilePage = read("frontend/src/pages/EmployeeProfilePage.tsx");
const employeesPage = read("frontend/src/pages/EmployeesPage.tsx");
const reportsPage = read("frontend/src/pages/ReportsPage.tsx");
const contractsPage = read("frontend/src/pages/ContractsPage.tsx");
const payrollFoundationPage = read("frontend/src/pages/PayrollFoundationPages.tsx");
const employeePayrollPanels = read("frontend/src/components/payroll/EmployeePayrollFoundationPanels.tsx");
const api = read("frontend/src/lib/api.ts");
const permissions = read("worker/src/db/permissions.ts");
const seed = read("database/seed.sql");
const schema = read("database/schema.sql");
const remoteUtils = read("scripts/remote-d1-schema-utils.mjs");
const remoteAudit = read("scripts/audit-remote-d1-schema.mjs");
const remoteGenerator = read("scripts/generate-remote-d1-repair.mjs");
const remoteReady = read("scripts/verify-remote-d1-schema-ready.mjs");
const wrangler = read("worker/wrangler.toml");
const pagesHeaders = read("frontend/public/_headers");

[
  '"/cases/:caseId/workspace"',
  '"/cases/:caseId/employee-info"',
  '"/cases/:caseId/contact-info"',
  '"/cases/:caseId/job-assignment"',
  '"/cases/:caseId/documents"',
  '"/cases/:caseId/contracts"',
  '"/cases/:caseId/payroll-profile"',
  '"/cases/:caseId/payment-methods"',
  '"/cases/:caseId/pension-profile"',
  '"/cases/:caseId/biometric-mapping"',
  '"/cases/:caseId/assets-uniforms"',
  '"/cases/:caseId/user-account"',
  '"/cases/:caseId/refresh-checklist"',
  '"/cases/:caseId/complete"'
].forEach((marker) => assert(lifecycle.includes(marker), `onboarding workspace API marker exists: ${marker}`));

[
  "loadOnboardingWorkspace",
  "validateWorkspaceJobAssignment",
  "employee_contacts",
  "employee_addresses",
  "employee_contracts",
  "employee_payroll_profiles",
  "employee_payment_methods",
  "employee_pension_profiles",
  "employee_biometric_mappings",
  "employee_asset_assignments",
  "source_of_truth",
  "setOnboardingTaskState",
  "NOT_REQUIRED",
  "isModuleEnabled",
  "activateEmployeeFromOnboarding",
  "getOnboardingWorkspaceDocumentTypes",
  "document_type_warning"
].forEach((marker) => assert(lifecycle.includes(marker), `lifecycle source-of-truth marker exists: ${marker}`));

assert(schema.includes("allowed_mime_types TEXT"), "document_types.allowed_mime_types exists in schema");
assert(schema.includes("max_file_size_mb") && schema.includes("allow_multiple_files"), "document type upload rule columns exist in schema");
assert(remoteUtils.includes("codeRequiredColumns") && remoteUtils.includes("allowed_mime_types"), "remote schema expected code-required columns include allowed_mime_types");
assert(remoteAudit.includes("codeRequiredColumns") && remoteAudit.includes("Referenced by Worker/runtime code."), "remote schema audit checks code-required columns");
assert(remoteGenerator.includes("ALTER TABLE") && remoteGenerator.includes("ADD COLUMN"), "remote schema generator can emit missing-column repairs");
assert(remoteReady.includes("codeRequiredColumns") && remoteReady.includes("${tableName}.${column} is missing"), "remote schema readiness checks code-required columns");
assert(lifecycle.includes("COALESCE(allowed_mime_types") && lifecycle.includes("Document upload configuration is incomplete"), "workspace document section has defensive metadata fallback");
assert(pagesHeaders.includes("/index.html") && pagesHeaders.includes("Cache-Control: no-cache"), "Cloudflare Pages headers keep index.html fresh");
assert(pagesHeaders.includes("/") && pagesHeaders.includes("Cache-Control: no-cache"), "Cloudflare Pages headers keep root document fresh");
assert(pagesHeaders.includes("/assets/*") && pagesHeaders.includes("max-age=31536000") && pagesHeaders.includes("immutable"), "Cloudflare Pages headers cache hashed assets immutably");
assert(lifecycle.includes("WorkspaceOptionalSectionStatus") && lifecycle.includes("loadOptionalOnboardingWorkspaceSection"), "onboarding workspace has optional section loader");
assert(lifecycle.includes("NO_PERMISSION") && lifecycle.includes("DISABLED") && lifecycle.includes("Optional onboarding workspace section unavailable"), "optional workspace sections handle no-permission, disabled, and warning states");
assert(lifecycle.includes("payment_institutions") && lifecycle.includes("pension_schemes") && lifecycle.includes("final_settlement"), "onboarding workspace optional payroll/final-settlement sections are represented");

assert(lifecycle.includes("uploadEmployeeDocument(c") && documents.includes("DOCUMENTS_BUCKET") && documents.includes("r2_key"), "onboarding document upload delegates to existing document/R2 flow");
assert(documents.includes("employee_documents") && documents.includes("employee_document_versions"), "existing document module writes employee document source tables");

[
  "getOnboardingWorkspace",
  "updateOnboardingWorkspaceEmployeeInfo",
  "updateOnboardingWorkspaceContactInfo",
  "updateOnboardingWorkspaceJobAssignment",
  "uploadOnboardingWorkspaceDocument",
  "createOnboardingWorkspaceContract",
  "updateOnboardingWorkspacePayrollProfile",
  "createOnboardingWorkspacePaymentMethod",
  "updateOnboardingWorkspacePensionProfile",
  "createOnboardingWorkspaceBiometricMapping",
  "saveOnboardingWorkspaceAssetsUniforms",
  "saveOnboardingWorkspaceUserAccount",
  "completeOnboardingWorkspace"
].forEach((marker) => assert(api.includes(marker), `frontend API helper exists: ${marker}`));

[
  "OnboardingWorkspace",
  "useAlert",
  "showSuccess",
  "showApiError",
  "OptionalSectionStatePanel",
  "OptionalSectionNotice",
  "optionalSectionUnavailable",
  "No permission",
  "Onboarding setup sections",
  "completedOnboardingTaskStatuses",
  "sectionStatus(tab)",
  "readiness.can_activate === true",
  "intent={primaryAction.intent}",
  "disabled={primaryAction.disabled}",
  "EmployeeInfoWorkspaceForm",
  "ContactWorkspaceForm",
  "JobAssignmentWorkspaceForm",
  "DocumentsWorkspaceForm",
  "ContractWorkspaceForm",
  "PayrollWorkspaceForm",
  "PaymentPensionWorkspaceForm",
  "AttendanceRosterWorkspaceForm",
  "AssetsWorkspaceForm",
  "UserAccessWorkspaceForm",
  "ChecklistWorkspaceTable",
  "SubNavigationBar",
  "uploadOnboardingWorkspaceDocument"
].forEach((marker) => assert(lifecyclePage.includes(marker), `onboarding case page includes workspace UI marker: ${marker}`));

assert(!lifecyclePage.includes("WorkspaceNoticePopup") && !lifecyclePage.includes("setNotice(") && !lifecyclePage.includes("setMessage(success)") && !lifecyclePage.includes("Unable to save onboarding workspace section.</div>"), "onboarding workspace uses global popup alerts instead of legacy inline/local save alerts");
assert(reportsPage.includes("canLoadPaymentInstitutions") && reportsPage.includes("Promise.resolve({ institutions: [] })"), "reports page skips payment institution reference API without permission");
assert(reportsPage.includes("canLoadPensionSchemes") && reportsPage.includes("Promise.resolve({ schemes: [] })"), "reports page skips pension scheme reference API without permission");
assert(contractsPage.includes("canLoadContracts") && contractsPage.includes("canLoadContractReferences"), "contracts page skips contract APIs when contracts are unavailable to the user");
assert(payrollFoundationPage.includes("canView") && payrollFoundationPage.includes("You do not have permission to view payment institutions"), "payment institutions page handles no-permission state");
assert(payrollFoundationPage.includes("You do not have permission to view pension setup"), "pension page handles no-permission state");
assert(employeePayrollPanels.includes("canViewPaymentInstitutions") && employeePayrollPanels.includes("canViewPensionSchemes"), "Employee 360 payroll panels skip optional reference APIs without permission");

assert(employeeProfilePage.includes("employees.360.view_during_onboarding"), "Employee 360 override permission is checked");
assert(employeeProfilePage.includes("Employee 360 is locked during onboarding"), "Employee 360 locked message exists");
assert(employeeProfilePage.includes("/onboarding/cases?case_id="), "Employee 360 lock links back to onboarding case");
assert(employeesRoute.includes("active_onboarding_case_id"), "employee list API returns active onboarding case marker");
assert(employeesPage.includes("employeePrimaryRoute") && employeesPage.includes("active_onboarding_case_id"), "employee list routes onboarding employees to onboarding case");

[
  "onboarding.workspace.view",
  "onboarding.workspace.update",
  "onboarding.workspace.documents.upload",
  "onboarding.workspace.contracts.create",
  "onboarding.workspace.payroll.update",
  "onboarding.workspace.payment_methods.update",
  "onboarding.workspace.pension.update",
  "onboarding.workspace.attendance.update",
  "onboarding.workspace.assets.update",
  "onboarding.workspace.user_access.update",
  "onboarding.workspace.complete",
  "onboarding.workspace.activate",
  "employees.360.view_during_onboarding"
].forEach((marker) => {
  assert(permissions.includes(marker), `permission catalog includes ${marker}`);
  assert(seed.includes(marker), `seed includes ${marker}`);
});

assert(wrangler.includes('binding = "DB"') && wrangler.includes('database_name = "hrm-v2"') && wrangler.includes('database_id = "97f9966e-4fe5-4999-aed7-dc20d75fc89e"'), "D1 binding unchanged");
assert(wrangler.includes('binding = "DOCUMENTS_BUCKET"') && wrangler.includes('bucket_name = "hrm-v2-documents"'), "R2 binding unchanged");
assert(read("worker/src/auth/password.ts").includes("PBKDF2_ITERATIONS = 100000") || read("worker/src/auth/password.ts").includes("100000"), "PBKDF2 remains capped at 100000");

["frontend/src/pages/LifecyclePage.tsx", "frontend/src/pages/EmployeeProfilePage.tsx", "frontend/src/pages/EmployeesPage.tsx"].forEach((file) => {
  notMatches(file, /\b(window\.)?(alert|confirm|prompt)\s*\(/, `${file} has no browser alert/confirm/prompt`);
});

includes("scripts/verify-performance-optimization.mjs", "performance", "performance optimization verifier remains present");
includes("scripts/verify-shadcn-navigation-tabs.mjs", "shadcn", "shadcn navigation verifier remains present");

if (process.exitCode) {
  console.error("Onboarding workspace verification failed.");
  process.exit(process.exitCode);
}

console.log("Onboarding workspace verification passed.");
